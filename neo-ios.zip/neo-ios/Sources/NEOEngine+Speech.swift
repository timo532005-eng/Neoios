import Foundation
import AVFoundation
import Network

// ════════════════════════════════════════════════════════════════
// NEOEngine+Speech.swift — konuşma tanıma / seslendirme bağlama
// (initSpeechRecognition, startListening/stopListening, speak(),
// updateVoicePanel, populateVoiceSelect karşılığı) ve ağ izleme.
// ════════════════════════════════════════════════════════════════

extension NEOEngine {

    func wireSpeech() {
        speech.onFinalResult = { [weak self] text in
            self?.sendMessage(text, fromVoice: true)
        }
        speech.onError = { [weak self] message in
            self?.showError(message, recoverDelay: 3.2)
        }
        speech.onEnd = { [weak self] in
            guard let self else { return }
            if self.state == .listening { self.setState(.idle) }
        }
        speech.$liveTranscript
            .receive(on: DispatchQueue.main)
            .sink { [weak self] text in self?.liveTranscript = text }
            .store(in: &speechCancellables)
        speech.$volume
            .receive(on: DispatchQueue.main)
            .sink { [weak self] v in
                guard let self, self.state == .listening else { return }
                self.volume = v
            }
            .store(in: &speechCancellables)

        refreshVoicePanelText()
    }

    func wireTTS() {
        tts.onFinishedAllSentences = { [weak self] in
            guard let self else { return }
            if self.state == .speaking { self.setState(.idle) }
        }
        tts.$volume
            .receive(on: DispatchQueue.main)
            .sink { [weak self] v in
                guard let self, self.state == .speaking else { return }
                self.volume = v
            }
            .store(in: &speechCancellables)
        refreshVoiceHint()
    }

    func toggleListening() {
        if state == .listening {
            speech.stop()
        } else if state == .idle || state == .error {
            startCommandListening()
        }
    }

    private func startCommandListening() {
        guard speech.supported else {
            showError("Bu cihaz konuşma tanımayı desteklemiyor.")
            return
        }
        tts.stop()
        speech.start()
        setState(.listening)
    }

    func speakNow(_ text: String) {
        let voice = tts.pickDefaultVoice(savedIdentifier: selectedVoiceIdentifier, genderPref: voiceGenderPref, strict: voiceGenderStrict)
        let maleMul = tts.syntheticMalePitchMultiplier(for: voice, genderPref: voiceGenderPref)
        let effectivePitch = Float((Double(pitch) * Double(maleMul)).clamped(to: 0...2))
        setState(.speaking)
        tts.speak(text, voice: voice, rate: rate, pitch: effectivePitch, humanize: humanize)
    }

    func refreshVoiceHint() {
        tts.loadVoices()
        let voices = tts.voices
        let hasTr = voices.contains { $0.language.lowercased().hasPrefix("tr") }
        let def = tts.pickDefaultVoice(savedIdentifier: selectedVoiceIdentifier, genderPref: voiceGenderPref, strict: voiceGenderStrict)
        let isEnhanced = def?.quality == .enhanced || def?.quality == .premium
        let trGenderMatch: Bool = {
            guard voiceGenderPref != .auto else { return false }
            return voices.contains { $0.language.lowercased().hasPrefix("tr") && genderMatches($0, voiceGenderPref) }
        }()

        if voiceGenderPref != .auto && hasTr && !trGenderMatch {
            let genderLabel = voiceGenderPref == .male ? "erkek" : "kadın"
            if voiceGenderPref == .male {
                voiceSupportHint = "iOS'ta Türkçe için Apple'ın sunduğu yerleşik bir erkek sistem sesi bulunmuyor (yalnızca \"Yelda\" kadın sesi geliyor) — bu bir uygulama kısıtı değil, işletim sisteminin kendi ses kütüphanesi kısıtıdır. Bunun yerine Türkçe kadın sesin tonu yapay olarak kalınlaştırılarak yaklaşık bir erkek ses efekti uygulanıyor; bu gerçek bir erkek ses kaydı değildir. Gerçek bir erkek sesi duymak isterseniz Ayarlar > Erişilebilirlik > Sesli İçerik bölümünden başka bir dilde (ör. İngilizce) bir erkek ses indirip \"Cinsiyet Tercihi\"ni değiştirmeden bırakabilirsiniz — ancak bu durumda Türkçe telaffuz bozulur."
            } else {
                let strictNote = voiceGenderStrict
                    ? " \"Türkçede uygun ses yoksa cinsiyeti yine de önceliklendir\" açık olduğu için başka bir dildeki bir \(genderLabel) ses kullanılıyor olabilir — bu durumda Türkçe telaffuz bozulabilir."
                    : " Şimdilik en iyi Türkçe sesi (\"\(def?.name ?? "")\") kullanıyorum. Yine de o cinsiyette bir ses istiyorsanız (telaffuz kalitesi düşebilir) yukarıdaki \"Türkçede uygun ses yoksa cinsiyeti yine de önceliklendir\" seçeneğini açabilirsiniz."
                voiceSupportHint = "Bu cihazda Türkçe bir \(genderLabel) ses bulamadım (yalnızca cihazınızın kurulu sunduğu seslerden seçim yapabiliyorum, yeni bir ses üretemem).\(strictNote) Ayarlar > Erişilebilirlik > Sesli İçerik bölümünden ek Türkçe sesler indirebilirsiniz."
            }
        } else if hasTr && isEnhanced {
            voiceSupportHint = "Türkçe, yüksek kaliteli bir sistem sesi bulundu ve otomatik seçildi: \"\(def?.name ?? "")\"."
        } else if hasTr {
            voiceSupportHint = "Türkçe bir sistem ses bulundu ve seçildi: \"\(def?.name ?? "")\". Daha insansı bir ton için Ayarlar > Erişilebilirlik > Sesli İçerik bölümünden \"Gelişmiş\" kaliteli bir Türkçe ses indirmeniz önerilir."
        } else {
            voiceSupportHint = "Bu cihazda Türkçe bir sistem sesi bulunamadı; en yakın/kaliteli ses otomatik kullanılacak. Ayarlar > Erişilebilirlik > Sesli İçerik bölümünden Türkçe bir ses indirmeniz gerekebilir."
        }
    }

    func refreshVoicePanelText() {
        guard speech.supported else {
            voicePanel = "YALNIZCA TTS"
            voicePanelLevel = .warn
            return
        }
        voicePanel = "AKTİF"
        voicePanelLevel = .ok
    }

    private func genderMatches(_ v: AVSpeechSynthesisVoice, _ pref: VoiceGenderPref) -> Bool {
        switch (v.gender, pref) {
        case (.male, .male), (.female, .female): return true
        default: return false
        }
    }

    // MARK: - Ağ izleme (navigator.onLine karşılığı)

    func startNetworkMonitoring() {
        let monitor = NWPathMonitor()
        monitor.pathUpdateHandler = { [weak self] path in
            Task { @MainActor in self?.updateNetworkPanel(online: path.status == .satisfied) }
        }
        monitor.start(queue: DispatchQueue(label: "neo.network.monitor"))
        self.networkMonitor = monitor
    }
}
