import Foundation
import Network

// ════════════════════════════════════════════════════════════════
// RemoteShareServer.swift — "Paylaşım" özelliğinin ağ katmanı.
//
// Üçüncü parti paket KULLANMADAN, Apple'ın Network framework'üyle
// (NWListener) çok küçük bir HTTP/1.1 sunucusu çalıştırır. Aynı Wi-Fi
// ağındaki başka bir cihaz, QR koddaki adresi tarayıcıda açınca NEO'nun
// web arayüzünü (bkz. RemoteWebUI.swift) buradan alır ve mesaj gönderir.
//
// Bu dosya yalnızca "HTTP isteği al → bir kapanışa ilet → cevabı geri
// yaz" işini yapar; hangi isteğe ne cevap verileceği (jeton kontrolü,
// mesaj listesi, mesaj gönderme) RemoteShareController'dadır.
// ════════════════════════════════════════════════════════════════

struct RemoteHTTPRequest: Sendable {
    let method: String
    let path: String
    let query: [String: String]
    let body: Data
}

struct RemoteHTTPResponse: Sendable {
    var status: Int
    var contentType: String
    var body: Data

    static func text(_ status: Int, _ message: String) -> RemoteHTTPResponse {
        RemoteHTTPResponse(status: status, contentType: "text/plain; charset=utf-8", body: Data(message.utf8))
    }
    static func html(_ page: String) -> RemoteHTTPResponse {
        RemoteHTTPResponse(status: 200, contentType: "text/html; charset=utf-8", body: Data(page.utf8))
    }
    static func json(_ status: Int = 200, _ data: Data) -> RemoteHTTPResponse {
        RemoteHTTPResponse(status: status, contentType: "application/json; charset=utf-8", body: data)
    }
}

/// start() tamamlanma bildirimini tam BİR kez göndermek için küçük bir
/// kilitli bayrak (NWListener durum kapanışı birden çok kez çağrılabilir).
private final class OnceFlag: @unchecked Sendable {
    private let lock = NSLock()
    private var fired = false
    func fire() -> Bool {
        lock.lock(); defer { lock.unlock() }
        if fired { return false }
        fired = true
        return true
    }
}

final class RemoteShareServer: @unchecked Sendable {
    private let queue = DispatchQueue(label: "app.neo.remote-share")
    private var listener: NWListener?
    /// Her HTTP isteği için çağrılır; dönen cevap istemciye yazılır.
    var onRequest: (@Sendable (RemoteHTTPRequest) async -> RemoteHTTPResponse)?

    /// Sistemin seçtiği boş bir TCP portunda dinlemeye başlar; hazır
    /// olunca portu (veya hatayı) completion ile bildirir.
    func start(completion: @escaping @Sendable (Result<UInt16, Error>) -> Void) {
        stop()
        do {
            let newListener = try NWListener(using: .tcp)
            let once = OnceFlag()
            newListener.stateUpdateHandler = { [weak newListener] state in
                switch state {
                case .ready:
                    if let port = newListener?.port?.rawValue, once.fire() {
                        completion(.success(port))
                    }
                case .failed(let error):
                    if once.fire() { completion(.failure(error)) }
                    newListener?.cancel()
                default:
                    break
                }
            }
            newListener.newConnectionHandler = { [weak self] connection in
                self?.accept(connection)
            }
            newListener.start(queue: queue)
            listener = newListener
        } catch {
            completion(.failure(error))
        }
    }

    func stop() {
        listener?.cancel()
        listener = nil
    }

    // MARK: - Bağlantı işleme

    private func accept(_ connection: NWConnection) {
        connection.stateUpdateHandler = { state in
            if case .failed = state { connection.cancel() }
        }
        connection.start(queue: queue)
        receive(on: connection, buffer: Data())
    }

    private func receive(on connection: NWConnection, buffer: Data) {
        connection.receive(minimumIncompleteLength: 1, maximumLength: 65_536) { [weak self] data, _, isComplete, error in
            guard let self else { connection.cancel(); return }
            var buf = buffer
            if let data { buf.append(data) }
            switch Self.parse(buf) {
            case .complete(let request):
                self.respond(to: request, on: connection)
            case .invalid:
                self.send(.text(400, "Geçersiz istek."), on: connection)
            case .incomplete:
                if error != nil || isComplete || buf.count > 300_000 {
                    connection.cancel()
                } else {
                    self.receive(on: connection, buffer: buf)
                }
            }
        }
    }

    private func respond(to request: RemoteHTTPRequest, on connection: NWConnection) {
        let handler = onRequest
        Task {
            var response = RemoteHTTPResponse.text(503, "NEO hazır değil.")
            if let handler { response = await handler(request) }
            self.send(response, on: connection)
        }
    }

    private func send(_ response: RemoteHTTPResponse, on connection: NWConnection) {
        var head = "HTTP/1.1 \(response.status) \(Self.reasonPhrase(response.status))\r\n"
        head += "Content-Type: \(response.contentType)\r\n"
        head += "Content-Length: \(response.body.count)\r\n"
        head += "Cache-Control: no-store\r\n"
        head += "X-Content-Type-Options: nosniff\r\n"
        head += "Referrer-Policy: no-referrer\r\n"
        head += "Connection: close\r\n\r\n"
        var out = Data(head.utf8)
        out.append(response.body)
        connection.send(content: out, contentContext: .finalMessage, isComplete: true, completion: .contentProcessed { _ in
            connection.cancel()
        })
    }

    private static func reasonPhrase(_ status: Int) -> String {
        switch status {
        case 200: return "OK"
        case 400: return "Bad Request"
        case 403: return "Forbidden"
        case 404: return "Not Found"
        case 409: return "Conflict"
        case 503: return "Service Unavailable"
        default: return "Status"
        }
    }

    // MARK: - Çok basit HTTP ayrıştırıcı

    private enum ParseResult {
        case complete(RemoteHTTPRequest)
        case incomplete
        case invalid
    }

    private static func parse(_ data: Data) -> ParseResult {
        let separator = Data("\r\n\r\n".utf8)
        guard let headerEnd = data.range(of: separator) else {
            return data.count > 32_768 ? .invalid : .incomplete
        }
        let headerData = data[data.startIndex..<headerEnd.lowerBound]
        guard let headerText = String(data: headerData, encoding: .utf8) else { return .invalid }
        let lines = headerText.components(separatedBy: "\r\n")
        guard let requestLine = lines.first else { return .invalid }
        let parts = requestLine.split(separator: " ", omittingEmptySubsequences: true)
        guard parts.count >= 2 else { return .invalid }
        let method = String(parts[0]).uppercased()
        let target = String(parts[1])

        var contentLength = 0
        for line in lines.dropFirst() {
            guard let colon = line.firstIndex(of: ":") else { continue }
            let name = line[line.startIndex..<colon].lowercased()
            if name == "content-length" {
                let value = line[line.index(after: colon)...].trimmingCharacters(in: .whitespaces)
                contentLength = Int(value) ?? 0
            }
        }
        guard contentLength >= 0, contentLength <= 200_000 else { return .invalid }

        let bodyStart = headerEnd.upperBound
        let available = data.count - (bodyStart - data.startIndex)
        guard available >= contentLength else { return .incomplete }
        let body = data[bodyStart..<(bodyStart + contentLength)]

        guard let comps = URLComponents(string: "http://neo.local" + target) else { return .invalid }
        var query: [String: String] = [:]
        for item in comps.queryItems ?? [] { query[item.name] = item.value ?? "" }
        return .complete(RemoteHTTPRequest(method: method, path: comps.path, query: query, body: Data(body)))
    }

    // MARK: - Yerel IP adresi

    /// Cihazın yerel ağdaki (özel aralıkta) IPv4 adresini döner: önce
    /// Wi-Fi (en0), sonra internet paylaşımı köprüsü (bridge*), sonra
    /// diğer arayüzler. Wi-Fi'ye bağlı değilse nil.
    static func localIPv4Address() -> String? {
        var ifaddrPointer: UnsafeMutablePointer<ifaddrs>?
        guard getifaddrs(&ifaddrPointer) == 0, let first = ifaddrPointer else { return nil }
        defer { freeifaddrs(ifaddrPointer) }

        var candidates: [(name: String, ip: String)] = []
        var cursor: UnsafeMutablePointer<ifaddrs>? = first
        while let current = cursor {
            let entry = current.pointee
            cursor = entry.ifa_next
            guard let addr = entry.ifa_addr, addr.pointee.sa_family == UInt8(AF_INET) else { continue }
            let flags = Int32(entry.ifa_flags)
            guard (flags & IFF_UP) != 0, (flags & IFF_LOOPBACK) == 0 else { continue }
            var host = [CChar](repeating: 0, count: Int(NI_MAXHOST))
            let result = getnameinfo(addr, socklen_t(addr.pointee.sa_len), &host, socklen_t(host.count), nil, 0, NI_NUMERICHOST)
            guard result == 0 else { continue }
            let ip = String(cString: host)
            guard isPrivate(ip) else { continue }
            candidates.append((String(cString: entry.ifa_name), ip))
        }
        if let wifi = candidates.first(where: { $0.name == "en0" }) { return wifi.ip }
        if let bridge = candidates.first(where: { $0.name.hasPrefix("bridge") }) { return bridge.ip }
        return candidates.first?.ip
    }

    private static func isPrivate(_ ip: String) -> Bool {
        let parts = ip.split(separator: ".").compactMap { Int($0) }
        guard parts.count == 4 else { return false }
        if parts[0] == 10 { return true }
        if parts[0] == 192 && parts[1] == 168 { return true }
        if parts[0] == 172 && (16...31).contains(parts[1]) { return true }
        return false
    }
}
