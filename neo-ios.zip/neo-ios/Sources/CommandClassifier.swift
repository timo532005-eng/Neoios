import Foundation

// ════════════════════════════════════════════════════════════════
// CommandClassifier.swift — orijinal bölüm 9 (hesap makinesi) ve
// bölüm 10 (KOMUT SINIFLANDIRMA VE YÖNLENDİRME) karşılığı.
// ════════════════════════════════════════════════════════════════

private func matches(_ pattern: String, _ text: String) -> Bool {
    (try? NSRegularExpression(pattern: pattern, options: .caseInsensitive))
        .map { $0.firstMatch(in: text, range: NSRange(text.startIndex..., in: text)) != nil } ?? false
}

private func firstGroup(_ pattern: String, _ text: String) -> String? {
    guard let re = try? NSRegularExpression(pattern: pattern, options: .caseInsensitive),
          let m = re.firstMatch(in: text, range: NSRange(text.startIndex..., in: text)),
          m.numberOfRanges > 1, let r = Range(m.range(at: 1), in: text) else { return nil }
    return String(text[r])
}

// MARK: - Güvenli hesap makinesi (eval kullanılmaz)

enum Calculator {
    static func turkishMathToSymbols(_ text: String) -> String {
        var t = text.lowercased()
        let replacements: [(String, String)] = [
            ("artı", "+"), ("eksi", "-"),
            ("çarpı", "*"), ("carpi", "*"),
            ("bölü", "/"), ("bolu", "/"),
            ("üzeri", "^"), ("uzeri", "^"),
            (",", "."),
        ]
        for (a, b) in replacements { t = t.replacingOccurrences(of: a, with: b) }
        t = t.replacingOccurrences(of: #"kaç\s*eder\??|kaçtır\??|kaç\??|="#, with: "", options: .regularExpression)
        t = t.replacingOccurrences(of: #"[^0-9+\-*/^().\s]"#, with: " ", options: .regularExpression)
        return t
    }

    enum EvalError: Error { case invalid }

    /// Basit güvenli aritmetik parser: sayı, + - * / ^ ( )
    static func safeEvaluate(_ expr: String) throws -> Double {
        let s = Array(expr.replacingOccurrences(of: " ", with: "").replacingOccurrences(of: "\t", with: ""))
        guard !s.isEmpty else { throw EvalError.invalid }
        var pos = 0

        func peek() -> Character? { pos < s.count ? s[pos] : nil }
        func consume() -> Character { defer { pos += 1 }; return s[pos] }

        func parseNumber() throws -> Double {
            let start = pos
            if peek() == "-" { pos += 1 }
            while let c = peek(), c.isNumber || c == "." { pos += 1 }
            let numStr = String(s[start..<pos])
            guard let val = Double(numStr), numStr != "-" else { throw EvalError.invalid }
            return val
        }
        func parseFactor() throws -> Double {
            if peek() == "(" {
                pos += 1
                let v = try parseExpr()
                guard peek() == ")" else { throw EvalError.invalid }
                pos += 1
                return v
            }
            return try parseNumber()
        }
        func parsePower() throws -> Double {
            let base = try parseFactor()
            if peek() == "^" { pos += 1; return pow(base, try parsePower()) }
            return base
        }
        func parseTerm() throws -> Double {
            var val = try parsePower()
            while let op = peek(), op == "*" || op == "/" {
                pos += 1
                let rhs = try parsePower()
                val = op == "*" ? val * rhs : val / rhs
            }
            return val
        }
        func parseExpr() throws -> Double {
            var val = try parseTerm()
            while let op = peek(), op == "+" || op == "-" {
                pos += 1
                let rhs = try parseTerm()
                val = op == "+" ? val + rhs : val - rhs
            }
            return val
        }

        let result = try parseExpr()
        guard pos == s.count, result.isFinite else { throw EvalError.invalid }
        return result
    }

    static func tryCalculate(_ rawText: String) -> Double? {
        let converted = turkishMathToSymbols(rawText)
        guard matches("[0-9]", converted), matches(#"[+\-*/^]"#, converted) else { return nil }
        guard let result = try? safeEvaluate(converted) else { return nil }
        return (result * 1e6).rounded() / 1e6
    }
}

// MARK: - Komut sınıflandırma

enum CommandClassifier {
    static func classify(_ text: String) -> ParsedCommand {
        let t = text.trimmingCharacters(in: .whitespacesAndNewlines)
        let lower = t.lowercased()

        if matches(#"(neo[, ]*)?ayarlar[ıi]?\s*a[çc]"#, lower) { return .ui(action: "openSettings") }
        if matches(#"(neo[, ]*)?ayarlar[ıi]?\s*kapat"#, lower) { return .ui(action: "closeDrawers") }
        if matches(#"(neo[, ]*)?(sohbeti|konu[şs]may[ıi]|ekran[ıi])\s*temizle"#, lower) { return .ui(action: "clearChat") }
        if matches(#"(neo[, ]*)?haf[ıi]zan[ıi]\s*g[öo]ster"#, lower) { return .ui(action: "showMemory") }
        if matches(#"(neo[, ]*)?hakk[ıi]nda\s*ne\s*biliyorsun"#, lower) { return .ui(action: "listMemory") }
        if matches(#"^neo\s*dur$"#, lower) { return .ui(action: "stop") }
        if matches(#"(neo[, ]*)?kameray?[ıi]?\s*a[çc]"#, lower) { return .ui(action: "openCamera") }
        if matches(#"(neo[, ]*)?takvim(i|imi)?\s*(aç|göster)"#, lower) { return .ui(action: "openCalendar") }
        if matches(#"(neo[, ]*)?profil(im|imi)?\s*(aç|göster|düzenle|ayarla)"#, lower) || matches(#"beni\s*tan[ıi]"#, lower) { return .ui(action: "openProfile") }
        if matches(#"(neo[, ]*)?g[öo]rsel\s*(oluştur|üret)"#, lower) { return .ui(action: "openImageGen") }
        if matches(#"(neo[, ]*)?ses(i|\s*kayd[ıi]n[ıi])?\s*yaz[ıi]ya\s*çevir"#, lower) { return .ui(action: "openTranscribe") }

        if let payload = firstGroup(#"(?:neo[, ]*)?bunu\s*hat[ıi]rla\s*[:\-]?\s*(.*)"#, t) {
            return .memory(action: "remember", payload: payload)
        }
        if let payload = firstGroup(#"(?:neo[, ]*)?bunu\s*unut\s*[:\-]?\s*(.*)"#, t) {
            return .memory(action: "forget", payload: payload)
        }

        if matches(#"^not\s*(ekle|al)\s*[:\-]?\s*"#, lower) {
            let payload = t.replacingOccurrences(of: #"^not\s*(ekle|al)\s*[:\-]?\s*"#, with: "", options: [.regularExpression, .caseInsensitive])
            return .notes(action: "add", payload: payload)
        }
        if matches(#"notlar[ıi]m[ıi]?\s*g[öo]ster"#, lower) { return .notes(action: "list", payload: "") }

        if let re = try? NSRegularExpression(pattern: #"(\d+)\s*dakika\s*sonra\s*hat[ıi]rlat\s*[:\-]?\s*(.*)"#, options: .caseInsensitive),
           let m = re.firstMatch(in: lower, range: NSRange(lower.startIndex..., in: lower)),
           let minsRange = Range(m.range(at: 1), in: lower) {
            let mins = Int(lower[minsRange]) ?? 0
            var payload = t
            if m.numberOfRanges > 2, let pr = Range(m.range(at: 2), in: lower), !lower[pr].isEmpty {
                payload = String(lower[pr])
            }
            return .reminder(minutes: mins, payload: payload)
        }

        // Hava durumu: "hava durumu"/"hava nasıl" ifadesi cümlenin HERHANGİ
        // bir yerinde geçebilir (ör. "bugünün hava durumu nedir", "hava
        // durumu nasıl acaba") — eskiden yalnızca cümle TAM OLARAK bu
        // kalıpla bitiyorsa yakalanıyordu, bu da "bugünün hava durumu
        // nedir" gibi fazladan kelime içeren doğal sorularda eşleşmeyip
        // yanlışlıkla aşağıdaki genel "bugün" tarih sorgusuna düşmesine
        // (ve "Bugün Cumartesi" gibi alakasız bir cevaba) yol açıyordu.
        if matches(#"(s[ıi]cakl[ıi]k|d[ıi]şar[ıi]s[ıi])\s*ka[çc]\s*derece"#, lower)
            || matches(#"hava\s*(durum|nas[ıi]l)"#, lower) {
            if let cityRaw = firstGroup(#"^(?:neo[, ]*)?(.+?)\s*(?:'?(?:da|de|ta|te))?\s*hava\s*(?:durumu?|nas[ıi]l)"#, t) {
                let city = cityRaw.trimmingCharacters(in: .whitespaces)
                let isGeneric = city.isEmpty || matches(#"^(bugün\w*|şu\s*an\w*|şimdi|d[ıi]şar[ıi]da)$"#, city.lowercased())
                return .weather(city: isGeneric ? nil : city)
            }
            return .weather(city: nil)
        }

        if matches(#"(takvim|etkinli[gğ]|randevu|toplant[ıi]|program[ıi]m)"#, lower)
            || matches(#"(bugün|yar[ıi]n|bu\s*hafta)\s*(ne\s*var|neler\s*var|planım\s*ne)"#, lower) {
            return .calendar(payload: t)
        }

        if matches(#"saat\s*ka[çc]"#, lower) || matches(#"^saat\??$"#, lower) { return .datetime(action: "time") }
        if matches(#"(bugün|hangi\s*gün|tarih\s*ne|hangi\s*tarih)"#, lower) { return .datetime(action: "date") }

        if matches(#"^neo\s*ara\s*[:\-]?\s*"#, lower) {
            let payload = t.replacingOccurrences(of: #"^neo\s*ara\s*[:\-]?\s*"#, with: "", options: [.regularExpression, .caseInsensitive])
            return .websearch(payload: payload)
        }

        if let calcResult = Calculator.tryCalculate(t), matches(#"[0-9]\s*[+\-*/^]\s*[0-9]"#, Calculator.turkishMathToSymbols(t)) {
            return .calculatorResult(payload: t, result: calcResult)
        }

        // Uygulama/cihaz AÇMA: yalnızca düz emir kipini değil ("X aç"),
        // soru/rica biçimlerini de ("X açar mısın", "X açabilir misin",
        // "X açsana") yakalıyoruz — aksi halde bu tür doğal sorular hiçbir
        // yerel örüntüye uymayıp doğrudan Gemini'ye (genel sohbet) düşüyor;
        // Gemini de gerçekte hiçbir komut çalıştırmadığı halde sistem
        // talimatındaki "cihazları açabilirsin" ifadesine dayanıp
        // "açtım" gibi UYDURMA bir onay verebiliyor.
        let openVerbAlt = #"aç[ae]r\s*m[ıiuü]s[ıiuü]n[ıiuü]?z?|açabilir\s*misin(?:iz)?|aç[sş]ana|aç|ba[şs]lat[ıi]r\s*m[ıiuü]s[ıiuü]n[ıiuü]?z?|ba[şs]latabilir\s*misin(?:iz)?|ba[şs]lat|yak[ae]r\s*m[ıiuü]s[ıiuü]n[ıiuü]?z?|yak"#
        let appPatterns = [
            #"^(?:neo[, ]*)?(.+?)\s+uygulamas[ıi]n[ıi]?\s*(?:"# + openVerbAlt + #")\s*\??\s*$"#,
            #"^(?:neo[, ]*)?(.+?)(?:'?[ıi]n[ıi]|'?y[ıi])?\s*(?:"# + openVerbAlt + #")\s*\??\s*$"#,
        ]
        for pattern in appPatterns {
            if let name = firstGroup(pattern, t), name.trimmingCharacters(in: .whitespaces).count >= 2 {
                return .appOpen(name: name.trimmingCharacters(in: .whitespaces))
            }
        }

        // Akıllı ev (Tuya) cihazlarını kapatmak/söndürmek için genel örüntü.
        // Aynı şekilde soru/rica biçimlerini de yakalıyoruz (ör. "akıllı
        // prizi kapatır mısın", "ışığı kapatabilir misin", "kapatsana").
        // "aç/başlat/yak" yukarıdaki appPatterns'e (uygulama açma) düşüyor;
        // NEOEngine tarafında önce AppCatalog'da aranıp bulunamazsa Tuya
        // cihazlarına bakılıyor. "kapat/söndür" için ise uygulamalarda
        // karşılığı olmadığından doğrudan burada ayrı bir dal var.
        let closeVerbAlt = #"kapat[ıiuü]r\s*m[ıiuü]s[ıiuü]n[ıiuü]?z?|kapatabilir\s*misin(?:iz)?|kapats[ae]na|kapat|söndür[üu]r\s*m[üuıi]s[üuıi]n[üuıi]?z?|söndürebilir\s*misin(?:iz)?|söndür|kapa"#
        let closePatterns = [
            #"^(?:neo[, ]*)?(.+?)(?:'?[ıi]n[ıi]|'?y[ıi])?\s*(?:"# + closeVerbAlt + #")\s*\??\s*$"#,
        ]
        for pattern in closePatterns {
            if let name = firstGroup(pattern, t), name.trimmingCharacters(in: .whitespaces).count >= 2 {
                return .deviceOff(name: name.trimmingCharacters(in: .whitespaces))
            }
        }

        return .gemini(payload: t)
    }
}
