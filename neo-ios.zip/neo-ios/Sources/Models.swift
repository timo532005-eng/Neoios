import Foundation

// ════════════════════════════════════════════════════════════════
// models.swift — Uygulama genelinde kullanılan veri modelleri
// ════════════════════════════════════════════════════════════════

enum NEOState: String {
    case idle, listening, thinking, speaking, error

    var label: String {
        switch self {
        case .idle: return "NEO ONLINE"
        case .listening: return "DİNLİYORUM…"
        case .thinking: return "ANALİZ EDİLİYOR…"
        case .speaking: return "KONUŞUYORUM…"
        case .error: return "SİSTEM HATASI"
        }
    }
}

/// NEO'nun genel konuşma tarzı tercihi — kullanıcı Profilim ekranından
/// seçer, Gemini'ye giden sistem talimatına doğal dilde bir yönerge
/// olarak eklenir (bkz. NEOEngine.buildSystemPrompt()).
enum CommunicationStyle: String, CaseIterable, Codable {
    case concise, balanced, warm, direct

    var label: String {
        switch self {
        case .concise: return "Kısa ve öz"
        case .balanced: return "Dengeli"
        case .warm: return "Sıcak ve samimi"
        case .direct: return "Doğrudan ve yalın"
        }
    }
    var promptHint: String {
        switch self {
        case .concise: return "Cevaplarını olabildiğince kısa tut, gereksiz açıklama yapma."
        case .balanced: return "Ne çok kısa ne çok uzun, dengeli bir uzunlukta cevaplar ver."
        case .warm: return "Daha sıcak, samimi ve destekleyici bir üslup kullan."
        case .direct: return "Lafı dolandırmadan, doğrudan ve net konuş."
        }
    }
}

/// Metin kutusunda "@" yazıldığında açılan AI modları popup'ı (bkz.
/// ControlBarView). Her mod, gönderilen TEK mesajı farklı işler.
enum AIMode: String, CaseIterable, Identifiable, Equatable {
    case imageGen
    case deepThink
    case quickAnswer
    case translate
    case buddy

    var id: String { rawValue }
    var label: String {
        switch self {
        case .imageGen: return "Görsel Oluştur"
        case .deepThink: return "Derin Düşünme"
        case .quickAnswer: return "Hızlı Yanıt"
        case .translate: return "Çeviri"
        case .buddy: return "Kanka"
        }
    }
    var icon: String {
        switch self {
        case .imageGen: return "photo.artframe"
        case .deepThink: return "brain.head.profile"
        case .quickAnswer: return "bolt.fill"
        case .translate: return "character.bubble"
        case .buddy: return "face.smiling.fill"
        }
    }
    var hint: String {
        switch self {
        case .imageGen: return "Yazdığınız açıklamadan bir görsel oluşturur ve gösterir."
        case .deepThink: return "Cevap vermeden önce daha uzun ve kapsamlı düşünür."
        case .quickAnswer: return "Olabildiğince kısa, tek-iki cümlelik bir cevap verir."
        case .translate: return "Yazdığınızı çevirir — dil belirtmezseniz TR↔EN arasında otomatik."
        case .buddy: return "Daha samimi, arkadaş canlısı ve insansı bir üslupla cevap verir."
        }
    }
    /// "@" sonrası filtreleme için eşleşecek anahtar kelimeler.
    var keywords: [String] {
        switch self {
        case .imageGen: return ["görsel", "resim", "image", "foto"]
        case .deepThink: return ["derin", "düşün", "think", "deep"]
        case .quickAnswer: return ["hızlı", "kısa", "quick", "fast"]
        case .translate: return ["çeviri", "çevir", "ceviri", "translate"]
        case .buddy: return ["kanka", "arkadaş", "samimi", "dost", "buddy"]
        }
    }
}

/// NEO'yu bir "hayat asistanı" yapan kullanıcı profili — Profilim
/// ekranından (bkz. ProfileDrawerView) doldurulur, bu cihazda saklanır ve
/// her Gemini isteğine sistem talimatının bir parçası olarak eklenir
/// (bkz. NEOEngine.buildSystemPrompt()). Tamamen isteğe bağlıdır; boş
/// bırakılırsa NEO genel/nötr biçimde davranmaya devam eder.
struct UserProfile: Codable, Equatable {
    var name: String = ""
    var nickname: String = ""
    var occupation: String = ""
    var interests: String = ""
    var goals: String = ""
    var routineNotes: String = ""
    var extraNotes: String = ""
    var communicationStyle: CommunicationStyle = .balanced

    var isEmpty: Bool {
        [name, nickname, occupation, interests, goals, routineNotes, extraNotes]
            .allSatisfy { $0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
    }

    /// NEO'nun kullanıcıya hitap ederken kullanacağı isim: takma ad
    /// girilmişse o, yoksa ad, o da yoksa boş dize (o zaman NEO genel
    /// bir hitapsız cevap kullanır).
    var addressName: String {
        let n = nickname.trimmingCharacters(in: .whitespacesAndNewlines)
        if !n.isEmpty { return n }
        return name.trimmingCharacters(in: .whitespacesAndNewlines)
    }
}

enum ChatRole: String, Codable {
    case user, neo
}

struct ChatMessage: Identifiable, Equatable {
    let id = UUID()
    let role: ChatRole
    let text: String
    var isError: Bool = false
    /// Sohbette gösterilecek üretilmiş görsel (PNG/JPEG baytları) — yalnızca
    /// görsel oluşturma sonuçlarında dolu (bkz. NEOEngine.generateImageInChat).
    var imageData: Data? = nil
    let ts: Date = Date()
}

/// Gemini'ye gönderilen sohbet turu (JS'teki AppState.history karşılığı).
struct HistoryTurn {
    let role: String // "user" | "model"
    let text: String
}

struct MemoryEntry: Identifiable, Codable, Equatable {
    let id: String
    let text: String
    let ts: Double // epoch millis, orijinaldeki Date.now() ile uyumlu

    init(text: String) {
        self.id = "m_" + String(Int(Date().timeIntervalSince1970 * 1000), radix: 36) + String(Int.random(in: 0..<1_000_000), radix: 36).prefix(4)
        self.text = text
        self.ts = Date().timeIntervalSince1970 * 1000
    }

    init(id: String, text: String, ts: Double) {
        self.id = id
        self.text = text
        self.ts = ts
    }

    var date: Date { Date(timeIntervalSince1970: ts / 1000) }
}

struct NoteEntry: Identifiable, Codable, Equatable {
    let id: String
    let text: String
    let ts: Double

    init(text: String) {
        self.id = "n_" + String(Int(Date().timeIntervalSince1970 * 1000), radix: 36)
        self.text = text
        self.ts = Date().timeIntervalSince1970 * 1000
    }
}

struct ReminderEntry: Identifiable {
    let id: String
    let text: String
    let fireAt: Date
    var workItem: DispatchWorkItem?

    init(text: String, fireAt: Date) {
        self.id = "r_" + String(Int(Date().timeIntervalSince1970 * 1000), radix: 36)
        self.text = text
        self.fireAt = fireAt
    }
}

struct CalendarEventEntry: Identifiable, Codable, Equatable {
    let id: String
    var title: String
    var date: String // "YYYY-MM-DD"
    var time: String? // "HH:MM"
    var notes: String
    let ts: Double

    init(title: String, date: String, time: String?, notes: String = "") {
        self.id = "e_" + String(Int(Date().timeIntervalSince1970 * 1000), radix: 36) + String(Int.random(in: 0..<1_000_000), radix: 36).prefix(4)
        self.title = title.isEmpty ? "Etkinlik" : title
        self.date = date
        self.time = (time?.isEmpty ?? true) ? nil : time
        self.notes = notes
        self.ts = Date().timeIntervalSince1970 * 1000
    }
}

/// classifyCommand() sonucu (JS'teki { type, action, payload, ... } nesnesi).
enum ParsedCommand {
    case ui(action: String)
    case memory(action: String, payload: String)
    case notes(action: String, payload: String)
    case reminder(minutes: Int, payload: String)
    case calculatorResult(payload: String, result: Double)
    case datetime(action: String)
    case websearch(payload: String)
    case weather(city: String?)
    case calendar(payload: String)
    case appOpen(name: String)
    case deviceOff(name: String)
    case gemini(payload: String)
}

/// Gemini API / ağ hataları için ortak hata tipi (JS'teki throw {code,message} karşılığı).
struct NEOError: LocalizedError, Identifiable {
    let id = UUID()
    let code: String
    let message: String
    /// Sunucunun "Retry-After" başlığından okunan, önerilen bekleme süresi
    /// (saniye). Yalnızca 429 (RATE_LIMIT) hatalarında dolu olabilir.
    var retryAfterSeconds: Int? = nil
    var errorDescription: String? { message }
}
