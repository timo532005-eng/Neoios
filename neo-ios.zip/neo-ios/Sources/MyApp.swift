import SwiftUI

// ════════════════════════════════════════════════════════════════
// Cloudflare Workers AI — Görsel Oluşturma Kimlik Bilgileri
// ════════════════════════════════════════════════════════════════
// "Görsel Oluştur" özelliği bu iki sabiti kullanır. Kendi Cloudflare
// hesabınızdaki değerlerle değiştirin:
//   • CLOUDFLARE_ACCOUNT_ID → Cloudflare panel > sağ kenar çubuğu
//     "Account ID" (dash.cloudflare.com üzerinden).
//   • CLOUDFLARE_API_TOKEN  → "Workers AI" için "Edit" (yazma) izniyle
//     oluşturulmuş bir API Token (dash.cloudflare.com/profile/api-tokens).
//
// API token'ı YALNIZCA burada bulunur; başka hiçbir dosyada
// tanımlanmaz veya kopyalanmaz.
let CLOUDFLARE_ACCOUNT_ID = "YOUR_ACCOUNT_ID"
let CLOUDFLARE_API_TOKEN = "YOUR_API_TOKEN"

@main
struct NEOApp: App {
    @StateObject private var engine = NEOEngine()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(engine)
                .preferredColorScheme(.dark)
        }
    }
}
