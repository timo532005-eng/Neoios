import SwiftUI

// ════════════════════════════════════════════════════════════════
// CalendarDrawerView.swift — #drawer-calendar (Apple Takvim tarzı ay
// görünümü) karşılığı — orijinal renderCalendar()/wireCalendar().
// ════════════════════════════════════════════════════════════════

struct CalendarDrawerView: View {
    @EnvironmentObject var engine: NEOEngine
    @Binding var isPresented: Bool
    @State private var newTitle = ""
    @State private var newDate = Date()
    @State private var newTime = Date()
    @State private var includeTime = false

    private var calendar: Calendar {
        var c = Calendar(identifier: .gregorian)
        c.locale = Locale(identifier: "tr_TR")
        c.firstWeekday = 2 // Pazartesi
        return c
    }

    private var monthLabel: String {
        let df = DateFormatter()
        df.locale = Locale(identifier: "tr_TR")
        df.dateFormat = "LLLL yyyy"
        return df.string(from: engine.calendarViewDate).capitalized
    }

    private var daysGrid: [Date] {
        guard let monthInterval = calendar.dateInterval(of: .month, for: engine.calendarViewDate) else { return [] }
        let firstOfMonth = monthInterval.start
        let weekday = calendar.component(.weekday, from: firstOfMonth) // 1=Sun..7=Sat
        let leading = (weekday - calendar.firstWeekday + 7) % 7
        guard let start = calendar.date(byAdding: .day, value: -leading, to: firstOfMonth) else { return [] }
        return (0..<42).compactMap { calendar.date(byAdding: .day, value: $0, to: start) }
    }

    private func iso(_ date: Date) -> String {
        let df = DateFormatter(); df.dateFormat = "yyyy-MM-dd"; df.timeZone = calendar.timeZone
        return df.string(from: date)
    }

    var body: some View {
        DrawerContainer(title: "Takvim", isPresented: $isPresented) {
            ScrollView {
                VStack(alignment: .leading, spacing: 14) {
                    // Ay navigasyonu
                    HStack {
                        Button(action: { shiftMonth(-1) }) { Image(systemName: "chevron.left") }
                        Spacer()
                        Text(monthLabel).font(NEOFont.display(14))
                        Spacer()
                        Button(action: { shiftMonth(1) }) { Image(systemName: "chevron.right") }
                    }
                    .foregroundStyle(engine.palette.text)

                    HStack {
                        ForEach(["Pzt", "Sal", "Çar", "Per", "Cum", "Cmt", "Paz"], id: \.self) { d in
                            Text(d).font(.system(size: 11)).foregroundStyle(engine.palette.textDim).frame(maxWidth: .infinity)
                        }
                    }

                    LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 7), spacing: 6) {
                        ForEach(daysGrid, id: \.self) { day in
                            dayCell(day)
                        }
                    }

                    Divider().overlay(engine.palette.panelBorder)

                    Text(NEOEngine.capitalizeTr(NEOEngine.formatDateTr(selectedISO)))
                        .font(NEOFont.display(13))
                        .foregroundStyle(engine.palette.secondary)

                    if dayEvents.isEmpty {
                        Text("Bu gün için etkinlik yok.")
                            .font(.system(size: 13))
                            .foregroundStyle(engine.palette.textDim)
                    } else {
                        VStack(spacing: 8) {
                            ForEach(dayEvents) { ev in
                                HStack {
                                    Text(ev.time ?? "Tüm gün")
                                        .font(NEOFont.mono(11))
                                        .foregroundStyle(engine.palette.primary)
                                        .frame(minWidth: 46, alignment: .leading)
                                    Text(ev.title).font(.system(size: 14)).foregroundStyle(engine.palette.text)
                                    Spacer()
                                    Button(action: { _ = engine.removeCalendarEvent(id: ev.id) }) {
                                        Image(systemName: "xmark").foregroundStyle(engine.palette.danger)
                                    }
                                }
                                .padding(10)
                                .background(engine.palette.panelBg)
                                .overlay(RoundedRectangle(cornerRadius: 10).stroke(engine.palette.panelBorder, lineWidth: 1))
                                .clipShape(RoundedRectangle(cornerRadius: 10))
                            }
                        }
                    }

                    Divider().overlay(engine.palette.panelBorder)

                    VStack(alignment: .leading, spacing: 8) {
                        KeyboardTextField("Etkinlik başlığı", text: $newTitle, palette: engine.palette)
                        HStack {
                            DatePicker("", selection: $newDate, displayedComponents: .date).labelsHidden()
                            Toggle("Saat belirt", isOn: $includeTime).toggleStyle(.switch).font(.system(size: 12))
                            if includeTime {
                                DatePicker("", selection: $newTime, displayedComponents: .hourAndMinute).labelsHidden()
                            }
                            Button(action: addEvent) {
                                Image(systemName: "plus").foregroundStyle(Color(hex: 0x04080a))
                                    .frame(width: 40, height: 40)
                                    .background(LinearGradient(colors: [engine.palette.primary, engine.palette.secondary], startPoint: .leading, endPoint: .trailing))
                                    .clipShape(RoundedRectangle(cornerRadius: 10))
                            }
                        }
                    }

                    FieldHint(text: "NEO'ya sesli veya yazılı olarak da doğrudan söyleyebilirsiniz: \"yarın saat 15:00'te toplantı ekle\", \"bugün bir etkinliğim var mı\" gibi. Doğal dil komutları için Ayarlar > AI bölümünde bir Gemini API anahtarı gerekir.")
                }
                .padding(16)
            }
        }
        .onAppear {
            if engine.calendarSelectedDate == nil { engine.calendarSelectedDate = NEOEngine.todayISO() }
            newDate = Date()
        }
    }

    private var selectedISO: String { engine.calendarSelectedDate ?? NEOEngine.todayISO() }
    private var dayEvents: [CalendarEventEntry] { engine.events(for: selectedISO) }

    private func shiftMonth(_ delta: Int) {
        if let d = calendar.date(byAdding: .month, value: delta, to: engine.calendarViewDate) {
            engine.calendarViewDate = d
        }
    }

    private func dayCell(_ day: Date) -> some View {
        let inMonth = calendar.isDate(day, equalTo: engine.calendarViewDate, toGranularity: .month)
        let dayISO = iso(day)
        let isToday = dayISO == NEOEngine.todayISO()
        let isSelected = dayISO == selectedISO
        let hasEvents = !engine.events(for: dayISO).isEmpty

        return Button(action: { engine.calendarSelectedDate = dayISO }) {
            VStack(spacing: 3) {
                Text("\(calendar.component(.day, from: day))")
                    .font(.system(size: 13, weight: isToday ? .bold : .regular))
                    .foregroundStyle(inMonth ? engine.palette.text : engine.palette.textDim.opacity(0.5))
                Circle()
                    .fill(hasEvents ? engine.palette.primary : .clear)
                    .frame(width: 4, height: 4)
            }
            .frame(maxWidth: .infinity, minHeight: 34)
            .background(isSelected ? engine.palette.primary.opacity(0.2) : (isToday ? engine.palette.panelBg : .clear))
            .overlay(RoundedRectangle(cornerRadius: 8).stroke(isSelected ? engine.palette.primary : .clear, lineWidth: 1))
            .clipShape(RoundedRectangle(cornerRadius: 8))
        }
        .buttonStyle(.plain)
    }

    private func addEvent() {
        let title = newTitle.trimmingCharacters(in: .whitespaces)
        guard !title.isEmpty else { return }
        let df = DateFormatter(); df.dateFormat = "yyyy-MM-dd"
        let dateStr = df.string(from: newDate)
        var timeStr: String? = nil
        if includeTime {
            let tf = DateFormatter(); tf.dateFormat = "HH:mm"
            timeStr = tf.string(from: newTime)
        }
        let entry = engine.addCalendarEvent(title: title, date: dateStr, time: timeStr)
        newTitle = ""
        engine.calendarSelectedDate = entry.date
        engine.calendarViewDate = newDate
    }
}
