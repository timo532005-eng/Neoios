import SwiftUI

// ════════════════════════════════════════════════════════════════
// HUDView.swift — HUDCanvasView'in (radar taraması, eşitleyici
// çubuklar, parçacıklar) üzerine bindirilen, dokunulabilir merkez
// "çekirdek": durum rengiyle parlayan bir küre + durum ikonu.
// Dokununca mikrofonu açar/kapatır (engine.toggleListening()).
// ════════════════════════════════════════════════════════════════

struct HUDView: View {
    @EnvironmentObject var engine: NEOEngine
    @State private var pulse = false

    private var stateColor: Color {
        switch engine.state {
        case .idle: return engine.palette.primary
        case .listening: return engine.palette.accent
        case .thinking: return engine.palette.secondary
        case .speaking: return engine.palette.primary
        case .error: return engine.palette.danger
        }
    }

    private var intensity: Double { engine.hudIntensity.multiplier }

    /// Dinlerken/konuşurken mikrofon veya TTS genliğine göre 0...1
    /// aralığında bir tepki seviyesi; diğer durumlarda sabit 0.
    private var reactiveLevel: Double {
        switch engine.state {
        case .listening, .speaking: return engine.volume
        default: return 0
        }
    }

    private var coreIcon: String {
        switch engine.state {
        case .idle: return "mic"
        case .listening: return "mic.fill"
        case .thinking: return "ellipsis"
        case .speaking: return "waveform"
        case .error: return "exclamationmark.triangle"
        }
    }

    var body: some View {
        Button(action: { engine.toggleListening() }) {
            ZStack {
                // Yumuşak parlama (glow) — ses genliğine göre büyür.
                Circle()
                    .fill(RadialGradient(colors: [stateColor.opacity(0.85 * intensity), stateColor.opacity(0.12), .clear], center: .center, startRadius: 2, endRadius: 90))
                    .frame(width: 150, height: 150)
                    .blur(radius: 10)
                    .scaleEffect(1 + reactiveLevel * 0.22)
                    .animation(.easeOut(duration: 0.12), value: engine.volume)

                // İnce dış çerçeve — hafifçe nabız gibi atar, sese göre genişler.
                Circle()
                    .strokeBorder(stateColor.opacity(0.55), lineWidth: 2)
                    .frame(width: 100, height: 100)
                    .scaleEffect(1 + reactiveLevel * 0.10 + (pulse ? 0.02 : 0))
                    .animation(engine.animationsEnabled ? .easeInOut(duration: 2.2).repeatForever(autoreverses: true) : nil, value: pulse)
                    .animation(.easeOut(duration: 0.12), value: engine.volume)

                // Merkez disk + durum ikonu.
                Circle()
                    .fill(engine.palette.bgDeep)
                    .frame(width: 92, height: 92)
                    .overlay(Circle().stroke(stateColor.opacity(0.7), lineWidth: 1.5))

                Image(systemName: coreIcon)
                    .font(.system(size: 30, weight: .regular))
                    .foregroundStyle(stateColor)
            }
            .shadow(color: stateColor.opacity(0.5 * intensity), radius: 20)
            .animation(.easeInOut(duration: 0.25), value: engine.state)
        }
        .buttonStyle(.plain)
        .onAppear { pulse = true }
    }
}
