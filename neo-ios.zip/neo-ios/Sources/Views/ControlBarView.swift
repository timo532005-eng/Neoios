import SwiftUI
import PhotosUI

// ════════════════════════════════════════════════════════════════
// ControlBarView.swift — tek satır: solda görsel/dosya eklemek için
// bir "+" düğmesi, ortada serbest metin kutusu, sağda gönder düğmesi
// ve hemen yanında minimalist bir kamera düğmesi. Konuşma yukarıdaki
// HUD'a dokunarak da başlatılabilir (bkz. HUDView); yazılı mesaj ise
// burada gönderilir — ikisi de aynı komut işleme hattından
// (engine.sendMessage) geçer.
//
// AI MODLARI: metin kutusuna "@" yazılınca (cümlenin herhangi bir
// yerinde, en sonda açık/kapanmamış bir "@..." varken) kutunun hemen
// üstünde bir mod seçici popup açılır (bkz. modePickerPopup). "@"'den
// sonra yazılan harfler listeyi filtreler. Bir mod seçilince o "@..."
// metinden silinir, seçili mod küçük bir "chip" olarak gösterilir ve
// gönderilen SONRAKİ (tek) mesaj o moda göre işlenir (bkz.
// NEOEngine.sendMessageWithMode).
// ════════════════════════════════════════════════════════════════

struct ControlBarView: View {
    @EnvironmentObject var engine: NEOEngine
    @State private var photoItem: PhotosPickerItem? = nil
    @State private var messageText: String = ""
    @State private var showModePicker = false
    @State private var modeFilter = ""
    @State private var selectedMode: AIMode? = nil
    @Binding var showCameraDrawer: Bool

    private var canSend: Bool { !messageText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }

    private var filteredModes: [AIMode] {
        guard !modeFilter.isEmpty else { return AIMode.allCases }
        return AIMode.allCases.filter { mode in
            mode.label.localizedCaseInsensitiveContains(modeFilter)
                || mode.keywords.contains { $0.localizedCaseInsensitiveContains(modeFilter) }
        }
    }

    /// messageText'in SONUNDA, aralarında boşluk olmayan açık bir
    /// "@filtre" var mı diye bakar (ör. "merhaba @gör" → "gör").
    /// Yoksa nil döner ve popup kapanır.
    private func trailingMention(in text: String) -> String? {
        guard let atIndex = text.lastIndex(of: "@") else { return nil }
        let after = text[text.index(after: atIndex)...]
        guard !after.contains(where: { $0.isWhitespace }) else { return nil }
        return String(after)
    }

    private func pickMode(_ mode: AIMode) {
        if let atIndex = messageText.lastIndex(of: "@") {
            messageText.removeSubrange(atIndex...)
        }
        selectedMode = mode
        showModePicker = false
        modeFilter = ""
    }

    private func send() {
        let text = messageText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return }
        if let mode = selectedMode {
            engine.sendMessageWithMode(text, mode: mode)
        } else {
            engine.sendMessage(text)
        }
        messageText = ""
        selectedMode = nil
        showModePicker = false
    }

    var body: some View {
        VStack(spacing: 8) {
            if showModePicker {
                modePickerPopup
            } else if let mode = selectedMode {
                modeChip(mode)
            }

            HStack(spacing: 10) {
                // Görsel/dosya ekleme — "+" düğmesi.
                PhotosPicker(selection: $photoItem, matching: .any(of: [.images, .videos])) {
                    Image(systemName: "plus")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundStyle(engine.palette.text)
                        .frame(width: 40, height: 40)
                        .background(engine.palette.panelBg)
                        .overlay(Circle().stroke(engine.palette.panelBorder, lineWidth: 1))
                        .clipShape(Circle())
                }
                .onChange(of: photoItem) { newItem in
                    guard let newItem else { return }
                    Task {
                        if let data = try? await newItem.loadTransferable(type: Data.self) {
                            await engine.analyzeAttachedImage(data)
                        }
                        photoItem = nil
                    }
                }

                KeyboardTextField(
                    text: $messageText,
                    placeholder: "Bir şeyler yazın… (\"@\" ile AI modları)",
                    textColor: engine.palette.text,
                    placeholderColor: engine.palette.textDim,
                    borderColor: engine.palette.panelBorder,
                    onSubmit: { send() },
                    onFocusChange: { focused in
                        // Yazarken arkadaki HUD animasyonunu durdurur (bkz.
                        // HUDCanvasView) — sürekli çizim ana iş parçacığını
                        // meşgul edip klavye olaylarının gecikmesine/kaybolmasına
                        // yol açabiliyordu.
                        engine.isTyping = focused
                    }
                )
                .frame(height: 40)
                .onChange(of: messageText) { newValue in
                    if let mention = trailingMention(in: newValue) {
                        modeFilter = mention
                        showModePicker = true
                    } else {
                        showModePicker = false
                    }
                }

                Button(action: send) {
                    Image(systemName: "paperplane.fill")
                        .font(.system(size: 17))
                        .foregroundStyle(engine.palette.bgDeep)
                        .frame(width: 40, height: 40)
                        .background(canSend ? engine.palette.primary : engine.palette.panelBorder)
                        .clipShape(Circle())
                }
                .disabled(!canSend)

                // Kamera — minimalist, ikon-only, gönder düğmesinin hemen sağında.
                Button(action: { showCameraDrawer = true }) {
                    Image(systemName: "camera")
                        .font(.system(size: 16))
                        .foregroundStyle(engine.palette.textDim)
                        .frame(width: 32, height: 32)
                }
            }
        }
        .padding(.horizontal, 16)
        .padding(.bottom, 14)
        .padding(.top, 4)
    }

    private var modePickerPopup: some View {
        VStack(alignment: .leading, spacing: 2) {
            if filteredModes.isEmpty {
                Text("Eşleşen mod yok")
                    .font(.system(size: 13))
                    .foregroundStyle(engine.palette.textDim)
                    .padding(10)
            } else {
                ForEach(filteredModes) { mode in
                    Button(action: { pickMode(mode) }) {
                        HStack(spacing: 10) {
                            Image(systemName: mode.icon)
                                .font(.system(size: 15))
                                .foregroundStyle(engine.palette.primary)
                                .frame(width: 22)
                            VStack(alignment: .leading, spacing: 1) {
                                Text(mode.label)
                                    .font(.system(size: 14, weight: .medium))
                                    .foregroundStyle(engine.palette.text)
                                Text(mode.hint)
                                    .font(.system(size: 11))
                                    .foregroundStyle(engine.palette.textDim)
                                    .lineLimit(1)
                            }
                            Spacer(minLength: 0)
                        }
                        .padding(.horizontal, 10)
                        .padding(.vertical, 8)
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                }
            }
        }
        .background(engine.palette.panelBg)
        .overlay(RoundedRectangle(cornerRadius: 10).stroke(engine.palette.panelBorder, lineWidth: 1))
        .clipShape(RoundedRectangle(cornerRadius: 10))
    }

    private func modeChip(_ mode: AIMode) -> some View {
        HStack(spacing: 6) {
            Image(systemName: mode.icon).font(.system(size: 11))
            Text(mode.label).font(.system(size: 12, weight: .medium))
            Button(action: { selectedMode = nil }) {
                Image(systemName: "xmark.circle.fill").font(.system(size: 13))
            }
            .buttonStyle(.plain)
        }
        .foregroundStyle(engine.palette.primary)
        .padding(.horizontal, 10)
        .padding(.vertical, 5)
        .background(engine.palette.primary.opacity(0.12))
        .overlay(Capsule().stroke(engine.palette.primary.opacity(0.4), lineWidth: 1))
        .clipShape(Capsule())
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}
