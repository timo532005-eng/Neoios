import SwiftUI

// ════════════════════════════════════════════════════════════════
// CoreView.swift — merkezdeki HUD'un (arkada HUDCanvasView'in radar/
// parçacık animasyonu, üstte HUDView'in dokunulabilir çekirdeği)
// altında durum etiketi ve varsa canlı konuşma metnini gösterir.
// ════════════════════════════════════════════════════════════════

struct CoreView: View {
    @EnvironmentObject var engine: NEOEngine
    /// true iken (bir çekmece açıkken) arkadaki HUD animasyonu tamamen
    /// durur — hem gereksiz görünmez çizimi önler hem de ana iş
    /// parçacığını, çekmecedeki metin kutularının klavye olaylarını
    /// zamanında işleyebilmesi için serbest bırakır.
    var reduceMotion: Bool = false

    private var stateColor: Color {
        switch engine.state {
        case .idle: return engine.palette.primary
        case .listening: return engine.palette.accent
        case .thinking: return engine.palette.secondary
        case .speaking: return engine.palette.primary
        case .error: return engine.palette.danger
        }
    }

    var body: some View {
        VStack(spacing: 14) {
            ZStack {
                HUDCanvasView(reduceMotion: reduceMotion || engine.isTyping)
                    .frame(width: 340, height: 340)
                HUDView()
            }
            .padding(20)

            Text(engine.stateLabel)
                .font(NEOFont.display(13))
                .tracking(4)
                .foregroundStyle(stateColor)
                .shadow(color: stateColor.opacity(0.5), radius: 10)

            Text(engine.liveTranscript)
                .font(NEOFont.mono(13))
                .foregroundStyle(engine.palette.textDim)
                .frame(minHeight: 20)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 20)
        }
    }
}
