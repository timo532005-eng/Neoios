import SwiftUI

// ════════════════════════════════════════════════════════════════
// ProfileDrawerView.swift — "Profilim" çekmecesi: NEO'yu bir hayat
// asistanına dönüştüren kişiselleştirme formu. Buradaki her alan
// engine.userProfile'a doğrudan bağlıdır (yazdıkça bu cihazda saklanır)
// ve NEOEngine.buildSystemPrompt() üzerinden her Gemini isteğine
// eklenir — yani NEO artık bu bilgileri "bilerek" cevap verir.
// ════════════════════════════════════════════════════════════════

struct ProfileDrawerView: View {
    @EnvironmentObject var engine: NEOEngine
    @Binding var isPresented: Bool
    @State private var showResetConfirm = false

    var body: some View {
        DrawerContainer(title: "Profilim", isPresented: $isPresented) {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    FieldHint(text: "Buraya girdiğin bilgileri NEO, seninle her konuşmasında hesaba katar — sana ismiyle hitap edebilir, ilgi alanlarına ve hedeflerine uygun öneriler verebilir. Tamamen isteğe bağlıdır, hiçbir alan zorunlu değil, ve tamamen bu cihazda saklanır.")

                    Group {
                        SectionHeader(text: "Kimlik")

                        FieldLabel(text: "Adın")
                        KeyboardTextField("ör. Ahmet", text: $engine.userProfile.name, palette: engine.palette)

                        FieldLabel(text: "Sana nasıl hitap etsin? (boşsa adını kullanır)")
                        KeyboardTextField("ör. Hocam, Kaptan, Ahmetcim…", text: $engine.userProfile.nickname, palette: engine.palette)

                        FieldLabel(text: "Meslek / uğraş")
                        KeyboardTextField("ör. Yazılım mühendisi, üniversite öğrencisi…", text: $engine.userProfile.occupation, palette: engine.palette)
                    }

                    Group {
                        SectionHeader(text: "Hayat")

                        FieldLabel(text: "İlgi alanların")
                        KeyboardTextField("ör. koşu, gitar, bilim kurgu, kahve", text: $engine.userProfile.interests, palette: engine.palette)

                        FieldLabel(text: "Hedeflerin")
                        KeyboardTextField("ör. Almanca öğrenmek, düzenli spor yapmak", text: $engine.userProfile.goals, palette: engine.palette)

                        FieldLabel(text: "Günlük rutinin")
                        KeyboardTextField("ör. hafta içi 09:00-18:00 çalışıyorum, akşamları spor", text: $engine.userProfile.routineNotes, palette: engine.palette)

                        FieldLabel(text: "Eklemek istediğin başka bir şey")
                        KeyboardTextField("NEO'nun bilmesini istediğin herhangi bir şey", text: $engine.userProfile.extraNotes, palette: engine.palette)
                    }

                    Group {
                        SectionHeader(text: "Konuşma Tarzı")
                        Picker("", selection: $engine.userProfile.communicationStyle) {
                            ForEach(CommunicationStyle.allCases, id: \.self) { style in
                                Text(style.label).tag(style)
                            }
                        }
                        .pickerStyle(.segmented)
                        FieldHint(text: "NEO'nun seninle nasıl konuşacağını belirler.")
                    }

                    if !engine.userProfile.isEmpty {
                        Button("Profili Sıfırla") { showResetConfirm = true }
                            .buttonStyle(NEOTextButtonStyle())
                            .foregroundStyle(engine.palette.danger)
                    }
                }
                .padding(16)
            }
        }
        .alert("Profili sıfırla", isPresented: $showResetConfirm) {
            Button("Vazgeç", role: .cancel) {}
            Button("Sıfırla", role: .destructive) { engine.userProfile = UserProfile() }
        } message: {
            Text("Girdiğin tüm profil bilgileri silinecek. Bu işlem geri alınamaz.")
        }
    }
}
