import SwiftUI

// ════════════════════════════════════════════════════════════════
// TopBarAndMenu.swift — .topbar / .brand-* / .menu-popup karşılığı.
// ════════════════════════════════════════════════════════════════

struct TopBarView: View {
    @EnvironmentObject var engine: NEOEngine
    @Binding var menuOpen: Bool

    var body: some View {
        HStack {
            HStack(spacing: 12) {
                Circle()
                    .fill(AngularGradient(colors: [engine.palette.primary, engine.palette.secondary, engine.palette.primary], center: .center))
                    .frame(width: 30, height: 30)
                    .overlay(Circle().fill(engine.palette.bg).padding(6))
                    .shadow(color: engine.palette.primarySoft, radius: 10)
                VStack(alignment: .leading, spacing: 0) {
                    Text("NEO")
                        .font(NEOFont.display(20, weight: .black))
                        .tracking(3)
                        .foregroundStyle(engine.palette.text)
                    Text("ANALYZE · ADAPT · EXECUTE · RESPOND")
                        .font(NEOFont.mono(9))
                        .tracking(2)
                        .foregroundStyle(engine.palette.textDim)
                }
            }
            Spacer()
            Button(action: { withAnimation(.easeOut(duration: 0.18)) { menuOpen.toggle() } }) {
                Image(systemName: "line.3.horizontal")
                    .foregroundStyle(engine.palette.textDim)
                    .frame(width: 40, height: 40)
                    .background(engine.palette.panelBg)
                    .overlay(RoundedRectangle(cornerRadius: 10).stroke(engine.palette.panelBorder, lineWidth: 1))
                    .clipShape(RoundedRectangle(cornerRadius: 10))
            }
        }
        .padding(.horizontal, 18)
        .padding(.vertical, 14)
    }
}

enum MenuTarget: String { case calendar, camera, notes, memory, chat, settings, imageGen, transcribe, profile, share }

struct MenuPopupView: View {
    @EnvironmentObject var engine: NEOEngine
    @Binding var isOpen: Bool
    var onSelect: (MenuTarget) -> Void

    private let items: [(MenuTarget, String, String)] = [
        (.profile, "person.crop.circle", "Profilim"),
        (.calendar, "calendar", "Takvim"),
        (.camera, "camera", "Kamera"),
        (.imageGen, "wand.and.stars", "Görsel Oluştur"),
        (.transcribe, "waveform", "Ses Kaydından Yazıya Çevir"),
        (.notes, "note.text", "Notlar"),
        (.memory, "brain", "Hafıza"),
        (.chat, "bubble.left.and.bubble.right", "Sohbet Geçmişi"),
        (.share, "qrcode", "Paylaşım"),
        (.settings, "gearshape", "Ayarlar"),
    ]

    var body: some View {
        if isOpen {
            VStack(alignment: .leading, spacing: 2) {
                ForEach(items, id: \.0) { item in
                    Button(action: {
                        withAnimation(.easeOut(duration: 0.15)) { isOpen = false }
                        onSelect(item.0)
                    }) {
                        HStack(spacing: 12) {
                            Image(systemName: item.1).frame(width: 18)
                            Text(item.2).lineLimit(1).minimumScaleFactor(0.8)
                            Spacer()
                        }
                        .font(.system(size: 14))
                        .foregroundStyle(engine.palette.text)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 11)
                    }
                }
            }
            .frame(width: 260)
            .background(
                LinearGradient(colors: [Color(hex: 0x0e141a).opacity(0.98), Color(hex: 0x080c10).opacity(0.98)], startPoint: .top, endPoint: .bottom)
            )
            .overlay(RoundedRectangle(cornerRadius: 14).stroke(engine.palette.panelBorder, lineWidth: 1))
            .clipShape(RoundedRectangle(cornerRadius: 14))
            .shadow(radius: 20)
            .transition(.opacity.combined(with: .move(edge: .top)))
            .zIndex(70)
        }
    }
}
