import SwiftUI

// ════════════════════════════════════════════════════════════════
// CameraDrawerView.swift — #drawer-camera karşılığı.
// ════════════════════════════════════════════════════════════════

struct CameraDrawerView: View {
    @EnvironmentObject var engine: NEOEngine
    @Binding var isPresented: Bool
    @State private var prompt = ""
    @State private var analyzing = false

    var body: some View {
        DrawerContainer(title: "Kamera", isPresented: $isPresented) {
            ScrollView {
                VStack(spacing: 14) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 12).fill(Color.black)
                        if engine.camera.isRunning {
                            CameraPreviewView(session: engine.camera.session)
                                .clipShape(RoundedRectangle(cornerRadius: 12))
                        }
                    }
                    .aspectRatio(4.0/3.0, contentMode: .fit)
                    .overlay(RoundedRectangle(cornerRadius: 12).stroke(engine.palette.panelBorder, lineWidth: 1))
                    .padding(.horizontal, 16)
                    .padding(.top, 12)

                    FieldHint(text: engine.camera.statusHint)
                        .padding(.horizontal, 16)

                    VStack(alignment: .leading, spacing: 6) {
                        FieldLabel(text: "Neyi analiz etmemi istersiniz? (opsiyonel)")
                        KeyboardTextField("Örn: Bu nedir, açıklar mısın?", text: $prompt, palette: engine.palette)
                    }
                    .padding(.horizontal, 16)

                    HStack(spacing: 10) {
                        Button(analyzing ? "Analiz ediliyor…" : "Çek ve Analiz Et") {
                            analyzing = true
                            Task {
                                await engine.captureAndAnalyze(promptOverride: prompt)
                                analyzing = false
                                isPresented = false
                            }
                        }
                        .buttonStyle(NEOPrimaryButtonStyle())
                        .disabled(analyzing || !engine.camera.isRunning)

                        Button("Kamerayı Değiştir") { engine.camera.switchCamera() }
                            .buttonStyle(NEOTextButtonStyle())
                    }
                    .padding(.horizontal, 16)
                    .padding(.bottom, 16)
                }
            }
        }
        .onAppear { engine.camera.start() }
        .onDisappear { engine.camera.stop() }
    }
}

// ════════════════════════════════════════════════════════════════
// AppLaunchModalView.swift — #app-launch-modal karşılığı.
// ════════════════════════════════════════════════════════════════

struct AppLaunchModalView: View {
    @EnvironmentObject var engine: NEOEngine

    var body: some View {
        if engine.showAppLaunchModal, let app = engine.pendingAppLaunch {
            ZStack {
                Color.black.opacity(0.6).ignoresSafeArea()
                    .onTapGesture { engine.showAppLaunchModal = false; engine.pendingAppLaunch = nil }

                VStack(spacing: 10) {
                    Text("⧉").font(.system(size: 34)).foregroundStyle(engine.palette.primary)
                    Text(app.label).font(NEOFont.display(16)).foregroundStyle(engine.palette.text)
                    Text(app.scheme != nil || app.webUrl != nil
                         ? "Cihazınızda yüklüyse uygulama açılmaya çalışılacak; yüklü değilse veya izin verilmezse web sürümüne yönlendirileceksiniz."
                         : "Bu uygulama için tanımlı bir bağlantım yok; cihazınızda elle açmanız gerekebilir.")
                        .font(.system(size: 12.5))
                        .foregroundStyle(engine.palette.textDim)
                        .multilineTextAlignment(.center)
                        .padding(.bottom, 8)

                    Button("Aç") { engine.triggerAppLaunch() }
                        .buttonStyle(NEOPrimaryButtonStyle())
                    Button("Kapat") { engine.showAppLaunchModal = false; engine.pendingAppLaunch = nil }
                        .buttonStyle(NEOTextButtonStyle())
                }
                .padding(24)
                .frame(width: min(320, UIScreen.main.bounds.width * 0.92))
                .background(LinearGradient(colors: [Color(hex: 0x0e141a).opacity(0.98), Color(hex: 0x080c10).opacity(0.98)], startPoint: .top, endPoint: .bottom))
                .overlay(RoundedRectangle(cornerRadius: 18).stroke(engine.palette.panelBorder, lineWidth: 1))
                .clipShape(RoundedRectangle(cornerRadius: 18))
                .shadow(radius: 30)
            }
            .zIndex(90)
            .transition(.opacity)
        }
    }
}

// ════════════════════════════════════════════════════════════════
// ToastView.swift — #toast karşılığı.
// ════════════════════════════════════════════════════════════════

struct ToastView: View {
    @EnvironmentObject var engine: NEOEngine
    var body: some View {
        if let msg = engine.toastMessage {
            VStack {
                Spacer()
                Text(msg)
                    .font(.system(size: 14))
                    .foregroundStyle(Color(hex: 0xffd9dd))
                    .padding(.horizontal, 18)
                    .padding(.vertical, 12)
                    .background(Color(red: 0.078, green: 0.039, blue: 0.047).opacity(0.95))
                    .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color(hex: 0xff4d5e).opacity(0.4), lineWidth: 1))
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .padding(.bottom, 90)
                    .frame(maxWidth: 420)
            }
            .transition(.move(edge: .bottom).combined(with: .opacity))
            .zIndex(100)
        }
    }
}
