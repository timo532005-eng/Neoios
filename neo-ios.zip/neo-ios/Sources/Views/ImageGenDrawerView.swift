import SwiftUI

// ════════════════════════════════════════════════════════════════
// ImageGenDrawerView.swift — YENİ ÖZELLİK: Görsel Oluştur.
// Gemini'nin görsel-üretim destekli modelini (Ayarlar > AI > Görsel
// Modeli) kullanarak metinden görsel üretir.
// ════════════════════════════════════════════════════════════════

struct ImageGenDrawerView: View {
    @EnvironmentObject var engine: NEOEngine
    @Binding var isPresented: Bool
    @StateObject private var vm = ImageGenViewModel()
    @State private var showSavedToast = false

    private var buttonLabel: String {
        if vm.state == .working { return "Oluşturuluyor…" }
        if vm.cooldownSecondsRemaining > 0 { return "Tekrar deneyin (\(vm.cooldownSecondsRemaining)sn)" }
        return "Oluştur"
    }

    var body: some View {
        DrawerContainer(title: "Görsel Oluştur", isPresented: $isPresented) {
            ScrollView {
                VStack(alignment: .leading, spacing: 14) {
                    FieldHint(text: "İstediğiniz görseli tarif edin (Türkçe yazabilirsiniz — Gemini API anahtarınız varsa gönderilmeden önce otomatik olarak İngilizceye çevrilir, çünkü görsel modelleri esas olarak İngilizce eğitildi). Cloudflare Workers AI (FLUX/SDXL) sizin için üretsin.")

                    KeyboardTextField("Örn: Neon ışıklarla aydınlanmış, yağmurlu bir gece şehri, siber-punk tarzında", text: $vm.prompt, palette: engine.palette)

                    Button(action: { vm.generate(engine: engine) }) {
                        HStack {
                            if vm.state == .working { ProgressView().tint(Color(hex: 0x04080a)) }
                            Text(buttonLabel)
                        }
                        .font(NEOFont.display(12)).tracking(1.5)
                    }
                    .buttonStyle(NEOPrimaryButtonStyle())
                    .disabled(vm.state == .working || vm.cooldownSecondsRemaining > 0 || vm.prompt.trimmingCharacters(in: .whitespaces).isEmpty)

                    if case .failed(let msg) = vm.state {
                        FieldHint(text: msg, warning: true)
                    }

                    if let translated = vm.translatedPromptUsed {
                        FieldHint(text: "Cloudflare'e gönderilen İngilizce prompt: \"\(translated)\"")
                    }

                    if let image = vm.resultImage {
                        Image(uiImage: image)
                            .resizable()
                            .scaledToFit()
                            .clipShape(RoundedRectangle(cornerRadius: 12))
                            .overlay(RoundedRectangle(cornerRadius: 12).stroke(engine.palette.panelBorder, lineWidth: 1))

                        HStack(spacing: 10) {
                            Button("Fotoğraflara Kaydet") {
                                vm.saveToPhotos()
                                showSavedToast = true
                                DispatchQueue.main.asyncAfter(deadline: .now() + 2) { showSavedToast = false }
                            }
                            .buttonStyle(NEOTextButtonStyle())

                            Button("Yeniden Oluştur") { vm.generate(engine: engine) }
                                .buttonStyle(NEOTextButtonStyle())
                                .disabled(vm.state == .working || vm.cooldownSecondsRemaining > 0)
                        }

                        if showSavedToast {
                            Text("Fotoğraflar'a kaydedildi.")
                                .font(.system(size: 12))
                                .foregroundStyle(engine.palette.primary)
                        }
                    }
                }
                .padding(16)
            }
        }
        // ÖNEMLİ: .onAppear DEĞİL, .onChange kullanıyoruz. DrawerContainer
        // uygulama açılırken bir kez oluşturulup hep hiyerarşide kalıyor
        // (yalnızca içeriği isPresented'a göre gösteriliyor), bu yüzden
        // .onAppear sadece uygulama açılışında (bekleyen prompt yokken)
        // çalışıyor, çekmece her açıldığında DEĞİL — "gönderdim diyor ama
        // hiçbir şey yapmıyor" hatasının sebebi buydu. vm (StateObject) de
        // çekmece kapalıyken bile yaşadığı için, prompt atandığı an üretim
        // güvenle başlatılabiliyor; çekmece açılınca ilerleme/sonuç zaten
        // görünür.
        .onChange(of: engine.pendingImagePrompt) { newValue in
            // AI modları > Görsel Oluştur üzerinden gönderilen prompt
            // (bkz. ControlBarView + NEOEngine.sendMessageWithMode).
            guard let pending = newValue else { return }
            engine.pendingImagePrompt = nil
            vm.prompt = pending
            vm.generate(engine: engine)
        }
    }
}
