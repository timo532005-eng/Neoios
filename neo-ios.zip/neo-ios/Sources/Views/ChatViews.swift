import SwiftUI
import UIKit

// ════════════════════════════════════════════════════════════════
// ChatViews.swift — .chat-msg / .bubble / .chat-inline / sohbet
// geçmişi çekmecesi karşılığı.
// ════════════════════════════════════════════════════════════════

struct ChatBubbleView: View {
    let message: ChatMessage
    @EnvironmentObject var engine: NEOEngine

    var body: some View {
        VStack(alignment: message.role == .user ? .trailing : .leading, spacing: 3) {
            Text(message.role == .user ? "KULLANICI" : "NEO")
                .font(NEOFont.mono(10))
                .tracking(1.5)
                .foregroundStyle(message.role == .user ? engine.palette.accent : engine.palette.primary)
            VStack(alignment: .leading, spacing: 8) {
                if let data = message.imageData {
                    ChatImageView(data: data)
                }
                Text(message.text)
                    .font(NEOFont.body(14.5))
                    .foregroundStyle(message.isError ? Color(hex: 0xffb9c0) : engine.palette.text)
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 10)
            .background(engine.palette.panelBg)
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(message.isError ? Color(hex: 0xff4d5e).opacity(0.4) : (message.role == .user ? Color(hex: 0xffb454).opacity(0.3) : engine.palette.panelBorder), lineWidth: 1)
            )
            .clipShape(RoundedRectangle(cornerRadius: 12))
        }
        .frame(maxWidth: .infinity, alignment: message.role == .user ? .trailing : .leading)
    }
}

/// Sohbet balonundaki üretilmiş görsel; her çizimde yeniden çözümlememek
/// için UIImage'ı bir kez çözüp saklar.
private struct ChatImageView: View {
    let data: Data
    @State private var image: UIImage? = nil

    var body: some View {
        Group {
            if let image {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
                    .frame(maxWidth: 280)
                    .clipShape(RoundedRectangle(cornerRadius: 8))
            } else {
                ProgressView()
            }
        }
        .onAppear { if image == nil { image = UIImage(data: data) } }
    }
}

struct ChatInlineView: View {
    @EnvironmentObject var engine: NEOEngine

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Text("SOHBET GEÇMİŞİ")
                    .font(NEOFont.mono(10))
                    .tracking(1.5)
                    .foregroundStyle(engine.palette.textDim)
                Spacer()
                Button("Temizle") { engine.clearChat() }
                    .font(.system(size: 11))
                    .foregroundStyle(engine.palette.primary)
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
            Divider().overlay(engine.palette.panelBorder)

            ScrollViewReader { proxy in
                ScrollView {
                    if engine.chatMessages.isEmpty {
                        Text("Henüz mesaj yok. Yazın veya mikrofona basın.")
                            .font(.system(size: 13))
                            .foregroundStyle(engine.palette.textDim)
                            .padding()
                    } else {
                        LazyVStack(spacing: 10) {
                            ForEach(engine.chatMessages) { msg in
                                ChatBubbleView(message: msg).id(msg.id)
                            }
                        }
                        .padding(12)
                    }
                }
                .onChange(of: engine.chatMessages.count) { _ in
                    if let last = engine.chatMessages.last {
                        withAnimation { proxy.scrollTo(last.id, anchor: .bottom) }
                    }
                }
            }
        }
        .background(engine.palette.panelBg)
        .overlay(RoundedRectangle(cornerRadius: 14).stroke(engine.palette.panelBorder, lineWidth: 1))
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }
}

struct ChatHistoryDrawerView: View {
    @EnvironmentObject var engine: NEOEngine
    @Binding var isPresented: Bool

    var body: some View {
        DrawerContainer(title: "Sohbet Geçmişi", isPresented: $isPresented, trailing: {
            Button("Temizle") { engine.clearChat() }
                .font(.system(size: 13))
                .foregroundStyle(engine.palette.primary)
        }) {
            ScrollView {
                if engine.chatMessages.isEmpty {
                    Text("Henüz mesaj yok.")
                        .foregroundStyle(engine.palette.textDim)
                        .padding()
                } else {
                    LazyVStack(spacing: 12) {
                        ForEach(engine.chatMessages) { msg in
                            ChatBubbleView(message: msg)
                        }
                    }
                    .padding(16)
                }
            }
        }
    }
}
