import SwiftUI

// ════════════════════════════════════════════════════════════════
// SettingsDrawerView.swift — orijinal #drawer-settings karşılığı.
// AI / Ses / Arayüz / Konum & Hava Durumu / Hafıza bölümleri.
// ════════════════════════════════════════════════════════════════

struct FieldLabel: View {
    let text: String
    @EnvironmentObject var engine: NEOEngine
    var body: some View {
        Text(text).font(.system(size: 13)).foregroundStyle(engine.palette.textDim)
    }
}

struct FieldHint: View {
    let text: String
    var warning = false
    @EnvironmentObject var engine: NEOEngine
    var body: some View {
        Text(text)
            .font(.system(size: 12))
            .foregroundStyle(warning ? engine.palette.accent : engine.palette.textDim)
            .lineSpacing(3)
            .padding(warning ? 10 : 0)
            .background(warning ? engine.palette.accent.opacity(0.08) : .clear)
            .overlay(warning ? RoundedRectangle(cornerRadius: 8).stroke(engine.palette.accent.opacity(0.25), lineWidth: 1) : nil)
    }
}

struct SectionHeader: View {
    let text: String
    @EnvironmentObject var engine: NEOEngine
    var body: some View {
        Text(text)
            .font(NEOFont.display(12))
            .tracking(2)
            .foregroundStyle(engine.palette.secondary)
            .padding(.top, 4)
    }
}

struct SettingsDrawerView: View {
    @EnvironmentObject var engine: NEOEngine
    @Binding var isPresented: Bool
    @State private var showKey = false
    @State private var showCfToken = false
    @State private var showTuyaSecret = false

    var body: some View {
        DrawerContainer(title: "Ayarlar", isPresented: $isPresented) {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {

                    // ── AI ──
                    Group {
                        SectionHeader(text: "AI")
                        FieldLabel(text: "Gemini API Key")
                        HStack {
                            KeyboardTextField(
                                "API anahtarınızı girin",
                                text: $engine.apiKey,
                                palette: engine.palette,
                                isSecure: !showKey,
                                autocapitalization: .none,
                                autocorrection: false
                            )
                            Button(showKey ? "Gizle" : "Göster") { showKey.toggle() }
                                .font(.system(size: 13))
                                .foregroundStyle(engine.palette.primary)
                        }

                        FieldHint(text: "⚠ API anahtarı bu cihazda UserDefaults içinde şifrelenmeden saklanır. Bu, paylaşılan/ortak bir cihazda güvenlik riski oluşturur. Üretim kullanımı için anahtarı asla istemci tarafında tutmayın; bir sunucu/proxy arkasına gizleyin.", warning: true)

                        Button(action: { engine.updateAiPanel(); engine.showToast(engine.apiKey.isEmpty ? "API anahtarı temizlendi." : "API anahtarı kaydedildi.") }) {
                            Text("API KEY KAYDET").font(NEOFont.display(12)).tracking(1.5)
                        }
                        .buttonStyle(NEOPrimaryButtonStyle())

                        FieldLabel(text: "Model")
                        KeyboardTextField("gemini-3.5-flash", text: $engine.model, palette: engine.palette, autocapitalization: .none, autocorrection: false, onSubmit: { engine.updateAiPanel() })
                        FieldHint(text: "Gemini model adları zamanla değişebilir. Güncel liste için Google AI Studio / Gemini API dokümantasyonuna bakın.")
                    }

                    // ── Görsel Oluşturma (Cloudflare Workers AI) ──
                    Group {
                        SectionHeader(text: "Görsel Oluşturma (Cloudflare Workers AI)")
                        FieldHint(text: "\"Görsel Oluştur\" özelliği Cloudflare Workers AI'yi (@cf/black-forest-labs/flux-1-schnell) kullanır. Aşağıya girdiğiniz değerler öncelikli kullanılır; boş bırakırsanız MyApp.swift dosyasındaki CLOUDFLARE_ACCOUNT_ID / CLOUDFLARE_API_TOKEN kod sabitleri kullanılır.")

                        FieldLabel(text: "Cloudflare Account ID")
                        KeyboardTextField("Cloudflare panelinizin sağ kenar çubuğunda", text: $engine.cloudflareAccountID, palette: engine.palette, autocapitalization: .none, autocorrection: false)

                        FieldLabel(text: "Cloudflare API Token")
                        HStack {
                            KeyboardTextField(
                                "Workers AI yazma izinli token",
                                text: $engine.cloudflareApiToken,
                                palette: engine.palette,
                                isSecure: !showCfToken,
                                autocapitalization: .none,
                                autocorrection: false
                            )
                            Button(showCfToken ? "Gizle" : "Göster") { showCfToken.toggle() }
                                .font(.system(size: 13))
                                .foregroundStyle(engine.palette.primary)
                        }
                        FieldHint(text: "Token'ı dash.cloudflare.com/profile/api-tokens üzerinden \"Workers AI\" için yazma (Edit) izniyle oluşturun.")
                        FieldHint(text: "⚠ Bu token da, diğer anahtarlar gibi, bu cihazda şifrelenmeden saklanır.", warning: true)

                        FieldLabel(text: "Görsel Modeli")
                        KeyboardTextField("@cf/black-forest-labs/flux-1-schnell", text: $engine.imageModel, palette: engine.palette, autocapitalization: .none, autocorrection: false)
                        FieldHint(text: "flux-1-schnell hızlıdır ama prompt'a bağlılığı zayıftır. Daha açıklamaya sadık sonuçlar için deneyebileceğiniz diğer Cloudflare Workers AI modelleri:\n• @cf/stabilityai/stable-diffusion-xl-base-1.0 (daha kaliteli, daha yavaş)\n• @cf/bytedance/stable-diffusion-xl-lightning (hızlı + gerçekçi)\n• @cf/lykon/dreamshaper-8-lcm (sanatsal/stilize)")

                        FieldLabel(text: "Yaratıcılık (temperature): \(String(format: "%.2f", engine.temperature))")
                        Slider(value: $engine.temperature, in: 0...1, step: 0.05)
                            .tint(engine.palette.primary)
                    }

                    // ── Ses ──
                    Group {
                        SectionHeader(text: "Ses (Voice)")
                        FieldLabel(text: "Ses Cinsiyeti Tercihi")
                        Picker("", selection: $engine.voiceGenderPref) {
                            ForEach(VoiceGenderPref.allCases, id: \.self) { g in Text(g.label).tag(g) }
                        }
                        .pickerStyle(.segmented)
                        .onChange(of: engine.voiceGenderPref) { _ in engine.refreshVoiceHint() }
                        FieldHint(text: "Cihazınızda bu cinsiyete uygun bir ses varsa otomatik olarak öncelikli seçilir.")

                        Toggle("Türkçede uygun ses yoksa cinsiyeti yine de önceliklendir", isOn: $engine.voiceGenderStrict)
                            .toggleStyle(NEOToggleStyle())
                            .onChange(of: engine.voiceGenderStrict) { _ in engine.refreshVoiceHint() }
                        FieldHint(text: "Kapalıyken doğru telaffuz için Türkçe ses önceliklidir. Açıkken, cihazınızda o cinsiyette Türkçe ses yoksa başka bir dildeki bir ses kullanılır — telaffuz bozulabilir.")

                        FieldLabel(text: "Hız: \(String(format: "%.1f", engine.rate))")
                        Slider(value: Binding(get: { Double(engine.rate) }, set: { engine.rate = Float($0) }), in: 0.5...2, step: 0.1)
                            .tint(engine.palette.primary)

                        FieldLabel(text: "Ses Kalınlığı / Ton: \(String(format: "%.1f", engine.pitch))")
                        Slider(value: Binding(get: { Double(engine.pitch) }, set: { engine.pitch = Float($0) }), in: 0...2, step: 0.1)
                            .tint(engine.palette.primary)
                        FieldHint(text: "Düşük değerler daha kalın/pes, yüksek değerler daha ince/tiz bir ses verir.")

                        Toggle("Cevapları otomatik seslendir", isOn: $engine.autoSpeak).toggleStyle(NEOToggleStyle())
                        Toggle("Doğal / insansı konuşma tonu", isOn: $engine.humanize).toggleStyle(NEOToggleStyle())
                        FieldHint(text: "Cümle aralarına doğal duraklamalar ekler, en uygun kaliteli sistem sesini otomatik seçer ve monoton robotik tekrarı azaltmak için hız/tona ince, insana özgü sapmalar uygular.")

                        FieldHint(text: engine.voiceSupportHint)
                    }

                    // ── Akıllı Ev (Tuya) ──
                    Group {
                        SectionHeader(text: "Akıllı Ev (Tuya)")
                        FieldHint(text: "Bağlarsanız \"salon lambasını aç\", \"prizi kapat\" gibi komutlarla Tuya/Smart Life hesabınıza bağlı cihazları gerçekten açıp kapatabilirim (Google Home'un kendisine değil, arkasındaki Tuya hesabına bağlanıyorum). Kurulum:\n1. iot.tuya.com'da ücretsiz bir geliştirici hesabı açın.\n2. Cloud > Create Cloud Project ile yeni proje oluşturun; veri merkezini aşağıdaki seçimle aynı yapın.\n3. Cloud Services'ten en azından \"IoT Core\" ve \"Smart Home Basic Service\"e abone olun.\n4. Proje detayından Access ID ve Access Secret'ı kopyalayıp aşağıya girin.\n5. Devices > Link App Account > Add App Account > \"Tuya App Account Authorization\" ile Tuya/Smart Life uygulamanızdan QR kodu okutun.\n6. Bağlantı tamamlanınca listede görünen UID'yi aşağıya girin.")

                        FieldLabel(text: "Veri Merkezi (Data Center)")
                        Picker("", selection: $engine.tuyaDataCenter) {
                            ForEach(TuyaDataCenter.allCases, id: \.self) { dc in Text(dc.label).tag(dc) }
                        }
                        .pickerStyle(.segmented)

                        FieldLabel(text: "Access ID (Client ID)")
                        KeyboardTextField("Tuya bulut projenizin Access ID'si", text: $engine.tuyaAccessId, palette: engine.palette, autocapitalization: .none, autocorrection: false)

                        FieldLabel(text: "Access Secret (Client Secret)")
                        HStack {
                            KeyboardTextField(
                                "Tuya bulut projenizin Access Secret'ı",
                                text: $engine.tuyaAccessSecret,
                                palette: engine.palette,
                                isSecure: !showTuyaSecret,
                                autocapitalization: .none,
                                autocorrection: false
                            )
                            Button(showTuyaSecret ? "Gizle" : "Göster") { showTuyaSecret.toggle() }
                                .font(.system(size: 13))
                                .foregroundStyle(engine.palette.primary)
                        }
                        FieldHint(text: "⚠ Bu değer de, diğer anahtarlar gibi, bu cihazda şifrelenmeden saklanır.", warning: true)

                        FieldLabel(text: "UID")
                        KeyboardTextField("Link App Account sonrası görünen UID", text: $engine.tuyaUid, palette: engine.palette, autocapitalization: .none, autocorrection: false)

                        Button("Cihazları Getir") { Task { await engine.refreshTuyaDevices() } }
                            .buttonStyle(NEOPrimaryButtonStyle())
                            .disabled(!engine.tuyaConfigured)

                        if !engine.tuyaDevices.isEmpty {
                            FieldHint(text: "Bulunan cihazlar (bu adlarla \"X'i aç\" / \"X'i kapat\" diyebilirsiniz): " + engine.tuyaDevices.map { "\($0.name)\($0.online ? "" : " (çevrimdışı)")" }.joined(separator: ", "))
                        }
                    }

                    // ── Arayüz ──
                    Group {
                        SectionHeader(text: "Arayüz")
                        Toggle("Animasyonlar", isOn: $engine.animationsEnabled).toggleStyle(NEOToggleStyle())

                        FieldLabel(text: "HUD Yoğunluğu")
                        Picker("", selection: $engine.hudIntensity) {
                            ForEach(HudIntensity.allCases, id: \.self) { i in Text(i.label).tag(i) }
                        }
                        .pickerStyle(.segmented)

                        FieldLabel(text: "Tema")
                        Picker("", selection: $engine.theme) {
                            ForEach(NeoTheme.allCases, id: \.self) { t in Text(t.label).tag(t) }
                        }
                        .pickerStyle(.segmented)
                    }

                    // ── Konum & Hava Durumu ──
                    Group {
                        SectionHeader(text: "Konum & Hava Durumu")
                        FieldLabel(text: "Varsayılan Şehir (opsiyonel)")
                        KeyboardTextField("Örn: İstanbul", text: $engine.defaultCity, palette: engine.palette)
                        FieldHint(text: "Konum izni vermezseniz veya sorguda bir şehir belirtmezseniz hava durumu bu şehir için sorgulanır.")
                    }

                    // ── Hafıza ──
                    Group {
                        SectionHeader(text: "Hafıza")
                        HStack(spacing: 10) {
                            Button("Hafızayı Gör") { }
                                .buttonStyle(NEOTextButtonStyle())
                            Button("Hafızayı Temizle") { engine.clearMemory() }
                                .buttonStyle(NEOTextButtonStyle(danger: true))
                        }
                    }
                }
                .padding(16)
            }
        }
    }
}

// MARK: - Ortak stiller

struct NEOTextFieldStyle: TextFieldStyle {
    @EnvironmentObject var engine: NEOEngine
    func _body(configuration: TextField<Self._Label>) -> some View {
        configuration
            .padding(.horizontal, 12)
            .padding(.vertical, 10)
            .background(Color.white.opacity(0.04))
            .overlay(RoundedRectangle(cornerRadius: 8).stroke(engine.palette.panelBorder, lineWidth: 1))
            .clipShape(RoundedRectangle(cornerRadius: 8))
            .foregroundStyle(engine.palette.text)
    }
}

struct NEOPrimaryButtonStyle: ButtonStyle {
    @EnvironmentObject var engine: NEOEngine
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .frame(maxWidth: .infinity)
            .padding(.vertical, 12)
            .background(LinearGradient(colors: [engine.palette.primary, engine.palette.secondary], startPoint: .leading, endPoint: .trailing))
            .foregroundStyle(Color(hex: 0x04080a))
            .clipShape(RoundedRectangle(cornerRadius: 10))
            .scaleEffect(configuration.isPressed ? 0.98 : 1)
    }
}

struct NEOTextButtonStyle: ButtonStyle {
    var danger = false
    @EnvironmentObject var engine: NEOEngine
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 13))
            .padding(.horizontal, 14)
            .padding(.vertical, 8)
            .foregroundStyle(danger ? engine.palette.danger : engine.palette.primary)
            .overlay(RoundedRectangle(cornerRadius: 8).stroke(danger ? engine.palette.danger.opacity(0.3) : engine.palette.panelBorder, lineWidth: 1))
    }
}

struct NEOToggleStyle: ToggleStyle {
    @EnvironmentObject var engine: NEOEngine
    func makeBody(configuration: Configuration) -> some View {
        HStack {
            configuration.label.font(.system(size: 14)).foregroundStyle(engine.palette.text)
            Spacer()
            Toggle("", isOn: configuration.$isOn).labelsHidden().tint(engine.palette.primary)
        }
    }
}
