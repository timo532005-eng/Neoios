import SwiftUI

// ════════════════════════════════════════════════════════════════
// MemoryAndNotesDrawers.swift — #drawer-memory ve #drawer-notes karşılığı.
// ════════════════════════════════════════════════════════════════

struct MemoryDrawerView: View {
    @EnvironmentObject var engine: NEOEngine
    @Binding var isPresented: Bool

    var body: some View {
        DrawerContainer(title: "Hafıza", isPresented: $isPresented) {
            VStack(alignment: .leading, spacing: 12) {
                FieldHint(text: "NEO'ya \"bunu hatırla: ...\" dediğinizde buraya kaydedilir. Bu cihazda saklanır.")
                    .padding(.horizontal, 16)
                    .padding(.top, 12)

                if engine.memory.isEmpty {
                    Spacer()
                    Text("Henüz kayıtlı bir hafıza yok.")
                        .foregroundStyle(engine.palette.textDim)
                        .frame(maxWidth: .infinity)
                        .padding()
                    Spacer()
                } else {
                    ScrollView {
                        LazyVStack(spacing: 10) {
                            ForEach(engine.memory.reversed()) { entry in
                                ListRow(text: entry.text, meta: formattedDate(entry.date)) {
                                    engine.deleteMemory(id: entry.id)
                                }
                            }
                        }
                        .padding(16)
                    }
                }
            }
        }
    }

    private func formattedDate(_ date: Date) -> String {
        let df = DateFormatter()
        df.locale = Locale(identifier: "tr_TR")
        df.dateStyle = .medium
        df.timeStyle = .short
        return df.string(from: date)
    }
}

struct NotesDrawerView: View {
    @EnvironmentObject var engine: NEOEngine
    @Binding var isPresented: Bool
    @State private var newNote = ""

    var body: some View {
        DrawerContainer(title: "Notlar", isPresented: $isPresented) {
            VStack(spacing: 12) {
                HStack {
                    KeyboardTextField("Yeni not…", text: $newNote, palette: engine.palette, onSubmit: addNote)
                    Button(action: addNote) {
                        Image(systemName: "plus")
                            .foregroundStyle(Color(hex: 0x04080a))
                            .frame(width: 42, height: 42)
                            .background(LinearGradient(colors: [engine.palette.primary, engine.palette.secondary], startPoint: .leading, endPoint: .trailing))
                            .clipShape(RoundedRectangle(cornerRadius: 10))
                    }
                }
                .padding(.horizontal, 16)
                .padding(.top, 12)

                if engine.notes.isEmpty {
                    Spacer()
                    Text("Henüz not eklenmedi.")
                        .foregroundStyle(engine.palette.textDim)
                    Spacer()
                } else {
                    ScrollView {
                        LazyVStack(spacing: 10) {
                            ForEach(engine.notes.reversed()) { entry in
                                ListRow(text: entry.text, meta: nil) {
                                    engine.deleteNote(id: entry.id)
                                }
                            }
                        }
                        .padding(16)
                    }
                }
            }
        }
    }

    private func addNote() {
        guard !newNote.trimmingCharacters(in: .whitespaces).isEmpty else { return }
        engine.addNote(newNote)
        newNote = ""
    }
}

/// .memory-list li karşılığı — hem hafıza hem notlar için ortak satır.
struct ListRow: View {
    let text: String
    let meta: String?
    let onDelete: () -> Void
    @EnvironmentObject var engine: NEOEngine

    var body: some View {
        HStack(alignment: .top) {
            VStack(alignment: .leading, spacing: 4) {
                Text(text).font(.system(size: 14)).foregroundStyle(engine.palette.text)
                if let meta {
                    Text(meta).font(NEOFont.mono(10)).foregroundStyle(engine.palette.textDim)
                }
            }
            Spacer()
            Button(action: onDelete) {
                Image(systemName: "xmark").foregroundStyle(engine.palette.danger)
            }
        }
        .padding(12)
        .background(engine.palette.panelBg)
        .overlay(RoundedRectangle(cornerRadius: 10).stroke(engine.palette.panelBorder, lineWidth: 1))
        .clipShape(RoundedRectangle(cornerRadius: 10))
    }
}
