import SwiftUI

// ════════════════════════════════════════════════════════════════
// HUDCanvasView.swift — orijinal initHudCanvas()/drawHud() (canvas 2D)
// karşılığı. SwiftUI Canvas + TimelineView(.animation) kullanılır.
// Yalnızca dekoratif/reaktif arkaplan çizer; dokunmaya kapalıdır
// (bkz. HUDView.swift — üstüne bindirilen dokunulabilir çekirdek).
// ════════════════════════════════════════════════════════════════

private struct HudParticle {
    let baseR: Double
    let angle: Double
    let speed: Double
    let size: Double
    let phase: Double
}
private struct HudBar {
    let angle: Double
    let phase: Double
    let speed: Double
    let rand: Double
}

struct HUDCanvasView: View {
    @EnvironmentObject var engine: NEOEngine
    /// true iken (bir çekmece açıkken ya da kullanıcı bir metin kutusuna
    /// yazarken) animasyon tamamen durur — hem gereksiz yere gizliyken
    /// çizim yapmamak için hem de ana iş parçacığını klavye olayları
    /// için serbest bırakmak için (bkz. reduceMotion kullanım yeri).
    var reduceMotion: Bool = false
    @State private var particles: [HudParticle] = []
    @State private var bars: [HudBar] = []
    @State private var smoothedVol: Double = 0
    @State private var angleAccum: Double = 0
    @State private var lastTimestamp: Date = Date()

    private let stateSpeed: [NEOState: Double] = [.idle: 1, .listening: 1.8, .thinking: 3, .speaking: 1.4, .error: 0.6]

    var body: some View {
        // minimumInterval ile kare hızı ~24fps'e sınırlanıyor (eskiden
        // sınırsız/60fps'ti) — bu, sürekli çalışan bu dekoratif animasyonun
        // ana iş parçacığı üzerindeki yükünü belirgin şekilde azaltır ve
        // klavye/dokunuş olaylarının gecikmeden işlenmesine yardımcı olur.
        // reduceMotion true iken (çekmece açık ya da metin yazılıyorken)
        // tamamen duruyor.
        TimelineView(.animation(minimumInterval: 1.0 / 24.0, paused: !engine.animationsEnabled || reduceMotion)) { timeline in
            Canvas { context, size in
                draw(context: context, size: size, timestamp: timeline.date)
            }
        }
        .onAppear(perform: setupParticles)
        .allowsHitTesting(false)
    }

    private func setupParticles() {
        guard particles.isEmpty else { return }
        particles = (0..<46).map { _ in
            HudParticle(
                baseR: 60 + Double.random(in: 0...220),
                angle: Double.random(in: 0...(2 * .pi)),
                speed: (0.05 + Double.random(in: 0...0.15)) * (Bool.random() ? 1 : -1),
                size: 0.6 + Double.random(in: 0...1.6),
                phase: Double.random(in: 0...(2 * .pi))
            )
        }
        let barCount = 40
        bars = (0..<barCount).map { i in
            HudBar(
                angle: (Double(i) / Double(barCount)) * 2 * .pi,
                phase: Double.random(in: 0...(2 * .pi)),
                speed: 0.5 + Double.random(in: 0...1.1),
                rand: 0.4 + Double.random(in: 0...0.6)
            )
        }
    }

    private func draw(context: GraphicsContext, size: CGSize, timestamp: Date) {
        let w = size.width, h = size.height
        let cx = w / 2, cy = h / 2
        let palette = engine.palette
        let primary = palette.primary
        let secondary = palette.secondary

        let dt = timestamp.timeIntervalSince(lastTimestamp)
        lastTimestamp = timestamp

        let speedMul = stateSpeed[engine.state] ?? 1
        let intensityMul = engine.hudIntensity.multiplier

        let targetVol = engine.volume
        smoothedVol += (targetVol - smoothedVol) * 0.15
        let vol = smoothedVol

        angleAccum += 0.36 * speedMul * min(dt, 0.05) // ~0.006/frame @60fps benzeri hız

        let ms = timestamp.timeIntervalSinceReferenceDate * 1000

        // ─── Jarvis tarzı enstrüman kadranı: dıştan içe çentikli halka,
        // iki kısmi "gösterge" yayı ve köşe parantezleri. Mevcut radar
        // taraması/eşitleyici/parçacıklarla birlikte katmanlanır.

        // Çentikli halka (saat kadranı gibi) — her 5. çentik daha uzun.
        let tickR = w * 0.465
        context.drawLayer { layer in
            layer.translateBy(x: cx, y: cy)
            layer.rotate(by: .radians(angleAccum * 0.15))
            let tickCount = 60
            for i in 0..<tickCount {
                let a = (Double(i) / Double(tickCount)) * 2 * .pi
                let isMajor = i % 5 == 0
                let len: Double = isMajor ? 10 : 4
                let x1 = cos(a) * tickR, y1 = sin(a) * tickR
                let x2 = cos(a) * (tickR - len), y2 = sin(a) * (tickR - len)
                var path = Path()
                path.move(to: CGPoint(x: x1, y: y1))
                path.addLine(to: CGPoint(x: x2, y: y2))
                layer.stroke(path, with: .color(primary.opacity(isMajor ? 0.55 : 0.22)), lineWidth: isMajor ? 1.4 : 0.8)
            }
        }

        // Güç/düzey göstergesi: ses genliğine/duruma tepki veren kısmi yay.
        let gaugeLevel = min(1, 0.22 + vol * 0.9 + (engine.state == .thinking ? 0.25 : 0))
        context.drawLayer { layer in
            let gaugeRect = CGRect(x: cx - w * 0.40, y: cy - w * 0.40, width: w * 0.80, height: w * 0.80)
            let track = Path(ellipseIn: gaugeRect)
            layer.stroke(track, with: .color(primary.opacity(0.12)), lineWidth: 2)
            var active = Path()
            active.addArc(center: CGPoint(x: cx, y: cy), radius: w * 0.40, startAngle: .degrees(-90), endAngle: .degrees(-90 + 360 * gaugeLevel), clockwise: false)
            layer.stroke(active, with: .color(secondary.opacity(0.75 * intensityMul)), style: StrokeStyle(lineWidth: 2.4, lineCap: .round))
        }

        // İkinci, yavaşça ters yönde dönen ince gösterge yayı (dekoratif).
        context.drawLayer { layer in
            var arc = Path()
            let sweepDeg = 70.0
            let startDeg = (angleAccum * -18).truncatingRemainder(dividingBy: 360)
            arc.addArc(center: CGPoint(x: cx, y: cy), radius: w * 0.355, startAngle: .degrees(startDeg), endAngle: .degrees(startDeg + sweepDeg), clockwise: false)
            layer.stroke(arc, with: .color(primary.opacity(0.4)), style: StrokeStyle(lineWidth: 1.4, lineCap: .round))
        }

        // Köşe parantezleri — klasik hedefleme/HUD çerçevesi hissi.
        let bracketInset = w * 0.015
        let bracketLen = w * 0.07
        let corners: [(CGPoint, CGPoint, CGPoint)] = [
            (CGPoint(x: bracketInset, y: bracketInset + bracketLen), CGPoint(x: bracketInset, y: bracketInset), CGPoint(x: bracketInset + bracketLen, y: bracketInset)),
            (CGPoint(x: w - bracketInset - bracketLen, y: bracketInset), CGPoint(x: w - bracketInset, y: bracketInset), CGPoint(x: w - bracketInset, y: bracketInset + bracketLen)),
            (CGPoint(x: w - bracketInset, y: h - bracketInset - bracketLen), CGPoint(x: w - bracketInset, y: h - bracketInset), CGPoint(x: w - bracketInset - bracketLen, y: h - bracketInset)),
            (CGPoint(x: bracketInset + bracketLen, y: h - bracketInset), CGPoint(x: bracketInset, y: h - bracketInset), CGPoint(x: bracketInset, y: h - bracketInset - bracketLen)),
        ]
        context.drawLayer { layer in
            for (p1, p2, p3) in corners {
                var path = Path()
                path.move(to: p1)
                path.addLine(to: p2)
                path.addLine(to: p3)
                layer.stroke(path, with: .color(secondary.opacity(0.5)), style: StrokeStyle(lineWidth: 1.6, lineCap: .round, lineJoin: .round))
            }
        }

        // Ana radar tarama çizgisi
        var sweep1 = Path()
        sweep1.move(to: .zero)
        sweep1.addLine(to: CGPoint(x: w * 0.42, y: 0))
        context.drawLayer { layer in
            layer.translateBy(x: cx, y: cy)
            layer.rotate(by: .radians(angleAccum * 2.2))
            let gradient = Gradient(stops: [.init(color: primary.opacity(0.67), location: 0), .init(color: .clear, location: 1)])
            layer.stroke(sweep1, with: .linearGradient(gradient, startPoint: .zero, endPoint: CGPoint(x: w * 0.42, y: 0)), lineWidth: 2)
        }

        // İkinci, ters yönlü tarama çizgisi
        var sweep2 = Path()
        sweep2.move(to: .zero)
        sweep2.addLine(to: CGPoint(x: w * 0.3, y: 0))
        context.drawLayer { layer in
            layer.translateBy(x: cx, y: cy)
            layer.rotate(by: .radians(-angleAccum * 1.3 + .pi))
            let gradient = Gradient(stops: [.init(color: secondary.opacity(0.47), location: 0), .init(color: .clear, location: 1)])
            layer.stroke(sweep2, with: .linearGradient(gradient, startPoint: .zero, endPoint: CGPoint(x: w * 0.3, y: 0)), lineWidth: 1)
        }

        // Eşitleyici (equalizer) çubukları
        let barBaseR = w * 0.185
        let barMaxLen = w * 0.09 * intensityMul
        context.drawLayer { layer in
            layer.translateBy(x: cx, y: cy)
            for b in bars {
                let idle = (sin(ms / 260 * b.speed + b.phase) * 0.5 + 0.5) * 0.35
                let level = min(1, idle + vol * b.rand * 1.3)
                let len = 4 + level * barMaxLen
                let a = b.angle + angleAccum * 0.4
                let x1 = cos(a) * barBaseR, y1 = sin(a) * barBaseR
                let x2 = cos(a) * (barBaseR + len), y2 = sin(a) * (barBaseR + len)
                var path = Path()
                path.move(to: CGPoint(x: x1, y: y1))
                path.addLine(to: CGPoint(x: x2, y: y2))
                let color = (level > 0.55 ? secondary : primary).opacity(0.8)
                layer.stroke(path, with: .color(color), style: StrokeStyle(lineWidth: 2.2, lineCap: .round))
            }
        }

        // Parçacıklar
        context.drawLayer { layer in
            for p in particles {
                let wobble = sin(ms / 900 + p.phase) * 6 * intensityMul
                let r = p.baseR + wobble
                let a = p.angle + angleAccum * p.speed * 3
                let x = cx + cos(a) * r
                let y = cy + sin(a) * r * 0.94
                let boost = 1 + vol * 0.9
                let dotSize = p.size * intensityMul * boost
                let rect = CGRect(x: x - dotSize, y: y - dotSize, width: dotSize * 2, height: dotSize * 2)
                let color = (Bool.random() ? primary : secondary).opacity(0.67)
                layer.fill(Path(ellipseIn: rect), with: .color(color))
            }
        }
    }
}
