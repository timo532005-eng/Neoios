import SwiftUI

// ════════════════════════════════════════════════════════════════
// StatusGridView.swift — .status-grid / .status-panel karşılığı
// ════════════════════════════════════════════════════════════════

struct StatusPanel: View {
    let label: String
    let value: String
    let level: PanelLevel
    @EnvironmentObject var engine: NEOEngine

    private var color: Color {
        switch level {
        case .ok: return engine.palette.primary
        case .warn: return engine.palette.accent
        case .bad: return engine.palette.danger
        }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(label)
                .font(NEOFont.mono(9))
                .tracking(1.5)
                .foregroundStyle(engine.palette.textDim)
            Text(value)
                .font(NEOFont.display(11))
                .tracking(0.5)
                .foregroundStyle(color)
                .lineLimit(1)
                .minimumScaleFactor(0.7)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .frame(minWidth: 100, alignment: .leading)
        .background(engine.palette.panelBg)
        .overlay(RoundedRectangle(cornerRadius: 10).stroke(engine.palette.panelBorder, lineWidth: 1))
        .clipShape(RoundedRectangle(cornerRadius: 10))
    }
}

struct StatusGridView: View {
    @EnvironmentObject var engine: NEOEngine

    var columns: [GridItem] { [GridItem(.adaptive(minimum: 100), spacing: 8)] }

    var body: some View {
        LazyVGrid(columns: columns, spacing: 8) {
            StatusPanel(label: "NEO", value: engine.neoPanel, level: .ok)
            StatusPanel(label: "AI · GEMINI", value: engine.aiPanel, level: engine.aiPanelLevel)
            StatusPanel(label: "SES", value: engine.voicePanel, level: engine.voicePanelLevel)
            StatusPanel(label: "AĞ", value: engine.networkPanel, level: engine.networkPanelLevel)
            StatusPanel(label: "SAAT", value: engine.clockText, level: .ok)
            activityPanel
            StatusPanel(label: "HAVA", value: engine.weatherPanel, level: engine.weatherPanelLevel)
        }
    }

    private var activityPanel: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text("AKTİVİTE")
                .font(NEOFont.mono(9))
                .tracking(1.5)
                .foregroundStyle(engine.palette.textDim)
            GeometryReader { geo in
                ZStack(alignment: .leading) {
                    Capsule().fill(Color.white.opacity(0.06))
                    Capsule()
                        .fill(LinearGradient(colors: [engine.palette.primary, engine.palette.secondary], startPoint: .leading, endPoint: .trailing))
                        .frame(width: geo.size.width * CGFloat(engine.volume))
                }
            }
            .frame(height: 6)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .frame(minWidth: 100, alignment: .leading)
        .background(engine.palette.panelBg)
        .overlay(RoundedRectangle(cornerRadius: 10).stroke(engine.palette.panelBorder, lineWidth: 1))
        .clipShape(RoundedRectangle(cornerRadius: 10))
    }
}
