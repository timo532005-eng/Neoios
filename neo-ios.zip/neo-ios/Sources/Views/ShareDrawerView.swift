import SwiftUI
import UIKit
import CoreImage.CIFilterBuiltins

// ════════════════════════════════════════════════════════════════
// ShareDrawerView.swift — "Paylaşım" çekmecesi. Paylaşımı başlatınca
// bir QR kod gösterir; aynı Wi-Fi ağındaki başka bir cihaz kamerasıyla
// bu kodu okutup açılan adreste NEO'yu tarayıcı üzerinden uzaktan
// kullanabilir (bkz. RemoteShareController / RemoteWebUI).
// ════════════════════════════════════════════════════════════════

struct ShareDrawerView: View {
    @EnvironmentObject var engine: NEOEngine
    @Binding var isPresented: Bool

    var body: some View {
        DrawerContainer(title: "Paylaşım", isPresented: $isPresented) {
            ShareContentView(remote: engine.remote)
        }
    }
}

private struct ShareContentView: View {
    @EnvironmentObject var engine: NEOEngine
    @ObservedObject var remote: RemoteShareController
    @State private var copied = false

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                FieldHint(text: "QR kodu aynı Wi-Fi ağındaki başka bir telefonun/bilgisayarın kamerasıyla okutun; tarayıcıda NEO'nun uzaktan kumanda sayfası açılır. Oradan yazdığınız mesajlar NEO'ya iletilir (akıllı ev komutları dahil) ve cevaplar orada da görünür. Paylaşım başlamadan önceki konuşmalar uzak cihazda görünmez.")

                if remote.isActive, let url = remote.shareURL {
                    activeSection(url: url)
                } else {
                    inactiveSection
                }

                FieldHint(text: "Sınırlar: İki cihaz aynı Wi-Fi ağında olmalı; NEO bu cihazda ön planda açık kalmalı (uygulamadan çıkarsanız paylaşım otomatik durur). Uzaktan yalnızca yazılı mesaj gönderilebilir (sesli konuşma desteklenmez). \"Görsel Oluştur\" modu çalışır: görsel birkaç on saniye içinde hem uzak cihazda hem NEO'nun sohbetinde görünür; sayfadaki görsele dokunup tam boyutta açabilir/kaydedebilirsiniz.")
                FieldHint(text: "⚠ Güvenlik: QR koda/bağlantıya sahip herkes NEO'yu kontrol edebilir. Bağlantı şifrelenmez (HTTP), bu yüzden yalnızca güvendiğiniz bir ağda kullanın ve işiniz bitince Paylaşımı Durdurun.", warning: true)
                FieldHint(text: "Bağlanamıyorsanız: iPadOS \"Yerel Ağ\" izni isteyebilir — İzin Ver deyin. Swift Playgrounds'ta proje ayarlarındaki Yetenekler (Capabilities) bölümüne \"Yerel Ağ\" (Local Network) yeteneğinin eklenmiş olması gerekebilir.")
            }
            .padding(16)
        }
    }

    private var inactiveSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Button(action: { remote.start(engine: engine) }) {
                Text("PAYLAŞIMI BAŞLAT").font(NEOFont.display(12)).tracking(1.5)
            }
            .buttonStyle(NEOPrimaryButtonStyle())

            if !remote.statusMessage.isEmpty {
                FieldHint(text: remote.statusMessage, warning: true)
            }
        }
    }

    private func activeSection(url: String) -> some View {
        VStack(alignment: .leading, spacing: 14) {
            QRImageView(text: url)
                .frame(maxWidth: .infinity)

            TimelineView(.periodic(from: .now, by: 2)) { context in
                let connected = remote.lastClientActivity.map { context.date.timeIntervalSince($0) < 6 } ?? false
                HStack(spacing: 8) {
                    Circle()
                        .fill(connected ? Color.green : engine.palette.textDim)
                        .frame(width: 8, height: 8)
                    Text(connected ? "Uzak cihaz bağlı" : "Bağlantı bekleniyor… QR kodu başka bir cihazla okutun")
                        .font(.system(size: 13))
                        .foregroundStyle(engine.palette.text)
                }
            }

            Text(url)
                .font(.system(size: 11, design: .monospaced))
                .foregroundStyle(engine.palette.textDim)
                .textSelection(.enabled)

            Button(copied ? "Kopyalandı ✓" : "Bağlantıyı Kopyala") {
                UIPasteboard.general.string = url
                copied = true
                Task { @MainActor in
                    try? await Task.sleep(nanoseconds: 1_500_000_000)
                    copied = false
                }
            }
            .buttonStyle(NEOTextButtonStyle())

            Button("Yeni Bağlantı Oluştur (eskisini geçersiz kıl)") {
                remote.regenerate(engine: engine)
            }
            .buttonStyle(NEOTextButtonStyle())

            Button("Paylaşımı Durdur") { remote.stop() }
                .buttonStyle(NEOTextButtonStyle())
                .foregroundStyle(engine.palette.danger)
        }
    }
}

/// QR kodu bir kez üretip saklar (üst görünüm sık yenilense de her seferinde
/// yeniden üretmemek için). Tarayıcıların rahat okuyabilmesi için beyaz
/// zemin + sessiz bölge (padding) ile çizilir.
private struct QRImageView: View {
    let text: String
    @State private var image: UIImage? = nil

    var body: some View {
        Group {
            if let image {
                Image(uiImage: image)
                    .interpolation(.none)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 230, height: 230)
                    .padding(14)
                    .background(Color.white)
                    .clipShape(RoundedRectangle(cornerRadius: 14))
            } else {
                Text("QR kod oluşturulamadı")
                    .font(.system(size: 13))
                    .foregroundStyle(.secondary)
            }
        }
        .onAppear { image = QRCode.image(for: text) }
        .onChange(of: text) { newText in image = QRCode.image(for: newText) }
    }
}

private enum QRCode {
    static func image(for string: String) -> UIImage? {
        let filter = CIFilter.qrCodeGenerator()
        filter.message = Data(string.utf8)
        filter.correctionLevel = "M"
        guard let output = filter.outputImage else { return nil }
        let scaled = output.transformed(by: CGAffineTransform(scaleX: 10, y: 10))
        let context = CIContext()
        guard let cgImage = context.createCGImage(scaled, from: scaled.extent) else { return nil }
        return UIImage(cgImage: cgImage)
    }
}
