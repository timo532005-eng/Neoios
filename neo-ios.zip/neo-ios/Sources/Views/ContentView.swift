import SwiftUI

// ════════════════════════════════════════════════════════════════
// ContentView.swift — orijinal <body> düzeninin (topbar, hud-stage,
// control-bar, çekmeceler, modallar, toast) tamamının birleştiği yer.
// ════════════════════════════════════════════════════════════════

struct ContentView: View {
    @EnvironmentObject var engine: NEOEngine
    @State private var menuOpen = false
    @State private var showChatDrawer = false
    @State private var showSettingsDrawer = false
    @State private var showMemoryDrawer = false
    @State private var showNotesDrawer = false
    @State private var showCameraDrawer = false
    @State private var showCalendarDrawer = false
    @State private var showImageGenDrawer = false
    @State private var showTranscribeDrawer = false
    @State private var showProfileDrawer = false
    @State private var showShareDrawer = false

    var body: some View {
        GeometryReader { geo in
            let isWide = geo.size.width > 820
            let anyDrawerOpen = showChatDrawer || showSettingsDrawer || showMemoryDrawer
                || showNotesDrawer || showCameraDrawer || showCalendarDrawer
                || showImageGenDrawer || showTranscribeDrawer || showProfileDrawer || showShareDrawer

            ZStack {
                engine.palette.bg.ignoresSafeArea()

                VStack(spacing: 0) {
                    TopBarView(menuOpen: $menuOpen)

                    if isWide {
                        HStack(alignment: .top, spacing: 16) {
                            ScrollView { StatusGridView().padding(.top, 8) }
                                .frame(width: 220)
                            Spacer(minLength: 0)
                            CoreView(reduceMotion: anyDrawerOpen)
                            Spacer(minLength: 0)
                            ChatInlineView().frame(width: 320)
                        }
                        .padding(.horizontal, 16)
                    } else {
                        ScrollView {
                            VStack(spacing: 14) {
                                StatusGridView()
                                CoreView(reduceMotion: anyDrawerOpen)
                                ChatInlineView().frame(height: 260)
                            }
                            .padding(.horizontal, 16)
                            .padding(.top, 4)
                        }
                    }

                    ControlBarView(showCameraDrawer: $showCameraDrawer)
                }

                // Menü pop-up (üst sağ köşe)
                VStack {
                    HStack {
                        Spacer()
                        MenuPopupView(isOpen: $menuOpen) { target in
                            switch target {
                            case .calendar: showCalendarDrawer = true
                            case .camera: showCameraDrawer = true
                            case .notes: showNotesDrawer = true
                            case .memory: showMemoryDrawer = true
                            case .chat: showChatDrawer = true
                            case .settings: showSettingsDrawer = true
                            case .imageGen: showImageGenDrawer = true
                            case .transcribe: showTranscribeDrawer = true
                            case .profile: showProfileDrawer = true
                            case .share: showShareDrawer = true
                            }
                        }
                        .padding(.trailing, 16)
                        .padding(.top, 64)
                    }
                    Spacer()
                }
                .allowsHitTesting(menuOpen)

                // Çekmeceler
                ChatHistoryDrawerView(isPresented: $showChatDrawer)
                SettingsDrawerView(isPresented: $showSettingsDrawer)
                MemoryDrawerView(isPresented: $showMemoryDrawer)
                NotesDrawerView(isPresented: $showNotesDrawer)
                CameraDrawerView(isPresented: $showCameraDrawer)
                CalendarDrawerView(isPresented: $showCalendarDrawer)
                ImageGenDrawerView(isPresented: $showImageGenDrawer)
                AudioTranscribeDrawerView(isPresented: $showTranscribeDrawer)
                ProfileDrawerView(isPresented: $showProfileDrawer)
                ShareDrawerView(isPresented: $showShareDrawer)

                // Uygulama açma modalı + toast
                AppLaunchModalView()
                ToastView()
            }
            .foregroundStyle(engine.palette.text)
            .animation(.easeOut(duration: 0.2), value: showChatDrawer)
            .animation(.easeOut(duration: 0.2), value: showSettingsDrawer)
            .animation(.easeOut(duration: 0.2), value: showMemoryDrawer)
            .animation(.easeOut(duration: 0.2), value: showNotesDrawer)
            .animation(.easeOut(duration: 0.2), value: showCameraDrawer)
            .animation(.easeOut(duration: 0.2), value: showCalendarDrawer)
            .animation(.easeOut(duration: 0.2), value: showImageGenDrawer)
            .animation(.easeOut(duration: 0.2), value: showTranscribeDrawer)
            .animation(.easeOut(duration: 0.2), value: showProfileDrawer)
            .animation(.easeOut(duration: 0.2), value: showShareDrawer)
            .animation(.easeInOut(duration: 0.15), value: engine.toastMessage)
        }
        .onReceive(NotificationCenter.default.publisher(for: .neoOpenDrawer)) { note in
            let name = note.object as? String
            showChatDrawer = false; showSettingsDrawer = false; showMemoryDrawer = false
            showNotesDrawer = false; showCameraDrawer = false; showCalendarDrawer = false
            showImageGenDrawer = false; showTranscribeDrawer = false; showProfileDrawer = false; showShareDrawer = false
            switch name {
            case "settings": showSettingsDrawer = true
            case "memory": showMemoryDrawer = true
            case "notes": showNotesDrawer = true
            case "camera": showCameraDrawer = true
            case "calendar": showCalendarDrawer = true
            case "chat": showChatDrawer = true
            case "imageGen": showImageGenDrawer = true
            case "transcribe": showTranscribeDrawer = true
            case "profile": showProfileDrawer = true
            case "share": showShareDrawer = true
            default: break
            }
        }
    }
}
