import SwiftUI

// ════════════════════════════════════════════════════════════════
// DrawerContainer.swift — .drawer / .drawer-header / .drawer-body
// karşılığı: sağdan açılan ortak çekmece kabı.
// ════════════════════════════════════════════════════════════════

struct DrawerContainer<Content: View, Trailing: View>: View {
    @EnvironmentObject var engine: NEOEngine
    let title: String
    @Binding var isPresented: Bool
    @ViewBuilder var trailing: () -> Trailing
    @ViewBuilder var content: () -> Content

    init(title: String, isPresented: Binding<Bool>, @ViewBuilder trailing: @escaping () -> Trailing = { EmptyView() }, @ViewBuilder content: @escaping () -> Content) {
        self.title = title
        self._isPresented = isPresented
        self.trailing = trailing
        self.content = content
    }

    var body: some View {
        ZStack(alignment: .trailing) {
            if isPresented {
                Color.black.opacity(0.5)
                    .ignoresSafeArea()
                    .onTapGesture { withAnimation(.easeOut(duration: 0.25)) { isPresented = false } }
                    .transition(.opacity)

                VStack(spacing: 0) {
                    HStack {
                        Text(title)
                            .font(NEOFont.display(17))
                            .foregroundStyle(engine.palette.text)
                        Spacer()
                        trailing()
                        Button(action: { withAnimation(.easeOut(duration: 0.25)) { isPresented = false } }) {
                            Image(systemName: "xmark")
                                .foregroundStyle(engine.palette.textDim)
                                .frame(width: 36, height: 36)
                                .background(engine.palette.panelBg)
                                .clipShape(RoundedRectangle(cornerRadius: 10))
                        }
                    }
                    .padding(16)
                    Divider().overlay(engine.palette.panelBorder)
                    content()
                }
                .frame(width: min(420, UIScreen.main.bounds.width * 0.92))
                .frame(maxHeight: .infinity)
                .background(
                    LinearGradient(colors: [Color(hex: 0x0a1016).opacity(0.97), Color(hex: 0x060a0e).opacity(0.98)], startPoint: .top, endPoint: .bottom)
                )
                .overlay(Rectangle().stroke(engine.palette.panelBorder, lineWidth: 1).opacity(0.6))
                .ignoresSafeArea(edges: .vertical)
                .transition(.move(edge: .trailing))
            }
        }
        .zIndex(60)
    }
}
