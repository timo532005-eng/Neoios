import SwiftUI
import UIKit

// ════════════════════════════════════════════════════════════════
// KeyboardTextField.swift — ControlBarView'daki serbest metin kutusu
// için SwiftUI'nin kendi TextField'ı YERİNE doğrudan UIKit'in
// UITextField'ını saran bir UIViewRepresentable. Görünüm birebir
// NEOTextFieldStyle ile aynı olacak şekilde elle çizildi (bkz.
// SettingsDrawerView.swift'teki NEOTextFieldStyle: aynı dolgu, aynı
// köşe yarıçapı, aynı çerçeve/arka plan renkleri).
//
// NEDEN: SwiftUI'nin TextField + @FocusState ikilisi, Swift
// Playgrounds'ın "Run" ile canlı çalıştırma modunda (Xcode ile
// derlenip cihaza gerçek bir uygulama olarak kurulmuş haliyle değil)
// bazı iPadOS sürümlerinde odak alsa bile klavyeyle hiç konuşmuyor.
// UIKit'in kendi, çok daha eski ve sağlam first-responder/klavye
// altyapısını doğrudan kullanmak, SwiftUI'nin bu özel çalıştırma
// modundaki olası bir tuhaflığını tamamen devre dışı bırakır.
// ════════════════════════════════════════════════════════════════

/// Metni NEOTextFieldStyle'daki gibi yatayda/dikeyde içeri kaydıran
/// (padding uygulayan) düz bir UITextField alt sınıfı. (private DEĞİL:
/// makeUIView/updateUIView bu tipi dönüş/parametre tipinde kullandığı
/// için, protokol uyumluluğunun gerektirdiği erişim düzeyiyle uyumlu
/// olması gerekiyor — bkz. derleyici hatası "Method must be declared
/// fileprivate because its result uses a private type".)
final class PaddedUITextField: UITextField {
    var textInsets = UIEdgeInsets(top: 10, left: 12, bottom: 10, right: 12)
    override func textRect(forBounds bounds: CGRect) -> CGRect { bounds.inset(by: textInsets) }
    override func editingRect(forBounds bounds: CGRect) -> CGRect { bounds.inset(by: textInsets) }
    override func placeholderRect(forBounds bounds: CGRect) -> CGRect { bounds.inset(by: textInsets) }
}

/// @MainActor: bu, doğası gereği yalnızca ana iş parçacığında var olan bir
/// UIKit görünümünü sarmalıyor. Tipin tamamını @MainActor işaretlemek,
/// içindeki kapanışların (onSubmit/onFocusChange) çağıran taraftan (ör.
/// ControlBarView.body içinde engine.palette/engine.isTyping gibi
/// @MainActor özelliklere erişen kapanışlar) "Sendable kapanış" olarak
/// yanlış çıkarılıp derleyici hatası vermesini önler — izolasyonun
/// kendisi veri yarışı güvenliğini zaten sağlıyor.
@MainActor
struct KeyboardTextField: UIViewRepresentable {
    @Binding var text: String
    var placeholder: String
    var textColor: Color
    var placeholderColor: Color
    var borderColor: Color
    /// NEOTextFieldStyle'daki arka planla birebir aynı: Color.white.opacity(0.04)
    var fieldBackground: Color = Color.white.opacity(0.04)
    /// true iken nokta nokta gösterir (API anahtarı/token/secret alanları
    /// için) — eskiden bunun için ayrı bir SecureField/TextField dalı
    /// gerekiyordu, burada tek alan üstünde dinamik olarak değişiyor.
    var isSecure: Bool = false
    var autocapitalization: UITextAutocapitalizationType = .sentences
    var autocorrection: Bool = true
    var keyboardType: UIKeyboardType = .default
    var returnKeyType: UIReturnKeyType = .send
    var onSubmit: () -> Void = {}
    var onFocusChange: (Bool) -> Void = { _ in }

    func makeUIView(context: Context) -> PaddedUITextField {
        let tf = PaddedUITextField()
        tf.delegate = context.coordinator
        tf.font = UIFont.systemFont(ofSize: 17)
        tf.clipsToBounds = true
        tf.layer.cornerRadius = 8
        tf.layer.borderWidth = 1
        tf.setContentHuggingPriority(.defaultLow, for: .horizontal)
        tf.addTarget(context.coordinator, action: #selector(Coordinator.textChanged(_:)), for: .editingChanged)
        applyStyle(to: tf)
        return tf
    }

    /// ÖNEMLİ: Bu olmadan SwiftUI, UIViewRepresentable'ı UITextField'ın
    /// KENDİ içerik boyutuna (placeholder/metin uzunluğuna) göre
    /// boyutlandırıyor — uzun placeholder'lı alanlarda (ör. Tuya/
    /// Cloudflare alanları) bu, kutunun çekmecenin genişliğini
    /// hiçe sayıp dışına taşmasına yol açıyordu. Burada açıkça "bana
    /// önerilen genişliği ver, yüksekliği ben sabitlerim" diyerek
    /// normal bir SwiftUI TextField gibi ebeveyninin genişliğine uymasını
    /// sağlıyoruz.
    func sizeThatFits(_ proposal: ProposedViewSize, uiView: PaddedUITextField, context: Context) -> CGSize? {
        CGSize(width: proposal.width ?? uiView.intrinsicContentSize.width, height: 40)
    }

    func updateUIView(_ uiView: PaddedUITextField, context: Context) {
        // Dış (SwiftUI) durum değiştiyse alanı güncelle — ama kullanıcı o
        // an yazıyorsa (`text` zaten eşitse) imleci sıçratmamak için
        // gereksiz bir atama yapmıyoruz.
        if uiView.text != text { uiView.text = text }
        applyStyle(to: uiView)
        if uiView.attributedPlaceholder?.string != placeholder {
            uiView.attributedPlaceholder = NSAttributedString(
                string: placeholder,
                attributes: [.foregroundColor: UIColor(placeholderColor)]
            )
        }
    }

    private func applyStyle(to tf: PaddedUITextField) {
        tf.textColor = UIColor(textColor)
        tf.backgroundColor = UIColor(fieldBackground)
        tf.layer.borderColor = UIColor(borderColor).cgColor
        tf.tintColor = UIColor(textColor)
        tf.isSecureTextEntry = isSecure
        tf.autocapitalizationType = autocapitalization
        tf.autocorrectionType = autocorrection ? .default : .no
        tf.keyboardType = keyboardType
        tf.returnKeyType = returnKeyType
    }

    func makeCoordinator() -> Coordinator { Coordinator(self) }

    @MainActor
    final class Coordinator: NSObject, UITextFieldDelegate {
        var parent: KeyboardTextField
        init(_ parent: KeyboardTextField) { self.parent = parent }

        @objc func textChanged(_ sender: UITextField) {
            parent.text = sender.text ?? ""
        }

        func textFieldShouldReturn(_ textField: UITextField) -> Bool {
            parent.onSubmit()
            return true
        }

        func textFieldDidBeginEditing(_ textField: UITextField) {
            parent.onFocusChange(true)
        }

        func textFieldDidEndEditing(_ textField: UITextField) {
            parent.onFocusChange(false)
        }
    }
}

extension KeyboardTextField {
    /// Kısayol: renkleri doğrudan projenin paletinden alır — çağrı
    /// yerlerinde tek tek textColor/placeholderColor/borderColor
    /// yazmaya gerek kalmaz (NEOTextFieldStyle'ın SwiftUI TextField
    /// çağrılarındaki kullanımıyla aynı sadelikte).
    init(
        _ placeholder: String,
        text: Binding<String>,
        palette: NEOPalette,
        isSecure: Bool = false,
        autocapitalization: UITextAutocapitalizationType = .sentences,
        autocorrection: Bool = true,
        keyboardType: UIKeyboardType = .default,
        returnKeyType: UIReturnKeyType = .send,
        onSubmit: @escaping () -> Void = {},
        onFocusChange: @escaping (Bool) -> Void = { _ in }
    ) {
        self._text = text
        self.placeholder = placeholder
        self.textColor = palette.text
        self.placeholderColor = palette.textDim
        self.borderColor = palette.panelBorder
        self.isSecure = isSecure
        self.autocapitalization = autocapitalization
        self.autocorrection = autocorrection
        self.keyboardType = keyboardType
        self.returnKeyType = returnKeyType
        self.onSubmit = onSubmit
        self.onFocusChange = onFocusChange
    }
}
