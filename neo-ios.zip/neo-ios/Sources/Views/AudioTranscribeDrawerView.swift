import SwiftUI
import UniformTypeIdentifiers

// ════════════════════════════════════════════════════════════════
// AudioTranscribeDrawerView.swift — YENİ ÖZELLİK: Ses Kaydından
// Yazıya Çevir. Kullanıcının seçtiği bir ses dosyasını Gemini API'ye
// gönderip birebir transkript aldırır (canlı mikrofon dinleme değil —
// bu, zaten var olan "sesli komut" akışından ayrı, dosya tabanlı bir
// özelliktir).
// ════════════════════════════════════════════════════════════════

struct AudioTranscribeDrawerView: View {
    @EnvironmentObject var engine: NEOEngine
    @Binding var isPresented: Bool
    @StateObject private var vm = AudioTranscribeViewModel()
    @State private var showFileImporter = false
    @State private var copied = false

    var body: some View {
        DrawerContainer(title: "Ses Kaydından Yazıya Çevir", isPresented: $isPresented) {
            ScrollView {
                VStack(alignment: .leading, spacing: 14) {
                    FieldHint(text: "Cihazınızdan bir ses dosyası (mp3, m4a, wav vb.) seçin; Gemini API bunu dinleyip olduğu gibi yazıya döksün. Bu, Ayarlar'daki Gemini API anahtarınızı ve metin modelinizi kullanır.")

                    Button("Ses Dosyası Seç") { showFileImporter = true }
                        .buttonStyle(NEOPrimaryButtonStyle())
                        .disabled(vm.state == .working)

                    if let name = vm.fileName {
                        HStack(spacing: 8) {
                            Image(systemName: "waveform").foregroundStyle(engine.palette.primary)
                            Text(name).font(.system(size: 13)).foregroundStyle(engine.palette.textDim).lineLimit(1)
                        }
                    }

                    if vm.state == .working {
                        HStack(spacing: 8) {
                            ProgressView().tint(engine.palette.primary)
                            Text("Ses dosyası dinleniyor ve yazıya dökülüyor…")
                                .font(.system(size: 13))
                                .foregroundStyle(engine.palette.textDim)
                        }
                    }

                    if case .failed(let msg) = vm.state {
                        FieldHint(text: msg, warning: true)
                    }

                    if !vm.transcript.isEmpty {
                        Divider().overlay(engine.palette.panelBorder)
                        Text("TRANSKRİPT").font(NEOFont.mono(10)).tracking(1.5).foregroundStyle(engine.palette.textDim)
                        Text(vm.transcript)
                            .font(.system(size: 14))
                            .foregroundStyle(engine.palette.text)
                            .padding(12)
                            .background(engine.palette.panelBg)
                            .overlay(RoundedRectangle(cornerRadius: 10).stroke(engine.palette.panelBorder, lineWidth: 1))
                            .clipShape(RoundedRectangle(cornerRadius: 10))

                        HStack(spacing: 10) {
                            Button(copied ? "Kopyalandı ✓" : "Kopyala") {
                                UIPasteboard.general.string = vm.transcript
                                copied = true
                                DispatchQueue.main.asyncAfter(deadline: .now() + 1.6) { copied = false }
                            }
                            .buttonStyle(NEOTextButtonStyle())

                            Button("NEO'ya Gönder") {
                                let text = vm.transcript
                                isPresented = false
                                engine.sendMessage(text)
                            }
                            .buttonStyle(NEOTextButtonStyle())

                            Button("Not Olarak Kaydet") { engine.addNote(vm.transcript) }
                                .buttonStyle(NEOTextButtonStyle())
                        }
                    }
                }
                .padding(16)
            }
        }
        .fileImporter(isPresented: $showFileImporter, allowedContentTypes: [.audio, .mp3, .wav, .mpeg4Audio], allowsMultipleSelection: false) { result in
            switch result {
            case .success(let urls):
                if let url = urls.first { vm.transcribe(fileURL: url, engine: engine) }
            case .failure(let error):
                vm.state = .failed("Dosya seçilemedi: \(error.localizedDescription)")
            }
        }
    }
}
