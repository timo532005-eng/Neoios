import Foundation
import UIKit

// ════════════════════════════════════════════════════════════════
// NEOEngine+Media.swift — Yeni özellikler: Görsel Oluşturma ve
// Ses Kaydından Yazıya Çevirme. İkisi de mevcut Gemini API anahtarını
// kullanır; ayrı çekmece görünümleri (ImageGenDrawerView,
// AudioTranscribeDrawerView) tarafından çağrılır.
// ════════════════════════════════════════════════════════════════

enum MediaTaskState: Equatable {
    case idle
    case working
    case failed(String)
}

@MainActor
final class ImageGenViewModel: ObservableObject {
    @Published var prompt = ""
    @Published var state: MediaTaskState = .idle
    @Published var resultImage: UIImage? = nil
    @Published var translatedPromptUsed: String? = nil
    /// 429 (istek limiti) sonrası, "Oluştur" düğmesinin tekrar aktif
    /// olacağı ana kadar kalan saniye. 0 ise engel yok.
    @Published var cooldownSecondsRemaining: Int = 0
    private var cooldownTimer: Timer?

    func generate(engine: NEOEngine) {
        guard cooldownSecondsRemaining == 0 else { return }
        let text = prompt.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return }
        state = .working
        resultImage = nil
        translatedPromptUsed = nil
        Task {
            do {
                // Çeviri (başarısız olursa HATA verir, sessizce devam etmez)
                // + Cloudflare üretimi: ortak çekirdek, bkz. NEOEngine.generateImageCore.
                let result = try await engine.generateImageCore(prompt: text)
                translatedPromptUsed = result.translatedPrompt
                guard let uiImage = UIImage(data: result.data) else {
                    state = .failed("Üretilen görsel çözümlenemedi.")
                    return
                }
                resultImage = uiImage
                state = .idle
            } catch {
                let neoErr = error as? NEOError
                state = .failed(neoErr?.message ?? "Görsel oluşturulamadı.")
                if neoErr?.code == "RATE_LIMIT" {
                    startCooldown(seconds: neoErr?.retryAfterSeconds ?? 20)
                }
            }
        }
    }

    private func startCooldown(seconds: Int) {
        cooldownTimer?.invalidate()
        cooldownSecondsRemaining = max(1, seconds)
        cooldownTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] timer in
            Task { @MainActor in
                guard let self else { timer.invalidate(); return }
                self.cooldownSecondsRemaining -= 1
                if self.cooldownSecondsRemaining <= 0 {
                    self.cooldownSecondsRemaining = 0
                    timer.invalidate()
                }
            }
        }
    }

    func saveToPhotos() {
        guard let img = resultImage else { return }
        UIImageWriteToSavedPhotosAlbum(img, nil, nil, nil)
    }
}

// ════════════════════════════════════════════════════════════════
// Görsel üretim çekirdeği — hem Görsel Oluştur çekmecesi
// (ImageGenViewModel) hem de sohbet içi/uzaktan üretim
// (generateImageInChat) tarafından kullanılır; böylece çeviri ve hata
// davranışı tek yerde durur.
// ════════════════════════════════════════════════════════════════

struct ImageGenResult {
    let data: Data
    /// Gönderilen İngilizce prompt (orijinalden farklıysa), yoksa nil.
    let translatedPrompt: String?
}

extension NEOEngine {
    func generateImageCore(prompt rawPrompt: String) async throws -> ImageGenResult {
        let text = rawPrompt.trimmingCharacters(in: .whitespacesAndNewlines)
        // Cloudflare'in görsel modelleri neredeyse tamamen İngilizce
        // eğitildi; Türkçe (veya başka bir dildeki) prompt'u önce
        // İngilizceye çeviriyoruz — aksi halde model metni anlamayıp
        // tamamen alakasız bir görsel üretebiliyor.
        var effectivePrompt = text
        if !apiKey.isEmpty {
            do {
                let translated = try await GeminiService.translateForImageGen(text: text, apiKey: apiKey, model: model)
                if !translated.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                    effectivePrompt = translated
                }
            } catch {
                // Çeviri başarısızsa sessizce çevrilmemiş metinle devam
                // ETMİYORUZ (alakasız görsellere yol açıyordu) — açık hata.
                let neoErr = error as? NEOError
                throw NEOError(
                    code: neoErr?.code ?? "TRANSLATE",
                    message: "Açıklamanız İngilizceye çevrilemediği için görsel oluşturulmadı (\(neoErr?.message ?? "çeviri hatası")). Çevrilmeden gönderilirse görsel modeli genelde alakasız sonuçlar üretiyor. Ayarlar > AI bölümündeki model adını kontrol edip tekrar deneyin, ya da açıklamayı doğrudan İngilizce yazın.",
                    retryAfterSeconds: neoErr?.retryAfterSeconds
                )
            }
        }
        let translatedUsed: String? = effectivePrompt.lowercased() != text.lowercased() ? effectivePrompt : nil

        let effectiveAccountID = cloudflareAccountID.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            ? CLOUDFLARE_ACCOUNT_ID : cloudflareAccountID
        let effectiveApiToken = cloudflareApiToken.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            ? CLOUDFLARE_API_TOKEN : cloudflareApiToken
        let img = try await CloudflareImageService.generateImage(
            prompt: effectivePrompt,
            accountID: effectiveAccountID,
            apiToken: effectiveApiToken,
            model: imageModel
        )
        return ImageGenResult(data: img.data, translatedPrompt: translatedUsed)
    }

    /// Görseli SOHBETİN içine üretir: kullanıcı mesajını ekler, üretir ve
    /// sonucu NEO mesajı olarak (görselle birlikte) sohbete ekler. Hem iPad'in
    /// sohbetinde hem Paylaşım (uzak tarayıcı) sayfasında görünür.
    func generateImageInChat(_ rawText: String) {
        let text = rawText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return }
        append(role: .user, text: text)
        setState(.thinking, label: "GÖRSEL OLUŞTURULUYOR…")
        Task {
            do {
                let result = try await generateImageCore(prompt: text)
                let caption = result.translatedPrompt.map { "Görsel hazır. (İngilizce prompt: \($0))" } ?? "Görsel hazır."
                append(role: .neo, text: caption, imageData: result.data)
            } catch {
                let neoErr = error as? NEOError
                append(role: .neo, text: neoErr?.message ?? "Görsel oluşturulamadı.", isError: true)
            }
            setState(.idle)
        }
    }
}

@MainActor
final class AudioTranscribeViewModel: ObservableObject {
    @Published var state: MediaTaskState = .idle
    @Published var transcript: String = ""
    @Published var fileName: String? = nil

    func transcribe(fileURL: URL, engine: NEOEngine) {
        state = .working
        transcript = ""
        fileName = fileURL.lastPathComponent
        Task {
            let accessed = fileURL.startAccessingSecurityScopedResource()
            defer { if accessed { fileURL.stopAccessingSecurityScopedResource() } }
            do {
                let data = try Data(contentsOf: fileURL)
                let mime = Self.mimeType(for: fileURL)
                let base64 = data.base64EncodedString()
                let text = try await GeminiService.transcribeAudio(base64Data: base64, mimeType: mime, apiKey: engine.apiKey, model: engine.model)
                transcript = text
                state = .idle
            } catch {
                state = .failed((error as? NEOError)?.message ?? "Ses dosyası okunamadı veya yazıya çevrilemedi.")
            }
        }
    }

    private static func mimeType(for url: URL) -> String {
        switch url.pathExtension.lowercased() {
        case "mp3": return "audio/mp3"
        case "wav": return "audio/wav"
        case "m4a", "caf": return "audio/mp4"
        case "aac": return "audio/aac"
        case "flac": return "audio/flac"
        case "ogg": return "audio/ogg"
        default: return "audio/mp4"
        }
    }
}
