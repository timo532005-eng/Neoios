import Foundation
import UIKit

// ════════════════════════════════════════════════════════════════
// RemoteShareController.swift — "Paylaşım" özelliğinin mantık katmanı.
//
// • Paylaşım başlatılınca rastgele bir JETON üretir; QR koddaki adres
//   bu jetonu içerir ve jetonsuz/yanlış jetonlu HER istek reddedilir (403).
// • Uzak cihaz yalnızca şunları yapabilir: sohbeti (paylaşım BAŞLADIKTAN
//   sonraki mesajları) okumak ve NEO'ya mesaj göndermek — mesaj, iPad'de
//   yazılmış gibi aynı komut hattından (engine.sendMessage) geçer.
// • Uygulama arka plana alınınca (iOS sunucuyu zaten askıya alır)
//   paylaşım otomatik olarak durdurulur.
// ════════════════════════════════════════════════════════════════

private struct APIMessage: Encodable {
    let id: String
    let role: String
    let text: String
    let err: Bool
    /// true ise bu mesajda bir görsel var; /api/image?id=<id> ile alınır.
    let img: Bool
}
private struct APIMessagesResponse: Encodable {
    let reset: Bool
    let state: String
    let label: String
    let messages: [APIMessage]
}
private struct APISendPayload: Decodable {
    let text: String
    let mode: String?
}
private struct APIResult: Encodable {
    let ok: Bool
    let error: String?
}

@MainActor
final class RemoteShareController: ObservableObject {
    @Published private(set) var isActive = false
    @Published private(set) var shareURL: String? = nil
    @Published private(set) var statusMessage = ""
    /// Uzak cihazın NEO'ya en son ulaştığı an (bağlı/bekleniyor göstergesi için).
    @Published private(set) var lastClientActivity: Date? = nil

    private let server = RemoteShareServer()
    private var token = ""
    /// Paylaşım başladığı andaki son mesaj — bundan ÖNCEKİ konuşmalar
    /// uzak cihaza gösterilmez (gizlilik).
    private var baselineMessageID: UUID? = nil
    private weak var engine: NEOEngine?
    private var backgroundObserver: NSObjectProtocol?

    init() {
        backgroundObserver = NotificationCenter.default.addObserver(
            forName: UIApplication.didEnterBackgroundNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            Task { @MainActor in self?.handleDidEnterBackground() }
        }
    }

    // MARK: - Başlat / durdur

    func start(engine: NEOEngine) {
        guard !isActive else { return }
        guard let ip = RemoteShareServer.localIPv4Address() else {
            statusMessage = "Yerel ağ adresi bulunamadı. Cihazınızın bir Wi-Fi ağına bağlı olduğundan emin olun."
            return
        }
        self.engine = engine
        let currentToken = Self.makeToken()
        token = currentToken
        baselineMessageID = engine.chatMessages.last?.id
        statusMessage = "Başlatılıyor…"

        server.onRequest = { [weak self] request in
            guard let self else { return .text(503, "NEO hazır değil.") }
            return await self.route(request)
        }
        server.start { [weak self] result in
            Task { @MainActor in
                guard let self, self.token == currentToken else { return }
                switch result {
                case .success(let port):
                    self.shareURL = "http://\(ip):\(port)/?t=\(currentToken)"
                    self.isActive = true
                    self.statusMessage = ""
                case .failure(let error):
                    self.token = ""
                    self.shareURL = nil
                    self.isActive = false
                    self.statusMessage = "Paylaşım başlatılamadı: \(error.localizedDescription)"
                }
            }
        }
    }

    func stop() {
        server.stop()
        server.onRequest = nil
        isActive = false
        shareURL = nil
        token = ""
        baselineMessageID = nil
        lastClientActivity = nil
    }

    /// Eski QR/bağlantıyı geçersiz kılıp yenisini üretir.
    func regenerate(engine: NEOEngine) {
        stop()
        statusMessage = ""
        start(engine: engine)
    }

    private func handleDidEnterBackground() {
        guard isActive else { return }
        stop()
        statusMessage = "Uygulama arka plana alındığı için paylaşım durduruldu. Gerekirse yeniden başlatın."
    }

    // MARK: - İstek yönlendirme

    private func route(_ request: RemoteHTTPRequest) -> RemoteHTTPResponse {
        guard isActive, !token.isEmpty, request.query["t"] == token else {
            return .text(403, "Erişim reddedildi. NEO üzerinden QR kodu yeniden okutun.")
        }
        guard let engine else { return .text(503, "NEO hazır değil.") }
        lastClientActivity = Date()

        switch (request.method, request.path) {
        case ("GET", "/"):
            return .html(RemoteWebUI.page)

        case ("GET", "/api/messages"):
            return messagesResponse(engine: engine, after: request.query["after"])

        case ("POST", "/api/send"):
            return handleSend(engine: engine, body: request.body)

        case ("GET", "/api/image"):
            guard let idString = request.query["id"],
                  let message = visibleMessages(engine).first(where: { $0.id.uuidString == idString }),
                  let data = message.imageData else {
                return .text(404, "Görsel bulunamadı.")
            }
            return RemoteHTTPResponse(status: 200, contentType: Self.imageContentType(for: data), body: data)

        default:
            return .text(404, "Bulunamadı.")
        }
    }

    /// Uzak cihaza gösterilebilecek mesajlar: paylaşım başlamadan önceki
    /// konuşmalar (ve onların görselleri) HARİÇ.
    private func visibleMessages(_ engine: NEOEngine) -> ArraySlice<ChatMessage> {
        let all = engine.chatMessages
        var startIndex = 0
        if let baseline = baselineMessageID, let idx = all.firstIndex(where: { $0.id == baseline }) {
            startIndex = idx + 1
        }
        return all[startIndex...]
    }

    private static func imageContentType(for data: Data) -> String {
        if data.starts(with: [0x89, 0x50, 0x4E, 0x47]) { return "image/png" }
        if data.starts(with: [0xFF, 0xD8]) { return "image/jpeg" }
        return "application/octet-stream"
    }

    private func messagesResponse(engine: NEOEngine, after: String?) -> RemoteHTTPResponse {
        var visible = visibleMessages(engine)
        var reset = false
        if let after, !after.isEmpty {
            if let idx = visible.firstIndex(where: { $0.id.uuidString == after }) {
                visible = visible[(idx + 1)...]
            } else {
                reset = true // istemcinin bildiği mesaj artık yok (sohbet temizlendi)
            }
        }
        let out = visible.suffix(200).map {
            APIMessage(id: $0.id.uuidString, role: $0.role == .user ? "user" : "neo", text: $0.text, err: $0.isError, img: $0.imageData != nil)
        }
        return jsonResponse(200, APIMessagesResponse(reset: reset, state: engine.state.rawValue, label: engine.stateLabel, messages: out))
    }

    private func handleSend(engine: NEOEngine, body: Data) -> RemoteHTTPResponse {
        guard let payload = try? JSONDecoder().decode(APISendPayload.self, from: body) else {
            return jsonResponse(400, APIResult(ok: false, error: "Geçersiz istek."))
        }
        let text = payload.text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else {
            return jsonResponse(400, APIResult(ok: false, error: "Mesaj boş."))
        }
        guard text.count <= Limits.maxMessageLength else {
            return jsonResponse(400, APIResult(ok: false, error: "Mesaj çok uzun (en fazla \(Limits.maxMessageLength) karakter)."))
        }
        if engine.state == .thinking {
            return jsonResponse(409, APIResult(ok: false, error: "NEO şu anda bir isteği işliyor, birkaç saniye bekleyin."))
        }
        let modeKey = payload.mode ?? "normal"
        if modeKey == "normal" {
            engine.sendMessage(text)
        } else if let mode = AIMode(rawValue: modeKey) {
            if mode == .imageGen {
                // Görsel, uzaktan istendiğinde sohbetin İÇİNE üretilir (çekmece
                // açılmaz) — hem iPad sohbetinde hem tarayıcıda görünür.
                engine.generateImageInChat(text)
            } else {
                engine.sendMessageWithMode(text, mode: mode)
            }
        } else {
            return jsonResponse(400, APIResult(ok: false, error: "Bu mod uzaktan desteklenmiyor."))
        }
        return jsonResponse(200, APIResult(ok: true, error: nil))
    }

    private func jsonResponse<T: Encodable>(_ status: Int, _ value: T) -> RemoteHTTPResponse {
        let data = (try? JSONEncoder().encode(value)) ?? Data("{}".utf8)
        return .json(status, data)
    }

    // MARK: - Jeton

    private static func makeToken() -> String {
        let alphabet = Array("abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789")
        var generator = SystemRandomNumberGenerator()
        return String((0..<24).map { _ in alphabet[Int.random(in: 0..<alphabet.count, using: &generator)] })
    }
}
