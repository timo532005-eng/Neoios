import Foundation

// ════════════════════════════════════════════════════════════════
// NEOEngine+SmartHome.swift — Tuya (akıllı ev) cihazlarını Türkçe
// sesli/yazılı komutlarla ("salon lambasını aç", "prizi kapat")
// eşleştirip açma/kapama. TuyaService.swift'teki imzalı REST
// çağrılarını sarmalar; CommandClassifier + NEOEngine+Commands
// tarafında .appOpen ("aç"/"yak") ve .deviceOff ("kapat"/"söndür")
// komutları buraya yönlendirilir.
// ════════════════════════════════════════════════════════════════

extension NEOEngine {

    /// Ayarlar ekranındaki "Cihazları Getir" düğmesi için: listeyi
    /// yeniden çeker ve sonucu bir toast ile bildirir.
    func refreshTuyaDevices() async {
        guard tuyaConfigured else {
            showToast("Önce Access ID, Access Secret ve UID alanlarını doldurun.")
            return
        }
        do {
            tuyaDevices = try await TuyaService.listDevices(credentials: tuyaCredentials)
            showToast(tuyaDevices.isEmpty ? "Hiç cihaz bulunamadı." : "\(tuyaDevices.count) cihaz bulundu.")
        } catch {
            showToast((error as? NEOError)?.message ?? "Cihaz listesi alınamadı.")
        }
    }

    /// Konuşulan/yazılan isme (ör. "salon lambası") en çok benzeyen,
    /// önbellekteki Tuya cihazını bulur. Tuya/Smart Life uygulamasında
    /// verdiğiniz cihaz adlarıyla eşleştirir (iki yönlü alt dize araması).
    func findTuyaDevice(named raw: String) -> TuyaDevice? {
        let n = AppCatalog.normalizeTr(raw)
        guard !n.isEmpty else { return nil }
        if let exact = tuyaDevices.first(where: { AppCatalog.normalizeTr($0.name) == n }) { return exact }
        return tuyaDevices.first { device in
            let dn = AppCatalog.normalizeTr(device.name)
            return !dn.isEmpty && (dn.contains(n) || n.contains(dn))
        }
    }

    /// "X aç"/"X yak" (turnOn: true) ya da "X kapat"/"X söndür"
    /// (turnOn: false) komutları için ortak işleyici. handleAppOpen
    /// (NEOEngine+Commands.swift), AppCatalog'da eşleşme bulunamadığında
    /// bunu çağırır; .deviceOff komutu ise doğrudan buraya gelir.
    func handleDeviceToggle(name: String, turnOn: Bool) async {
        guard tuyaConfigured else {
            respondLocally("\"\(name)\" adında bağlı bir akıllı ev cihazı bulamadım. Ayarlar > Akıllı Ev (Tuya) bölümünden Tuya hesabınızı bağlarsanız bu tür komutları kullanabilirim.")
            return
        }
        setState(.thinking)
        do {
            if tuyaDevices.isEmpty {
                tuyaDevices = try await TuyaService.listDevices(credentials: tuyaCredentials)
            }
            guard var device = findTuyaDevice(named: name) else {
                respondLocally("\"\(name)\" adında bağlı bir akıllı ev cihazı bulamadım. Cihaz adlarını Tuya/Smart Life uygulamasındaki isimleriyle söylemeyi deneyin.")
                return
            }
            if !device.online {
                // Önbellekteki liste bayat olabilir; göndermeden önce en
                // güncel çevrimiçi durumunu tekrar kontrol ediyoruz.
                tuyaDevices = try await TuyaService.listDevices(credentials: tuyaCredentials)
                if let refreshed = findTuyaDevice(named: name) { device = refreshed }
            }
            guard let code = device.toggleCode else {
                respondLocally("\"\(device.name)\" cihazı için açma/kapama komutunu bulamadım; bu cihaz türü şu an desteklenmiyor olabilir.")
                return
            }
            try await TuyaService.sendCommand(credentials: tuyaCredentials, deviceId: device.id, code: code, value: turnOn)
            if device.online {
                respondLocally(turnOn ? "\"\(device.name)\" açıldı." : "\"\(device.name)\" kapatıldı.")
            } else {
                // Tuya, cihaz çevrimdışıyken bile komutu kabul edip "başarılı"
                // dönebiliyor — cihaza gerçekten ulaşmamış olabilir. Yanlış
                // bir "başarılı" izlenimi vermemek için bunu açıkça belirtiyoruz.
                respondLocally("\"\(device.name)\" \(turnOn ? "açma" : "kapatma") komutunu gönderdim ama cihaz şu anda çevrimdışı görünüyor; gerçekten \(turnOn ? "açıldığını" : "kapandığını") kontrol edin.")
            }
        } catch {
            showError((error as? NEOError)?.message ?? "Akıllı ev komutu gönderilemedi.", recoverDelay: 3.2)
        }
    }
}
