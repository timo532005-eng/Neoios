import Foundation
import CryptoKit

// ════════════════════════════════════════════════════════════════
// TuyaService.swift — Tuya Cloud (IoT Core) OpenAPI entegrasyonu.
//
// Ayrı bir "Tuya SDK" KURULMAZ (Swift Playgrounds'ta üçüncü parti
// paket bağımlılıkları pratik değil); bunun yerine Tuya'nın "cloud
// authorization" imzalama şeması (HMAC-SHA256, bkz. sign(...) altta)
// kullanılarak düz URLSession istekleri imzalanır — tıpkı diğer
// servislerdeki (WeatherService, GeminiService) desen gibi.
//
// Bu, "Google Home" değil "Tuya/Smart Life" hesabınızla çalışır —
// Google Home'da görünen bir cihaz genelde arka planda bir Tuya (veya
// başka bir marka) hesabına bağlıdır; NEO doğrudan o hesaba bağlanır.
//
// KURULUM (Ayarlar > Akıllı Ev (Tuya) bölümündeki ipucu metinleriyle
// aynı adımlar):
//   1. iot.tuya.com adresinde ücretsiz bir geliştirici hesabı açın.
//   2. Cloud > Create Cloud Project ile yeni bir proje oluşturun
//      (veri merkezini/Data Center'ı evinize en yakın bölgeyle aynı
//      seçin — bu uygulamadaki "Veri Merkezi" ayarıyla eşleşmeli).
//   3. Projeyi açın, "Cloud Services" sekmesinden en azından "IoT
//      Core" ve "Smart Home Basic Service" servislerine abone olun.
//   4. Proje detaylarından Access ID (Client ID) ve Access Secret
//      (Client Secret) değerlerini kopyalayıp Ayarlar'a girin.
//   5. Devices > Link App Account > Add App Account > "Tuya App
//      Account Authorization" ile Tuya/Smart Life uygulamanızdan QR
//      kodu okutup hesabınızı bu projeye bağlayın.
//   6. Bağlantı tamamlanınca listede görünen UID'yi kopyalayıp
//      Ayarlar'a girin.
// ════════════════════════════════════════════════════════════════

struct TuyaCredentials {
    let accessId: String
    let accessSecret: String
    let uid: String
    let dataCenter: TuyaDataCenter
}

struct TuyaDevice: Identifiable, Equatable {
    let id: String
    let name: String
    let online: Bool
    let category: String
    /// Bu cihazı açıp kapatmak için kullanılacak DP kodu (ör. "switch_1").
    /// Bilinen röle kodları önceliklendirilerek seçilir (bkz. pickToggleCode) —
    /// böylece LED/kilit gibi boolean göstergeler yanlışlıkla tetiklenmez.
    let toggleCode: String?
}

/// Tuya OpenAPI'nin döndürdüğü, tipi önceden bilinmeyen JSON değerleri
/// (bool/int/double/string) için esnek bir kod çözücü.
enum TuyaJSONValue: Codable {
    case bool(Bool), int(Int), double(Double), string(String), null

    init(from decoder: Decoder) throws {
        let c = try decoder.singleValueContainer()
        if let b = try? c.decode(Bool.self) { self = .bool(b); return }
        if let i = try? c.decode(Int.self) { self = .int(i); return }
        if let d = try? c.decode(Double.self) { self = .double(d); return }
        if let s = try? c.decode(String.self) { self = .string(s); return }
        self = .null
    }
    func encode(to encoder: Encoder) throws {
        var c = encoder.singleValueContainer()
        switch self {
        case .bool(let b): try c.encode(b)
        case .int(let i): try c.encode(i)
        case .double(let d): try c.encode(d)
        case .string(let s): try c.encode(s)
        case .null: try c.encodeNil()
        }
    }
    var boolValue: Bool? { if case .bool(let b) = self { return b }; return nil }
}

private struct TuyaStatusItem: Codable {
    let code: String
    let value: TuyaJSONValue
}

/// Bir cihazın status dizisinden, gerçek "aç/kapat" (röle) DP kodunu seçer.
/// Körü körüne ilk boolean alanı almak riskli: göstergeler (LED ışığı,
/// çocuk kilidi vb.) de boolean olabilir ve yanlışlıkla ONLAR açılıp
/// kapanır — komut Tuya'dan "başarılı" döner ama fiziksel cihaz
/// etkilenmez. Bu yüzden önce bilinen röle DP adlarını, sonra "switch"
/// ile başlayan boolean kodları, en son da gösterge olmayan herhangi bir
/// boolean kodu deniyoruz.
private func pickToggleCode(from status: [TuyaStatusItem]?) -> String? {
    guard let status else { return nil }
    let preferred = ["switch_1", "switch", "switch_led_1", "switch_led", "switch_main"]
    for name in preferred {
        if status.contains(where: { $0.code == name && $0.value.boolValue != nil }) { return name }
    }
    if let switchLike = status.first(where: { $0.code.hasPrefix("switch") && $0.value.boolValue != nil }) {
        return switchLike.code
    }
    let indicatorLike = ["indicator", "backlight", "lock", "light"]
    if let plain = status.first(where: { item in
        item.value.boolValue != nil && !indicatorLike.contains(where: { item.code.lowercased().contains($0) })
    }) {
        return plain.code
    }
    return status.first(where: { $0.value.boolValue != nil })?.code
}
private struct TuyaDeviceRaw: Codable {
    let id: String
    let name: String
    let online: Bool?
    let category: String?
    let status: [TuyaStatusItem]?
}
private struct TuyaListResponse: Codable {
    let result: [TuyaDeviceRaw]?
    let success: Bool?
    let msg: String?
}
private struct TuyaTokenResult: Codable {
    let access_token: String
    let expire_time: Int?
}
private struct TuyaTokenResponse: Codable {
    let result: TuyaTokenResult?
    let success: Bool?
    let msg: String?
}
private struct TuyaCommandResponse: Codable {
    let success: Bool?
    let msg: String?
}

enum TuyaService {

    // MARK: - İmzalama (Tuya "cloud authorization" HMAC-SHA256 şeması)

    private static func sha256Hex(_ data: Data) -> String {
        SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
    }

    private static func hmacSHA256Hex(_ message: String, secret: String) -> String {
        let key = SymmetricKey(data: Data(secret.utf8))
        let mac = HMAC<SHA256>.authenticationCode(for: Data(message.utf8), using: key)
        return Data(mac).map { String(format: "%02X", $0) }.joined()
    }

    /// stringToSign = HTTPMethod \n Content-SHA256 \n (boş Headers satırı) \n url
    /// str = client_id + (varsa access_token) + t + stringToSign
    /// sign = HMAC-SHA256(str, secret) → büyük harf hex
    private static func signature(
        method: String,
        pathWithQuery: String,
        body: Data,
        accessId: String,
        accessSecret: String,
        accessToken: String?,
        timestamp: String
    ) -> String {
        let contentHash = sha256Hex(body)
        let stringToSign = "\(method)\n\(contentHash)\n\n\(pathWithQuery)"
        let prefix = accessId + (accessToken ?? "") + timestamp
        return hmacSHA256Hex(prefix + stringToSign, secret: accessSecret)
    }

    private static func signedRequest(
        creds: TuyaCredentials,
        method: String,
        path: String,
        body: Data,
        accessToken: String?
    ) -> URLRequest? {
        guard let url = URL(string: creds.dataCenter.baseURL + path) else { return nil }
        let t = String(Int(Date().timeIntervalSince1970 * 1000))
        let sig = signature(method: method, pathWithQuery: path, body: body, accessId: creds.accessId, accessSecret: creds.accessSecret, accessToken: accessToken, timestamp: t)
        var request = URLRequest(url: url)
        request.httpMethod = method
        if !body.isEmpty {
            request.httpBody = body
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        }
        request.setValue(creds.accessId, forHTTPHeaderField: "client_id")
        if let accessToken { request.setValue(accessToken, forHTTPHeaderField: "access_token") }
        request.setValue(sig, forHTTPHeaderField: "sign")
        request.setValue(t, forHTTPHeaderField: "t")
        request.setValue("HMAC-SHA256", forHTTPHeaderField: "sign_method")
        return request
    }

    // MARK: - Token (grant_type=1, "basit mod" bulut yetkilendirmesi)

    private static func fetchToken(_ creds: TuyaCredentials) async throws -> String {
        guard !creds.accessId.isEmpty, !creds.accessSecret.isEmpty else {
            throw NEOError(code: "TUYA_CONFIG", message: "Tuya Access ID / Access Secret alanları boş. Ayarlar > Akıllı Ev (Tuya) bölümünden doldurun.")
        }
        let path = "/v1.0/token?grant_type=1"
        guard let request = signedRequest(creds: creds, method: "GET", path: path, body: Data(), accessToken: nil) else {
            throw NEOError(code: "BAD_URL", message: "Geçersiz Tuya veri merkezi adresi.")
        }
        let data = try await perform(request, networkErrorMessage: "Tuya kimlik doğrulama servisine ulaşılamadı.")
        let decoded = try? JSONDecoder().decode(TuyaTokenResponse.self, from: data)
        guard decoded?.success == true, let token = decoded?.result?.access_token else {
            throw NEOError(code: "TUYA_AUTH", message: "Tuya erişim anahtarı alınamadı\(decoded?.msg.map { ": \($0)" } ?? ""). Access ID/Secret ve veri merkezi (data center) doğru mu kontrol edin.")
        }
        return token
    }

    // MARK: - Cihaz listesi

    static func listDevices(credentials creds: TuyaCredentials) async throws -> [TuyaDevice] {
        guard !creds.uid.isEmpty else {
            throw NEOError(code: "TUYA_CONFIG", message: "Tuya UID alanı boş. Ayarlar > Akıllı Ev (Tuya) bölümünden hesabınızı bağlayıp UID'nizi girin.")
        }
        let token = try await fetchToken(creds)
        let path = "/v1.0/users/\(creds.uid)/devices"
        guard let request = signedRequest(creds: creds, method: "GET", path: path, body: Data(), accessToken: token) else {
            throw NEOError(code: "BAD_URL", message: "Geçersiz Tuya veri merkezi adresi.")
        }
        let data = try await perform(request, networkErrorMessage: "Tuya cihaz listesi alınamadı.")
        let decoded = try? JSONDecoder().decode(TuyaListResponse.self, from: data)
        guard decoded?.success == true else {
            throw NEOError(code: "TUYA_DEVICES", message: "Tuya cihaz listesi alınamadı\(decoded?.msg.map { ": \($0)" } ?? "").")
        }
        return (decoded?.result ?? []).map { raw in
            let toggleCode = pickToggleCode(from: raw.status)
            return TuyaDevice(id: raw.id, name: raw.name, online: raw.online ?? false, category: raw.category ?? "", toggleCode: toggleCode)
        }
    }

    // MARK: - Cihaz komutu gönder (aç/kapat)

    static func sendCommand(credentials creds: TuyaCredentials, deviceId: String, code: String, value: Bool) async throws {
        let token = try await fetchToken(creds)
        let path = "/v1.0/devices/\(deviceId)/commands"
        struct CommandItem: Codable { let code: String; let value: Bool }
        struct CommandBody: Codable { let commands: [CommandItem] }
        guard let body = try? JSONEncoder().encode(CommandBody(commands: [CommandItem(code: code, value: value)])) else {
            throw NEOError(code: "ENCODE", message: "Komut hazırlanamadı.")
        }
        guard let request = signedRequest(creds: creds, method: "POST", path: path, body: body, accessToken: token) else {
            throw NEOError(code: "BAD_URL", message: "Geçersiz Tuya veri merkezi adresi.")
        }
        let data = try await perform(request, networkErrorMessage: "Tuya cihazına komut gönderilemedi.")
        let decoded = try? JSONDecoder().decode(TuyaCommandResponse.self, from: data)
        guard decoded?.success == true else {
            throw NEOError(code: "TUYA_COMMAND", message: "Cihaza komut gönderilemedi\(decoded?.msg.map { ": \($0)" } ?? "").")
        }
    }

    // MARK: - Ortak ağ yardımcısı

    private static func perform(_ request: URLRequest, networkErrorMessage: String) async throws -> Data {
        let data: Data
        let response: URLResponse
        do {
            (data, response) = try await URLSession.shared.data(for: request)
        } catch {
            throw NEOError(code: "NETWORK", message: networkErrorMessage + " İnternet bağlantınızı kontrol edin.")
        }
        guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else {
            throw NEOError(code: "HTTP", message: "Tuya servisi bir hata döndürdü.")
        }
        return data
    }
}
