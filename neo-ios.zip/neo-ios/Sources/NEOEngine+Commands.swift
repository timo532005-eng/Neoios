import Foundation
import UIKit

// ════════════════════════════════════════════════════════════════
// NEOEngine+Commands.swift — orijinal bölüm 10 (KOMUT YÖNLENDİRME),
// 10.1 (HAVA DURUMU), 10.1.1 (TAKVİM), 10.2 (UYGULAMA AÇMA) ve
// bölüm 11 (GEMİNİ) ve bölüm 14 (MESAJ GÖNDERME) karşılığı.
// ════════════════════════════════════════════════════════════════

extension NEOEngine {

    // MARK: - Mesaj gönderme (bölüm 14)

    func sendMessage(_ rawText: String, fromVoice: Bool = false) {
        let text = rawText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else {
            showError("Boş bir mesaj gönderilemez.", recoverDelay: 1.5)
            return
        }
        guard text.count <= Limits.maxMessageLength else {
            showError("Mesaj çok uzun (\(text.count) karakter). Lütfen \(Limits.maxMessageLength) karakterin altında bir mesaj yazın.", recoverDelay: 2.4)
            return
        }
        append(role: .user, text: text)
        let cmd = CommandClassifier.classify(text)
        Task { await handle(cmd) }
    }

    /// Metin kutusunda "@" ile seçilen bir AI moduyla TEK bir mesaj
    /// gönderir (bkz. ControlBarView). Yerel komut sınıflandırıcısını
    /// (CommandClassifier) BİLEREK atlıyoruz — kullanıcı özellikle bir
    /// modu seçtiyse (ör. "Derin Düşünme"), mesajının yanlışlıkla hava
    /// durumu/takvim gibi başka bir yerel komutla eşleşmesini istemeyiz.
    func sendMessageWithMode(_ rawText: String, mode: AIMode) {
        let text = rawText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else {
            showError("Boş bir mesaj gönderilemez.", recoverDelay: 1.5)
            return
        }
        guard text.count <= Limits.maxMessageLength else {
            showError("Mesaj çok uzun (\(text.count) karakter). Lütfen \(Limits.maxMessageLength) karakterin altında bir mesaj yazın.", recoverDelay: 2.4)
            return
        }
        append(role: .user, text: text)
        switch mode {
        case .imageGen:
            pendingImagePrompt = text
            postDrawer("imageGen")
            respondLocally("Görsel Oluştur ekranını açtım ve isteğinizi gönderdim.")
        case .deepThink:
            Task { await callGeminiAndRespond(text, thinkingLevel: "high") }
        case .quickAnswer:
            Task { await callGeminiAndRespond(text, thinkingLevel: "low", extraSystemInstruction: "Bu TEK mesaj için: cevabını olabildiğince kısa tut, mümkünse tek-iki cümleyi geçme, gereksiz açıklama ekleme.") }
        case .translate:
            Task { await callGeminiAndRespond(text, thinkingLevel: "low", extraSystemInstruction: "Bu TEK mesaj bir ÇEVİRİ isteğidir. Kullanıcının metninde hedef dil açıkça belirtilmişse (ör. \"İngilizceye:\", \"to Spanish:\", \"Fransızca:\") o dile çevir. Hedef dil belirtilmemişse: metin Türkçe ise İngilizceye, Türkçe DEĞİLSE Türkçeye çevir. SADECE çeviriyi yaz — hedef dil etiketini, tırnak işaretini, parantez içi açıklamayı veya başka hiçbir ek metni ekleme.") }
        case .buddy:
            Task { await callGeminiAndRespond(text, thinkingLevel: "low", extraSystemInstruction: "Bu TEK mesaj için üslubunu değiştir: resmi, robotik asistan tonunu bırak; samimi, sıcak, esprili, yakın bir arkadaşla konuşur gibi konuş. \"Kanka\", \"dostum\", \"abi/abla\" gibi senli-benli hitaplar, günlük konuşma dili ve doğal bir akış kullanabilirsin; istersen uygun yerlerde emoji de ekleyebilirsin. Ama hâlâ doğru, yardımcı ve dürüst ol — sadece ton değişiyor, verdiğin bilginin kalitesi değil.") }
        }
    }

    // MARK: - Komut yönlendirme

    func handle(_ cmd: ParsedCommand) async {
        switch cmd {
        case .ui(let action): handleUi(action)
        case .memory(let action, let payload): handleMemoryCmd(action: action, payload: payload)
        case .notes(let action, let payload): handleNotesCmd(action: action, payload: payload)
        case .reminder(let minutes, let payload): handleReminderCmd(minutes: minutes, payload: payload)
        case .calculatorResult(_, let result): respondLocally("Sonuç: " + formatNumberTr(result))
        case .datetime(let action): handleDatetime(action)
        case .websearch(let payload):
            append(role: .neo, text: "Bu sürümde canlı internet taraması yapamıyorum (bir arama aracı bağlı değil). Sorunuzu kendi bilgimle cevaplamayı deneyeceğim.")
            await callGeminiAndRespond(payload)
        case .weather(let city): await handleWeather(city: city)
        case .calendar(let payload): await handleCalendar(payload: payload)
        case .appOpen(let name): await handleAppOpen(name: name)
        case .deviceOff(let name): await handleDeviceToggle(name: name, turnOn: false)
        case .gemini(let payload): await callGeminiAndRespond(payload)
        }
    }

    private func formatNumberTr(_ n: Double) -> String {
        let nf = NumberFormatter()
        nf.locale = Locale(identifier: "tr_TR")
        nf.maximumFractionDigits = 6
        nf.numberStyle = .decimal
        return nf.string(from: NSNumber(value: n)) ?? String(n)
    }

    // MARK: - UI komutları

    private func handleUi(_ action: String) {
        switch action {
        case "openSettings": respondLocally("Ayarlar açıldı."); postDrawer("settings")
        case "closeDrawers": postDrawer(nil); respondLocally("Anlaşıldı.")
        case "clearChat": clearChat(); setState(.idle)
        case "showMemory": postDrawer("memory"); respondLocally("Hafıza paneli açıldı.")
        case "openCamera": postDrawer("camera"); respondLocally("Kamera açıldı. Görüntüyü analiz etmemi istediğinizde \"Çek ve Analiz Et\" düğmesine basabilirsiniz.")
        case "openCalendar": postDrawer("calendar"); respondLocally("Takvim açıldı.")
        case "openProfile":
            postDrawer("profile")
            respondLocally(userProfile.isEmpty
                ? "Profilim açıldı. Beni tanımanı istersen adını, ilgi alanlarını ve nasıl davranmamı istediğini buradan girebilirsin."
                : "Profilim açıldı.")
        case "openImageGen": postDrawer("imageGen"); respondLocally("Görsel oluşturma paneli açıldı. Ne çizmemi istersiniz?")
        case "openTranscribe": postDrawer("transcribe"); respondLocally("Ses kaydından yazıya çevirme paneli açıldı.")
        case "listMemory":
            let text = memory.isEmpty ? "Şu an hakkınızda kayıtlı bir bilgi yok." : "Hakkınızda kayıtlı bilgiler: " + memory.map(\.text).joined(separator: "; ")
            respondLocally(text)
        case "stop":
            tts.stop(); speech.stop(); setState(.idle)
        default: break
        }
    }

    /// Çekmece açma isteklerini View katmanına iletir (NotificationCenter
    /// yerine basit bir Published alanla da yapılabilir; burada engine'in
    /// UI katmanından bağımsız kalması için bildirim kullanılıyor).
    private func postDrawer(_ name: String?) {
        NotificationCenter.default.post(name: .neoOpenDrawer, object: name)
    }

    // MARK: - Hafıza komutları

    private func handleMemoryCmd(action: String, payload: String) {
        let content = payload.trimmingCharacters(in: .whitespacesAndNewlines)
        if action == "remember" {
            guard !content.isEmpty else {
                respondLocally("Ne hatırlamamı istediğinizi belirtmediniz. Örneğin: \"bunu hatırla: Python öğreniyorum.\"")
                return
            }
            saveMemory(content)
            respondLocally("Kaydettim: \"\(content)\"")
        } else if action == "forget" {
            if !content.isEmpty {
                let before = memory.count
                memory.removeAll { $0.text.lowercased().contains(content.lowercased()) }
                let removed = before - memory.count
                respondLocally(removed > 0 ? "\(removed) hafıza kaydını sildim." : "Bu ifadeyle eşleşen bir hafıza kaydı bulamadım.")
            } else {
                let removed = deleteLastMemory()
                respondLocally(removed != nil ? "Son kaydı sildim: \"\(removed!.text)\"" : "Silinecek bir hafıza kaydı yok.")
            }
        }
    }

    // MARK: - Not komutları

    private func handleNotesCmd(action: String, payload: String) {
        let content = payload.trimmingCharacters(in: .whitespacesAndNewlines)
        if action == "add" {
            guard !content.isEmpty else { respondLocally("Not içeriğini anlayamadım."); return }
            addNote(content)
            respondLocally("Not eklendi: \"\(content)\"")
        } else if action == "list" {
            let text = notes.isEmpty ? "Henüz bir notunuz yok." : "Notlarınız: " + notes.map(\.text).joined(separator: "; ")
            respondLocally(text)
        }
    }

    // MARK: - Hatırlatıcı komutu

    private func handleReminderCmd(minutes: Int, payload: String) {
        let content = payload.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "hatırlatma" : payload
        guard minutes > 0 else { respondLocally("Kaç dakika sonra hatırlatmamı istediğinizi anlayamadım."); return }
        addReminder(content, delayMinutes: minutes)
        respondLocally("\(minutes) dakika sonra hatırlatacağım: \"\(content)\". Not: bu hatırlatıcı yalnızca uygulama açık kaldığı sürece çalışır.")
    }

    // MARK: - Tarih/saat

    private func handleDatetime(_ action: String) {
        let now = Date()
        let df = DateFormatter()
        df.locale = Locale(identifier: "tr_TR")
        if action == "time" {
            df.dateFormat = "HH:mm"
            respondLocally("Şu an saat \(df.string(from: now)).")
        } else {
            df.dateFormat = "EEEE d MMMM yyyy"
            respondLocally("Bugün \(df.string(from: now)).")
        }
    }

    // MARK: - Hava durumu (bölüm 10.1)

    private func handleWeather(city cityFromCmd: String?) async {
        setState(.thinking)
        do {
            let loc = try await resolveWeatherLocation(cityFromCmd)
            let w = try await WeatherService.fetchWeather(loc)
            let place = loc.label ?? cityFromCmd ?? "bulunduğunuz konum"
            let desc = Weather.desc(w.code)
            weatherPanel = "\(w.temp)° \(Weather.emoji(w.code))"; weatherPanelLevel = .ok
            respondLocally("\(place) için hava şu anda \(w.temp)°C, \(desc). Nem yüzde \(w.humidity), rüzgar \(w.wind) km/s.")
        } catch {
            weatherPanel = "HATA"; weatherPanelLevel = .bad
            showError((error as? NEOError)?.message ?? "Hava durumu alınamadı.", recoverDelay: 3.2)
        }
    }

    private func resolveWeatherLocation(_ cityFromCmd: String?) async throws -> ResolvedLocation {
        let city = (cityFromCmd?.trimmingCharacters(in: .whitespaces)).flatMap { $0.isEmpty ? nil : $0 } ?? (defaultCity.isEmpty ? nil : defaultCity)
        if let city { return try await WeatherService.geocodeCity(city) }
        do {
            return try await OneShotLocationFetcher().fetch()
        } catch {
            throw NEOError(code: "LOCATION", message: "Konumunuzu belirleyemedim. Ayarlar > Konum & Hava Durumu bölümünden bir \"varsayılan şehir\" girebilir ya da \"İstanbul hava durumu\" gibi şehir adıyla sorabilirsiniz.")
        }
    }

    // MARK: - Takvim (bölüm 10.1.1)

    func loadEvents() { events = Store.get(StorageKeys.events, fallback: []) }
    func persistEvents() { Store.set(StorageKeys.events, events) }

    func addCalendarEvent(title: String, date: String, time: String?, notes: String = "") -> CalendarEventEntry {
        let entry = CalendarEventEntry(title: title, date: date, time: time, notes: notes)
        events.append(entry)
        events.sort { ($0.date + ($0.time ?? "00:00")) < ($1.date + ($1.time ?? "00:00")) }
        return entry
    }
    func removeCalendarEvent(id: String) -> CalendarEventEntry? {
        guard let idx = events.firstIndex(where: { $0.id == id }) else { return nil }
        return events.remove(at: idx)
    }
    func removeCalendarEvent(hint: String?) -> CalendarEventEntry? {
        guard let hint, !hint.isEmpty else { return nil }
        let n = AppCatalog.normalizeTr(hint)
        guard !n.isEmpty else { return nil }
        if let idx = events.firstIndex(where: { AppCatalog.normalizeTr($0.title) == n }) {
            return events.remove(at: idx)
        }
        if let idx = events.firstIndex(where: { AppCatalog.normalizeTr($0.title).contains(n) || n.contains(AppCatalog.normalizeTr($0.title)) }) {
            return events.remove(at: idx)
        }
        return nil
    }
    func events(for dateISO: String) -> [CalendarEventEntry] {
        events.filter { $0.date == dateISO }.sorted { ($0.time ?? "") < ($1.time ?? "") }
    }
    func events(from startISO: String, to endISO: String) -> [CalendarEventEntry] {
        events.filter { $0.date >= startISO && $0.date <= endISO }.sorted { ($0.date + ($0.time ?? "")) < ($1.date + ($1.time ?? "")) }
    }

    static func todayISO() -> String {
        let df = DateFormatter(); df.dateFormat = "yyyy-MM-dd"; df.timeZone = .current
        return df.string(from: Date())
    }
    static func addDaysISO(_ iso: String, _ days: Int) -> String {
        let df = DateFormatter(); df.dateFormat = "yyyy-MM-dd"
        guard let d = df.date(from: iso), let added = Calendar.current.date(byAdding: .day, value: days, to: d) else { return iso }
        return df.string(from: added)
    }
    static func formatDateTr(_ iso: String) -> String {
        let inDf = DateFormatter(); inDf.dateFormat = "yyyy-MM-dd"
        guard let d = inDf.date(from: iso) else { return iso }
        let out = DateFormatter(); out.locale = Locale(identifier: "tr_TR"); out.dateFormat = "d MMMM yyyy EEEE"
        return out.string(from: d)
    }
    static func capitalizeTr(_ s: String) -> String {
        guard let f = s.first else { return s }
        return String(f).uppercased(with: Locale(identifier: "tr_TR")) + s.dropFirst()
    }

    func formatAddConfirmation(_ entry: CalendarEventEntry) -> String {
        let dateLabel = Self.formatDateTr(entry.date)
        let timeLabel = entry.time.map { "saat \($0)'te" } ?? "tüm gün süren bir etkinlik olarak"
        return "\"\(entry.title)\" etkinliğini \(dateLabel) tarihine, \(timeLabel) takviminize ekledim."
    }

    private func buildCalendarQueryAnswer(_ parsed: GeminiService.CalendarIntent) -> String {
        let today = Self.todayISO()
        var startISO = today, endISO = today, label = "bugün"
        switch parsed.query_scope ?? "today" {
        case "tomorrow": startISO = Self.addDaysISO(today, 1); endISO = startISO; label = "yarın"
        case "week": endISO = Self.addDaysISO(today, 6); label = "bu hafta"
        case "date":
            if let d = parsed.date { startISO = d; endISO = d; label = Self.formatDateTr(d) }
        case "today": break
        default: endISO = Self.addDaysISO(today, 30); label = "önümüzdeki 30 gün içinde"
        }
        let evs = events(from: startISO, to: endISO)
        if evs.isEmpty { return "\(Self.capitalizeTr(label)) için takviminizde kayıtlı bir etkinlik görünmüyor." }
        let multiDay = startISO != endISO
        let lines = evs.map { e -> String in
            let dateLabel = multiDay ? Self.formatDateTr(e.date) + " — " : ""
            let timeLabel = e.time ?? "tüm gün"
            return "\(dateLabel)\(e.title) (\(timeLabel))"
        }
        return "\(Self.capitalizeTr(label)) için \(evs.count) etkinliğiniz var: " + lines.joined(separator: "; ") + "."
    }

    private func handleCalendar(payload: String) async {
        setState(.thinking)
        do {
            let parsed = try await GeminiService.parseCalendarIntent(text: payload, apiKey: apiKey, model: model)
            switch parsed.intent {
            case "add":
                let entry = addCalendarEvent(title: parsed.title ?? "Etkinlik", date: parsed.date ?? Self.todayISO(), time: parsed.time)
                calendarSelectedDate = entry.date
                respondLocally(formatAddConfirmation(entry))
            case "remove":
                if let removed = removeCalendarEvent(hint: parsed.target_hint ?? parsed.title) {
                    respondLocally("\"\(removed.title)\" adlı etkinliği takviminizden sildim.")
                } else {
                    respondLocally("Belirttiğinize eşleşen bir etkinlik bulamadım. Takvim panelinden silmek istediğiniz etkinliği elle de kaldırabilirsiniz.")
                }
            case "query":
                respondLocally(buildCalendarQueryAnswer(parsed))
            default:
                await callGeminiAndRespond(payload)
            }
        } catch {
            showError((error as? NEOError)?.message ?? "Takvim isteği işlenemedi.", recoverDelay: 3.2)
        }
    }

    // MARK: - Uygulama açma (bölüm 10.2)

    private func handleAppOpen(name: String) async {
        if let match = AppCatalog.findMatch(name) {
            if match.internalTarget == "camera" {
                postDrawer("camera")
                respondLocally("Kamera açıldı. Görüntüyü analiz etmemi istediğinizde \"Çek ve Analiz Et\" düğmesine basabilirsiniz.")
                return
            }
            if match.internalTarget == "calendar" {
                postDrawer("calendar")
                respondLocally("Takvim açıldı.")
                return
            }
            if match.internalTarget == "settings" {
                postDrawer("settings")
                respondLocally("Ayarlar açıldı.")
                return
            }
            if match.internalTarget == "profile" {
                postDrawer("profile")
                respondLocally("Profilim açıldı.")
                return
            }
            if match.internalTarget == "share" {
                postDrawer("share")
                respondLocally("Paylaşım ekranı açıldı.")
                return
            }
            pendingAppLaunch = match
            showAppLaunchModal = true
            respondLocally("\"\(match.label)\" için bir açma penceresi gösterdim; \"Aç\" düğmesine basarak deneyebilirsiniz. Sistem güvenlik kısıtlamaları nedeniyle uygulamaları düğmeye basılmadan, kendiliğimden açamam.")
            return
        }
        // AppCatalog'da eşleşme yok: Ayarlar > Akıllı Ev (Tuya) bölümünden
        // bağlanmış bir cihaz olabilir mi diye bakıyoruz ("ışığı aç" vb.).
        if tuyaConfigured {
            await handleDeviceToggle(name: name, turnOn: true)
            return
        }
        pendingAppLaunch = AppCatalogEntry(keys: [], label: name.trimmingCharacters(in: .whitespaces))
        showAppLaunchModal = true
        respondLocally("\"\(name)\" için bir açma penceresi gösterdim; \"Aç\" düğmesine basarak deneyebilirsiniz. Sistem güvenlik kısıtlamaları nedeniyle uygulamaları düğmeye basılmadan, kendiliğimden açamam.")
    }

    func triggerAppLaunch() {
        guard let app = pendingAppLaunch else { return }
        showAppLaunchModal = false
        pendingAppLaunch = nil
        guard app.scheme != nil || app.webUrl != nil else {
            showToast("\"\(app.label)\" için tanımlı bir bağlantım yok; cihazınızda elle açmanız gerekebilir.")
            return
        }
        if let scheme = app.scheme, let url = URL(string: scheme) {
            UIApplicationOpener.open(url)
        } else if let webUrl = app.webUrl, let url = URL(string: webUrl) {
            UIApplicationOpener.open(url)
        }
    }

    // MARK: - Gemini (bölüm 11)

    func callGeminiAndRespond(_ userText: String, thinkingLevel: String = "low", extraSystemInstruction: String? = nil) async {
        setState(.thinking)
        do {
            let sysPrompt = extraSystemInstruction.map { buildSystemPrompt() + "\n\n" + $0 } ?? buildSystemPrompt()
            let reply = try await GeminiService.callText(userText: userText, history: history, historySummary: historySummary, systemPrompt: sysPrompt, apiKey: apiKey, model: model, temperature: temperature, thinkingLevel: thinkingLevel)
            history.append(HistoryTurn(role: "user", text: userText))
            history.append(HistoryTurn(role: "model", text: reply))
            compressHistoryIfNeeded()
            append(role: .neo, text: reply)
            updateAiPanel()
            if autoSpeak { speakNow(reply) } else { setState(.idle) }
        } catch {
            updateAiPanel()
            showError((error as? NEOError)?.message ?? "Bilinmeyen bir hata oluştu.", recoverDelay: 3.2)
        }
    }

    private func compressHistoryIfNeeded() {
        guard history.count > Limits.maxHistoryMessages else { return }
        let batch = Array(history.prefix(Limits.compressBatchSize))
        history.removeFirst(Limits.compressBatchSize)
        let joined = batch.map { ($0.role == "user" ? "Kullanıcı: " : "NEO: ") + $0.text }.joined(separator: "\n")
        let shortened = joined.count > 600 ? String(joined.prefix(600)) + "…" : joined
        historySummary = (historySummary.isEmpty ? "" : historySummary + " ") + shortened
        if historySummary.count > 1800 { historySummary = String(historySummary.suffix(1800)) }
    }

    // MARK: - Kamera analizi

    func captureAndAnalyze(promptOverride: String?) async {
        guard let data = await camera.captureFrame() else {
            showToast("Kamera görüntüsü henüz hazır değil.")
            return
        }
        let base64 = data.base64EncodedString()
        let prompt = (promptOverride?.trimmingCharacters(in: .whitespaces)).flatMap { $0.isEmpty ? nil : $0 } ?? "Bu görüntüde ne görüyorsun? Kısa ve net bir şekilde Türkçe açıkla."
        append(role: .user, text: "[Kamera görüntüsü] \(prompt)")
        setState(.thinking)
        do {
            let reply = try await GeminiService.callVision(base64Data: base64, promptText: prompt, mimeType: "image/jpeg", systemPrompt: buildSystemPrompt(), apiKey: apiKey, model: model, temperature: temperature)
            append(role: .neo, text: reply)
            updateAiPanel()
            if autoSpeak { speakNow(reply) } else { setState(.idle) }
        } catch {
            updateAiPanel()
            showError((error as? NEOError)?.message ?? "Görüntü analiz edilemedi.", recoverDelay: 3.2)
        }
    }

    func analyzeAttachedImage(_ data: Data) async {
        let base64 = data.base64EncodedString()
        append(role: .user, text: "[Fotoğraf] Bu görüntüyü analiz eder misin?")
        setState(.thinking)
        do {
            let reply = try await GeminiService.callVision(base64Data: base64, promptText: "Bu görüntüde ne görüyorsun? Kısa ve net bir şekilde Türkçe açıkla.", mimeType: "image/jpeg", systemPrompt: buildSystemPrompt(), apiKey: apiKey, model: model, temperature: temperature)
            append(role: .neo, text: reply)
            updateAiPanel()
            if autoSpeak { speakNow(reply) } else { setState(.idle) }
        } catch {
            updateAiPanel()
            showError((error as? NEOError)?.message ?? "Fotoğraf analiz edilemedi.", recoverDelay: 3.2)
        }
    }
}

extension Notification.Name {
    static let neoOpenDrawer = Notification.Name("neoOpenDrawer")
}

extension Double {
    func clamped(to range: ClosedRange<Double>) -> Double {
        Swift.min(Swift.max(self, range.lowerBound), range.upperBound)
    }
}

/// window.open()/window.location.href karşılığı — basit bir UIApplication sarmalayıcısı.
enum UIApplicationOpener {
    @MainActor static func open(_ url: URL) {
        UIApplication.shared.open(url, options: [:], completionHandler: nil)
    }
}
