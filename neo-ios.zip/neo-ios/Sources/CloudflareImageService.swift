import Foundation

// ════════════════════════════════════════════════════════════════
// CloudflareImageService.swift — Cloudflare Workers AI REST API ile
// metinden görsel oluşturma. Model: @cf/black-forest-labs/flux-1-schnell
//
// Bu, Cloudflare'in resmi cURL örneğinin birebir Swift/URLSession
// karşılığıdır:
//
//   curl https://api.cloudflare.com/client/v4/accounts/$CLOUDFLARE_ACCOUNT_ID/ai/run/@cf/black-forest-labs/flux-1-schnell \
//     -X POST \
//     -H "Authorization: Bearer $CLOUDFLARE_API_TOKEN" \
//     -d '{ "prompt": "cyberpunk cat", "seed": "Random positive integer" }'
//
// NOT: Cloudflare'in resmi model kimliği tiredir: "flux-1-schnell"
// ("flux.1-schnell" değil). Yanlış yazılırsa 404 (model/endpoint
// bulunamadı) hatası alınır.
//
// Başarılı cevap gövdesi şu şekildedir:
//   { "result": { "image": "<base64 JPEG>" }, "success": true, "errors": [], "messages": [] }
// ════════════════════════════════════════════════════════════════

enum CloudflareImageService {
    /// Kolayca değiştirilebilecek varsayılan model kimliği.
    static let defaultModel = "@cf/black-forest-labs/flux-1-schnell"

    struct GeneratedImage {
        let data: Data
        let mimeType: String
    }

    private struct RequestBody: Codable {
        let prompt: String
        var steps: Int? = nil
    }

    private struct CFErrorItem: Codable {
        let code: Int?
        let message: String?
    }

    private struct CFResult: Codable {
        let image: String?
    }

    private struct CFResponse: Codable {
        let result: CFResult?
        let success: Bool?
        let errors: [CFErrorItem]?
        let messages: [String]?
    }

    static func generateImage(
        prompt: String,
        accountID: String,
        apiToken: String,
        model: String = CloudflareImageService.defaultModel,
        steps: Int? = nil,
        timeout: TimeInterval = 60
    ) async throws -> GeneratedImage {
        let trimmedAccount = accountID.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedToken = apiToken.trimmingCharacters(in: .whitespacesAndNewlines)

        guard !trimmedAccount.isEmpty, trimmedAccount != "YOUR_ACCOUNT_ID" else {
            throw NEOError(code: "NO_ACCOUNT", message: "Cloudflare ACCOUNT_ID ayarlanmamış. MyApp.swift dosyasının en üstündeki CLOUDFLARE_ACCOUNT_ID sabitini kendi Cloudflare hesap kimliğinizle değiştirin.")
        }
        guard !trimmedToken.isEmpty, trimmedToken != "YOUR_API_TOKEN" else {
            throw NEOError(code: "NO_TOKEN", message: "Cloudflare API_TOKEN ayarlanmamış. MyApp.swift dosyasının en üstündeki CLOUDFLARE_API_TOKEN sabitini kendi Cloudflare API token'ınızla değiştirin (token'ın \"Workers AI\" yazma izni olmalı).")
        }
        let trimmedPrompt = prompt.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedPrompt.isEmpty else {
            throw NEOError(code: "EMPTY_PROMPT", message: "Görsel açıklaması boş olamaz.")
        }

        guard let url = URL(string: "https://api.cloudflare.com/client/v4/accounts/\(trimmedAccount)/ai/run/\(model)") else {
            throw NEOError(code: "BAD_URL", message: "Geçersiz Cloudflare adresi (ACCOUNT_ID'yi kontrol edin).")
        }

        var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalAndRemoteCacheData, timeoutInterval: timeout)
        request.httpMethod = "POST"
        request.setValue("Bearer \(trimmedToken)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONEncoder().encode(RequestBody(prompt: trimmedPrompt, steps: steps))

        let data: Data
        let response: URLResponse
        do {
            (data, response) = try await URLSession.shared.data(for: request)
        } catch let urlError as URLError where urlError.code == .timedOut {
            throw NEOError(code: "TIMEOUT", message: "Cloudflare isteği zaman aşımına uğradı (\(Int(timeout)) saniye içinde cevap gelmedi). Bağlantınızı kontrol edip tekrar deneyin.")
        } catch {
            throw NEOError(code: "NETWORK", message: "İnternet bağlantısı kurulamadı: \(error.localizedDescription)")
        }

        guard let http = response as? HTTPURLResponse else {
            throw NEOError(code: "NETWORK", message: "İnternet bağlantısı kurulamadı.")
        }

        let contentType = (http.value(forHTTPHeaderField: "Content-Type") ?? "").lowercased()
        let decoded = try? JSONDecoder().decode(CFResponse.self, from: data)
        let serverDetail = decoded?.errors?.compactMap { err -> String? in
            guard let msg = err.message else { return nil }
            return err.code != nil ? "[\(err.code!)] \(msg)" : msg
        }.joined(separator: "; ") ?? ""

        if !(200...299).contains(http.statusCode) {
            switch http.statusCode {
            case 401, 403:
                throw NEOError(code: "AUTH", message: "Cloudflare API token geçersiz veya yetkisiz (\(http.statusCode)). CLOUDFLARE_API_TOKEN'ı kontrol edin — token'ın \"Workers AI\" için yazma (Edit) izni olmalı." + (serverDetail.isEmpty ? "" : " (\(serverDetail))"))
            case 404:
                throw NEOError(code: "NOT_FOUND", message: "Hesap veya model bulunamadı (404). CLOUDFLARE_ACCOUNT_ID'yi ve model adını (\"\(model)\") kontrol edin." + (serverDetail.isEmpty ? "" : " (\(serverDetail))"))
            case 429:
                throw NEOError(
                    code: "RATE_LIMIT",
                    message: "İstek limiti aşıldı (429). Biraz bekleyip tekrar deneyin." + (serverDetail.isEmpty ? "" : " (\(serverDetail))"),
                    retryAfterSeconds: http.value(forHTTPHeaderField: "Retry-After").flatMap { Int($0) }
                )
            case 400:
                throw NEOError(code: "BAD_REQUEST", message: "İstek reddedildi (400)." + (serverDetail.isEmpty ? " API anahtarı veya istek biçimi hatalı olabilir." : " \(serverDetail)"))
            case 500...599:
                throw NEOError(code: "SERVER", message: "Cloudflare tarafında geçici bir sorun oluştu (\(http.statusCode))." + (serverDetail.isEmpty ? "" : " (\(serverDetail))"))
            default:
                throw NEOError(code: "HTTP_\(http.statusCode)", message: "Beklenmeyen sunucu cevabı: \(http.statusCode)" + (serverDetail.isEmpty ? "" : " — \(serverDetail)"))
            }
        }

        // Cloudflare bazı görsel modellerinde ham görsel baytlarını doğrudan
        // (JSON'suz) döndürür; bazılarında ise JSON içinde base64 olarak
        // sarmalar. İkisini de destekliyoruz:

        // 1) Content-Type açıkça bir görsel türü ise: gövde zaten ham görseldir.
        if contentType.hasPrefix("image/") {
            guard !data.isEmpty else {
                throw NEOError(code: "EMPTY", message: "Sunucu boş bir görsel döndürdü.")
            }
            return GeneratedImage(data: data, mimeType: contentType)
        }

        // 2) JSON gövdesi: {"result":{"image":"<base64>"}, "success": true, ...}
        if let base64 = decoded?.result?.image,
           let imgData = Data(base64Encoded: base64, options: .ignoreUnknownCharacters) {
            return GeneratedImage(data: imgData, mimeType: "image/jpeg")
        }

        // 3) success:false ile 200 dönmüş olabilir (Cloudflare bazı durumlarda
        // bunu yapar) — errors dizisini kullanıcıya göster.
        if decoded?.success == false {
            throw NEOError(code: "PROVIDER_ERROR", message: "Cloudflare görsel oluşturamadı." + (serverDetail.isEmpty ? "" : " \(serverDetail)"))
        }

        // 4) Hiçbiri uymuyorsa: teşhis için ham cevabın bir kısmını göster.
        let rawPreview = String(data: data.prefix(300), encoding: .utf8) ?? "(çözümlenemeyen ikili veri, \(data.count) bayt)"
        throw NEOError(code: "PARSE", message: "Cloudflare'den beklenen görsel verisi alınamadı. Sunucu cevabı: \(rawPreview)")
    }
}
