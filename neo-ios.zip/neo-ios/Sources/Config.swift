import Foundation

// ════════════════════════════════════════════════════════════════
// config.swift
// NEO — merkezi yapılandırma. (Orijinal config.js karşılığı)
// ════════════════════════════════════════════════════════════════

enum Config {
    /// Tek değişiklik noktası: Gemini modelini güncellemek için bu satırı değiştirin.
    static let geminiModel = "gemini-3.5-flash"
    static let geminiApiBase = "https://generativelanguage.googleapis.com/v1beta/models"
    // 30sn eskiden normal sohbet cevapları için bile yetersiz kalıp zaman
    // aşımına yol açabiliyordu (özellikle Gemini 3.x'in varsayılan "derin
    // düşünme" davranışıyla birleşince — bkz. GeminiService.thinkingConfig).
    // thinkingLevel: "low" ile bu artık büyük ölçüde azaldı, ama yine de
    // biraz daha geniş bir pay bırakıyoruz.
    static let geminiTimeoutSeconds: TimeInterval = 45
    static let geminiVisionTimeoutSeconds: TimeInterval = 90

    /// Görsel oluşturma: Cloudflare Workers AI, varsayılan model
    /// flux-1-schnell'dir (hızlı ama prompt'a bağlılığı zayıf). Daha iyi
    /// prompt takibi için Ayarlar'dan başka bir Cloudflare görsel modeline
    /// geçilebilir (ör. @cf/stabilityai/stable-diffusion-xl-base-1.0).
    static let cloudflareImageModel = "@cf/black-forest-labs/flux-1-schnell"
}

/// UserDefaults anahtarları (orijinaldeki STORAGE_KEYS / localStorage karşılığı).
/// NOT: Orijinal web sürümünde olduğu gibi API anahtarı burada da
/// şifrelenmeden saklanır — bu, orijinal uygulamanın kendi güvenlik uyarısıyla
/// birlikte kabul ettiği bir tasarım kararıdır (bkz. Ayarlar ekranındaki uyarı).
enum StorageKeys {
    static let apiKey = "neo_gemini_api_key"
    static let model = "neo_gemini_model"
    static let hfToken = "neo_hf_token"
    static let hfImageModel = "neo_hf_image_model"
    static let cloudflareAccountID = "neo_cf_account_id"
    static let cloudflareApiToken = "neo_cf_api_token"
    static let temperature = "neo_temperature"
    static let voiceIdentifier = "neo_voice_identifier"
    static let rate = "neo_voice_rate"
    static let pitch = "neo_voice_pitch"
    static let autoSpeak = "neo_auto_speak"
    static let humanize = "neo_voice_humanize"
    static let animations = "neo_animations_enabled"
    static let hudIntensity = "neo_hud_intensity"
    static let theme = "neo_theme"
    static let defaultCity = "neo_default_city"
    static let events = "neo_calendar_events"
    static let voiceGender = "neo_voice_gender"
    static let voiceGenderStrict = "neo_voice_gender_strict"
    static let memory = "neo_memory_v1"
    static let notes = "neo_notes_v1"
    static let userProfile = "neo_user_profile_v1"
    static let tuyaAccessId = "neo_tuya_access_id"
    static let tuyaAccessSecret = "neo_tuya_access_secret"
    static let tuyaUid = "neo_tuya_uid"
    static let tuyaDataCenter = "neo_tuya_data_center"
}

enum HudIntensity: String, CaseIterable, Codable {
    case low, normal, high
    var label: String {
        switch self {
        case .low: return "Düşük"
        case .normal: return "Normal"
        case .high: return "Yüksek"
        }
    }
    var multiplier: Double {
        switch self {
        case .low: return 0.5
        case .normal: return 1.0
        case .high: return 1.6
        }
    }
}

enum NeoTheme: String, CaseIterable, Codable {
    case neoDark = "neo-dark"
    case neoCrimson = "neo-crimson"
    var label: String {
        switch self {
        case .neoDark: return "NEO Koyu (varsayılan)"
        case .neoCrimson: return "NEO Kızıl"
        }
    }
}

enum VoiceGenderPref: String, CaseIterable, Codable {
    case auto, female, male
    var label: String {
        switch self {
        case .auto: return "Fark etmez / Otomatik"
        case .female: return "Kadın"
        case .male: return "Erkek"
        }
    }
}

/// Tuya Cloud (IoT Core) OpenAPI veri merkezi — hesabınızı Tuya IoT
/// Platformu'nda hangi bölgede oluşturduysanız onu seçmeniz gerekir
/// (Cloud > Proje Detayları sayfasında "Data Center" olarak yazar).
enum TuyaDataCenter: String, CaseIterable, Codable {
    case europe = "eu"
    case us = "us"
    case china = "cn"
    case india = "in"

    var baseURL: String {
        switch self {
        case .europe: return "https://openapi.tuyaeu.com"
        case .us: return "https://openapi.tuyaus.com"
        case .china: return "https://openapi.tuyacn.com"
        case .india: return "https://openapi.tuyain.com"
        }
    }
    var label: String {
        switch self {
        case .europe: return "Avrupa (EU)"
        case .us: return "ABD (US)"
        case .china: return "Çin (CN)"
        case .india: return "Hindistan (IN)"
        }
    }
}

enum Defaults {
    static let temperature = 0.8
    static let rate: Float = 1.0
    static let pitch: Float = 1.0
    static let userProfile = UserProfile()
    static let autoSpeak = true
    static let humanize = true
    static let animations = true
    static let hudIntensity = HudIntensity.normal
    static let theme = NeoTheme.neoDark
    static let defaultCity = ""
    static let voiceGender = VoiceGenderPref.auto
    static let voiceGenderStrict = false
    static let tuyaDataCenter = TuyaDataCenter.europe
}

enum Limits {
    static let maxMessageLength = 4000
    /// Bu sayıdan fazla mesaj birikince en eski yarısı özetlenir.
    static let maxHistoryMessages = 16
    /// Özetlenirken kaç mesajın özetleneceği (en eskiden itibaren).
    static let compressBatchSize = 8
}

/// Her Gemini isteğinde systemInstruction olarak gönderilir.
/// {{MEMORY}} yer tutucusu çalışma anında kayıtlı hafızayla doldurulur.
enum SystemPrompt {
    static let template = """
    Sen NEO adında, Türkçe konuşan bir kişisel yapay zekâ asistanısın.

    KİŞİLİK:
    - Zeki, sakin, profesyonel ve kendinden eminsin.
    - Analitik ve yardımseversin, ama gereksiz uzun konuşmazsın.
    - Doğal konuşursun; robotik, aşırı resmi cümlelerden kaçınırsın.
    - Gerektiğinde hafif mizah ve ince sarkazm kullanabilirsin, ama asla
      kullanıcıyı küçümsemez, hakaret etmez ve hassas/ciddi konularla
      (sağlık, kayıp, üzüntü, kriz anları) dalga geçmezsin. Ciddi
      durumlarda mizahı tamamen bırakırsın.
    - Ara sıra "Efendim.", "Elbette.", "Anlaşıldı.", "Hemen ilgileniyorum."
      gibi ifadeler kullanabilirsin, ama bunları her cümlede tekrarlamazsın.
    - Bilmediğin veya emin olmadığın bir şeyi asla uydurmazsın; bilmediğini
      açıkça söylersin.

    CEVAP TARZI:
    - Basit sorulara kısa ve net cevap ver.
    - Karmaşık/teknik konularda gerektiğinde "Problem → Analiz → Çözüm"
      formatını kullanabilirsin.
    - Cevapların sesli okunacağı için gereksiz markdown işaretleri,
      yıldız, tire dizisi gibi öğeler kullanma; düz, akıcı Türkçe yaz.

    ÖNEMLİ GERÇEKLİK KURALI:
    - Sen bir iOS uygulaması içinde çalışıyorsun. Genel, canlı bir internet
      taraması yapamazsın; bildirimlere doğrudan erişemezsin. Böyle bir şey
      istendiğinde bunu yapabiliyormuş gibi davranma; yapamadığını açıkça
      belirt ve varsa alternatif öner.
    - Sınırlı biçimde bazı cihaz özelliklerine erişimin VAR: kullanıcı "hava
      durumu" dediğinde konumuna veya belirttiği şehre göre gerçek bir hava
      durumu servisinden veri çekebilirsin; "kamera aç" dediğinde kamerayı
      açıp çektiği görüntüyü senin için analiz edebilirsin; kullanıcının
      takvimine tam okuma/yazma erişimin var — etkinlik ekleyebilir,
      silebilir ve "bugün bir etkinliğim var mı" gibi soruları gerçek takvim
      verisine bakarak cevaplayabilirsin. Kullanıcı Ayarlar bölümünden Tuya
      (akıllı ev) hesabını bağladıysa, "salon lambasını aç" veya "prizi
      kapat" gibi komutlarla bağlı akıllı ev cihazlarını gerçekten açıp
      kapatabilirsin. Bunlar arayüzdeki ilgili düğmeler veya yerel
      komutlarla (senin doğrudan kod çalıştırman değil, uygulamanın kendisi
      tarafından) tetiklenir.
    - ÇOK ÖNEMLİ: Bu eylemler (hava durumu, kamera, takvim, akıllı ev),
      kullanıcının mesajı SANA ulaşmadan ÖNCE, uygulamanın kendi yerel
      komut ayrıştırıcısı tarafından belirli kalıplara (ör. "ışığı kapat",
      "salon lambasını aç") uyup uymadığına bakılarak tetiklenir. Eğer bir
      mesaj sana ulaşıp senin bu şekilde normal bir sohbet cevabı üretmen
      gerekiyorsa, bu KESİNLİKLE o eylemin GERÇEKLEŞMEDİĞİ, yerel
      ayrıştırıcının kullanıcının (muhtemelen soru veya rica biçimindeki)
      ifadesini tanımadığı anlamına gelir. Bu durumda ASLA "açtım",
      "kapattım", "ekledim" gibi bir eylemi fiilen gerçekleştirdiğini
      iddia eden bir cevap VERME — bu doğru olmayan bir onay olur. Bunun
      yerine kullanıcıya isteğini kısa ve doğrudan bir emir cümlesiyle (ör.
      "ışığı kapat", "salon lambasını aç") tekrar söylemesini öner; böylece
      uygulama bunu doğrudan yakalayıp gerçekten çalıştırabilir.
    - Bir uygulamayı (WhatsApp, YouTube, Spotify vb.) doğrudan, kullanıcı
      onayı olmadan açamazsın; sistem güvenlik kısıtlamaları buna izin
      vermez. Böyle bir istek geldiğinde uygulamanın adıyla bir "Aç" düğmesi
      içeren bir pencere göstereceğini belirt ve kullanıcının o düğmeye
      basması gerektiğini söyle.

    HAFIZA:
    Kullanıcı hakkında şu ana kadar kaydedilmiş bilgiler (varsa aşağıda
    listelenmiştir; yoksa henüz bir şey kaydedilmemiştir). Bu bilgileri
    uygun olduğunda doğal şekilde kullan, ama her cevapta zorla tekrar etme:
    {{MEMORY}}

    KULLANICI PROFİLİ (hayat asistanı modu):
    Kullanıcı, Profilim ekranından kendisi hakkında şu bilgileri girdi
    (girmediyse aşağıda belirtilir). Bunları doğal ve dozunda kullan:
    uygun olduğunda ismiyle/takma adıyla hitap edebilir, ilgi alanlarına,
    hedeflerine veya günlük rutinine gerçekten ilgiliyse değinebilirsin —
    ama her cevaba zorla sıkıştırmaya, sürekli tekrar etmeye veya
    kullanıcıyı profildeki bilgilerle sorgulamaya çalışma:
    {{PROFILE}}
    """
}

// ── HAVA DURUMU: WMO hava kodu → Türkçe açıklama / emoji ─────────
enum Weather {
    static let codeToTr: [Int: String] = [
        0: "açık", 1: "çoğunlukla açık", 2: "parçalı bulutlu", 3: "kapalı",
        45: "sisli", 48: "kırağı sisli",
        51: "hafif çisenti", 53: "çisenti", 55: "yoğun çisenti",
        56: "dondurucu çisenti", 57: "yoğun dondurucu çisenti",
        61: "hafif yağmurlu", 63: "yağmurlu", 65: "şiddetli yağmurlu",
        66: "dondurucu hafif yağmur", 67: "dondurucu şiddetli yağmur",
        71: "hafif kar yağışlı", 73: "kar yağışlı", 75: "yoğun kar yağışlı",
        77: "kar taneli", 80: "hafif sağanaklı", 81: "sağanaklı", 82: "şiddetli sağanaklı",
        85: "hafif kar sağanaklı", 86: "yoğun kar sağanaklı",
        95: "gök gürültülü fırtınalı", 96: "dolulu fırtınalı", 99: "şiddetli dolulu fırtınalı",
    ]
    static func desc(_ code: Int) -> String { codeToTr[code] ?? "bilinmeyen hava durumu" }
    static func emoji(_ code: Int) -> String {
        switch code {
        case 0: return "☀️"
        case 1, 2: return "🌤️"
        case 3: return "☁️"
        case 45, 48: return "🌫️"
        case 51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82: return "🌧️"
        case 71, 73, 75, 77, 85, 86: return "❄️"
        case 95, 96, 99: return "⛈️"
        default: return "🌡️"
        }
    }
}

/// Uygulama açma: bilinen uygulama takma adları ve bağlantıları.
/// "scheme" bir özel URL şemasıdır (yalnızca cihazda ilgili uygulama
/// kayıtlıysa işe yarar). "internal" ise NEO'nun kendi içinde
/// karşılayabildiği (kamera, ayarlar gibi) özellikleri işaret eder.
struct AppCatalogEntry {
    let keys: [String]
    let label: String
    var scheme: String? = nil
    var webUrl: String? = nil
    var internalTarget: String? = nil
}

enum AppCatalog {
    static let entries: [AppCatalogEntry] = [
        .init(keys: ["kamera", "camera"], label: "Kamera", internalTarget: "camera"),
        .init(keys: ["ayarlar", "settings"], label: "Ayarlar", internalTarget: "settings"),
        .init(keys: ["profil", "profilim", "profile"], label: "Profilim", internalTarget: "profile"),
        .init(keys: ["paylaşım", "paylasim", "paylaşımı", "qr"], label: "Paylaşım", internalTarget: "share"),
        .init(keys: ["whatsapp"], label: "WhatsApp", scheme: "whatsapp://send", webUrl: "https://web.whatsapp.com"),
        .init(keys: ["instagram"], label: "Instagram", scheme: "instagram://app", webUrl: "https://instagram.com"),
        .init(keys: ["youtube"], label: "YouTube", scheme: "youtube://", webUrl: "https://youtube.com"),
        .init(keys: ["spotify"], label: "Spotify", scheme: "spotify://", webUrl: "https://open.spotify.com"),
        .init(keys: ["gmail", "e-posta", "e posta", "eposta", "mail"], label: "Gmail", scheme: "googlegmail://", webUrl: "https://mail.google.com"),
        .init(keys: ["takvim", "calendar"], label: "Takvim", internalTarget: "calendar"),
        .init(keys: ["harita", "haritalar", "maps", "google maps", "google haritalar"], label: "Haritalar", scheme: "maps://", webUrl: "https://maps.google.com"),
        .init(keys: ["twitter", "x"], label: "X (Twitter)", scheme: "twitter://", webUrl: "https://x.com"),
        .init(keys: ["facebook"], label: "Facebook", scheme: "fb://", webUrl: "https://facebook.com"),
        .init(keys: ["telegram"], label: "Telegram", scheme: "tg://", webUrl: "https://web.telegram.org"),
        .init(keys: ["netflix"], label: "Netflix", scheme: "nflx://", webUrl: "https://netflix.com"),
        .init(keys: ["hesap makinesi", "hesapmakinesi", "calculator"], label: "Hesap Makinesi", scheme: "calculator://", webUrl: "https://www.google.com/search?q=hesap+makinesi"),
        .init(keys: ["play store", "playstore", "google play"], label: "Play Store", scheme: "market://", webUrl: "https://play.google.com"),
        .init(keys: ["app store", "appstore"], label: "App Store", scheme: "itms-apps://", webUrl: "https://apps.apple.com"),
        .init(keys: ["galeri", "fotoğraflar", "fotograflar", "photos"], label: "Galeri", scheme: nil, webUrl: "https://photos.google.com"),
    ]

    static func normalizeTr(_ s: String) -> String {
        var out = s.lowercased()
        let map: [(String, String)] = [("ı", "i"), ("İ", "i"), ("ş", "s"), ("ğ", "g"), ("ü", "u"), ("ö", "o"), ("ç", "c"), ("'", ""), ("’", "")]
        for (a, b) in map { out = out.replacingOccurrences(of: a, with: b) }
        return out.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    static func findMatch(_ rawName: String) -> AppCatalogEntry? {
        let n = normalizeTr(rawName)
        guard !n.isEmpty else { return nil }
        for app in entries {
            for key in app.keys {
                let nk = normalizeTr(key)
                if nk == n || n.contains(nk) { return app }
            }
        }
        return nil
    }
}
