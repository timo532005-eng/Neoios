import Foundation

// ════════════════════════════════════════════════════════════════
// persistence.swift — storeGet()/storeSet() (localStorage) karşılığı.
// UserDefaults kullanılır; JSON-kodlanabilir tipler JSON olarak saklanır.
// ════════════════════════════════════════════════════════════════

enum Store {
    static func get<T: Codable>(_ key: String, fallback: T) -> T {
        guard let data = UserDefaults.standard.data(forKey: key) else { return fallback }
        return (try? JSONDecoder().decode(T.self, from: data)) ?? fallback
    }

    static func set<T: Codable>(_ key: String, _ value: T) {
        if let data = try? JSONEncoder().encode(value) {
            UserDefaults.standard.set(data, forKey: key)
        }
    }

    static func getString(_ key: String, fallback: String = "") -> String {
        UserDefaults.standard.string(forKey: key) ?? fallback
    }
    static func setString(_ key: String, _ value: String) {
        UserDefaults.standard.set(value, forKey: key)
    }

    static func getDouble(_ key: String, fallback: Double) -> Double {
        UserDefaults.standard.object(forKey: key) == nil ? fallback : UserDefaults.standard.double(forKey: key)
    }
    static func setDouble(_ key: String, _ value: Double) {
        UserDefaults.standard.set(value, forKey: key)
    }

    static func getBool(_ key: String, fallback: Bool) -> Bool {
        UserDefaults.standard.object(forKey: key) == nil ? fallback : UserDefaults.standard.bool(forKey: key)
    }
    static func setBool(_ key: String, _ value: Bool) {
        UserDefaults.standard.set(value, forKey: key)
    }

    static func remove(_ key: String) {
        UserDefaults.standard.removeObject(forKey: key)
    }
}
