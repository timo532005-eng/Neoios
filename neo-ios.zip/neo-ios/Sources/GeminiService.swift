import Foundation

// ════════════════════════════════════════════════════════════════
// GeminiService.swift — Gemini REST API entegrasyonu (orijinal app.js
// bölüm 11: GEMINI API ENTEGRASYONU karşılığı) + görsel oluşturma ve
// ses transkripsiyonu için ek uç noktalar.
// ════════════════════════════════════════════════════════════════

// MARK: - İstek/cevap gövdeleri

private struct GeminiPart: Codable {
    var text: String? = nil
    var inlineData: GeminiInlineData? = nil
    enum CodingKeys: String, CodingKey { case text, inlineData }
}
private struct GeminiInlineData: Codable {
    let mimeType: String
    let data: String
}
private struct GeminiContent: Codable {
    let role: String
    let parts: [GeminiPart]
}
/// Gemini 3.x modelleri varsayılan olarak her istekte "derin düşünme"
/// (thinking) yapar — bu, basit bir sohbet cevabı için bile belirgin
/// bir gecikme ekleyip isteğin 30 saniyelik zaman aşımı süresine
/// takılmasına yol açabiliyordu ("API'ı girmeme rağmen zaman problemi
/// oluşuyor" şikayetinin asıl sebebi). thinkingLevel: "low" ile bunu
/// en aza indirip yanıtları belirgin şekilde hızlandırıyoruz — bu
/// uygulamadaki görevlerin (sohbet, hava durumu, çeviri, takvim/komut
/// ayrıştırma) hiçbiri derin akıl yürütme gerektirmiyor zaten.
private struct GeminiThinkingConfig: Codable {
    var thinkingLevel: String = "low"
}
private struct GeminiGenerationConfig: Codable {
    var temperature: Double? = nil
    var responseModalities: [String]? = nil
    var thinkingConfig: GeminiThinkingConfig? = nil
    /// En kötü durumda (model uzayıp gitmeye meyilliyse) yanıt süresini
    /// sınırlamak için bir üst sınır — sohbet/görsel analizi gibi
    /// kullanıcıyı bekleten görevlerde ayarlanır, kısa yapısı gereği
    /// zaten kısa olan çeviri/ayrıştırma gibi yardımcı çağrılarda
    /// dokunulmuyor (nil = Gemini'nin kendi varsayılanı).
    var maxOutputTokens: Int? = nil
}
private struct GeminiSystemInstruction: Codable {
    let parts: [GeminiPart]
}
private struct GeminiRequestBody: Codable {
    let contents: [GeminiContent]
    var systemInstruction: GeminiSystemInstruction? = nil
    let generationConfig: GeminiGenerationConfig
}

private struct GeminiResponse: Codable {
    struct Candidate: Codable {
        struct Content: Codable { let parts: [GeminiPart]? }
        let content: Content?
        let finishReason: String?
    }
    let candidates: [Candidate]?
}

private struct GeminiErrorBody: Codable {
    struct Err: Codable { let message: String? }
    let error: Err?
}

/// generateImage() gibi görsel/metin karışık cevap dönebilen çağrıların
/// ayrıştırılmış sonucu.
struct GeminiPartsResult {
    let text: String
    let imageBase64: String?
    let imageMimeType: String?
}

final class GeminiService {
    /// Yalnızca Gemini 3.x ve üzeri modeller "thinkingLevel" alanını
    /// anlıyor (2.x ve altı farklı, uyumsuz bir "thinkingBudget" alanı
    /// kullanıyor) — bu yüzden kullanıcı Ayarlar'dan eski bir model adı
    /// girmiş olsa bile isteği bozmamak için yalnızca model adı
    /// "gemini-3" veya üzeri bir sürüm belirtiyorsa ekliyoruz.
    /// level: "low" (varsayılan, hız için) / "high" (AI modları >
    /// Derin Düşünme seçildiğinde — daha kapsamlı akıl yürütme için).
    private static func thinkingConfig(for model: String, level: String = "low") -> GeminiThinkingConfig? {
        guard let match = model.range(of: #"gemini-(\d+(?:\.\d+)?)"#, options: .regularExpression) else { return nil }
        let numStr = model[match].replacingOccurrences(of: "gemini-", with: "")
        guard let major = Double(numStr), major >= 3 else { return nil }
        return GeminiThinkingConfig(thinkingLevel: level)
    }

    /// Ham Gemini isteği: config, body kodlar, ağ hatalarını ve HTTP durum
    /// kodlarını orijinaldeki callGeminiRaw() ile birebir aynı mesajlarla eşler.
    /// Metin VE (varsa) görsel parçalarını birlikte döner.
    private static func callRawParts(body: Data, apiKey: String, model: String, timeout: TimeInterval) async throws -> GeminiPartsResult {
        guard var comps = URLComponents(string: "\(Config.geminiApiBase)/\(model):generateContent") else {
            throw NEOError(code: "BAD_URL", message: "Geçersiz model adresi.")
        }
        comps.queryItems = [URLQueryItem(name: "key", value: apiKey)]
        guard let url = comps.url else {
            throw NEOError(code: "BAD_URL", message: "Geçersiz model adresi.")
        }

        var request = URLRequest(url: url, timeoutInterval: timeout)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = body

        // 503 ("model overloaded") Google tarafında çok sık görülen, tamamen
        // GEÇİCİ bir durumdur — Google'ın kendi dokümantasyonu da üstel
        // geri çekilmeli (exponential backoff) otomatik yeniden deneme
        // öneriyor. Eskiden burada tek seferlik yeniden deneme sadece ağ
        // zaman aşımı için vardı, 503/500/502/504 anında kullanıcıya hata
        // olarak gösteriliyordu — şimdi bunlar da en fazla 2 kez, artan
        // bir bekleme ile otomatik olarak yeniden deneniyor.
        let maxAttempts = 3
        var data = Data()
        var http: HTTPURLResponse?
        var lastServerStatus = 0
        retryLoop: for attempt in 1...maxAttempts {
            let isLastAttempt = attempt == maxAttempts
            let oneData: Data
            let oneResponse: URLResponse
            do {
                (oneData, oneResponse) = try await URLSession.shared.data(for: request)
            } catch let urlError as URLError where urlError.code == .timedOut {
                if isLastAttempt {
                    throw NEOError(code: "TIMEOUT", message: "Gemini isteği zaman aşımına uğradı (\(attempt) kez denendi). Bağlantınızı kontrol edip tekrar deneyin.")
                }
                continue retryLoop
            } catch {
                throw NEOError(code: "NETWORK", message: "İnternet bağlantısı kurulamadı. Bağlantınızı kontrol edin.")
            }
            guard let oneHttp = oneResponse as? HTTPURLResponse else {
                throw NEOError(code: "NETWORK", message: "İnternet bağlantısı kurulamadı. Bağlantınızı kontrol edin.")
            }
            if (500...599).contains(oneHttp.statusCode) && !isLastAttempt {
                lastServerStatus = oneHttp.statusCode
                // Üstel geri çekilme: ~0.6sn, sonra ~1.2sn.
                try? await Task.sleep(nanoseconds: UInt64(0.6 * Double(attempt) * 1_000_000_000))
                continue retryLoop
            }
            data = oneData
            http = oneHttp
            break retryLoop
        }
        guard let http else {
            throw NEOError(code: "SERVER", message: "Gemini sunucusunda geçici bir sorun oluştu (\(lastServerStatus)). Birkaç kez denendi, hâlâ başarısız — birazdan tekrar deneyin.")
        }

        if !(200...299).contains(http.statusCode) {
            let detail = (try? JSONDecoder().decode(GeminiErrorBody.self, from: data))?.error?.message ?? ""
            switch http.statusCode {
            case 400:
                throw NEOError(code: "BAD_REQUEST", message: "İstek reddedildi (400). " + (detail.isEmpty ? "API anahtarı veya istek biçimi hatalı olabilir." : detail))
            case 401, 403:
                throw NEOError(code: "AUTH", message: "API anahtarı geçersiz veya yetkisiz (\(http.statusCode)). Ayarlar bölümünden anahtarınızı kontrol edin.")
            case 404:
                throw NEOError(code: "NOT_FOUND", message: "Model bulunamadı (404). Model adını kontrol edin: \"\(model)\"")
            case 429:
                let retryAfter = (http.value(forHTTPHeaderField: "Retry-After")).flatMap { Int($0) }
                let waitNote = retryAfter.map { " Sunucu \($0) saniye sonra tekrar denemenizi öneriyor." } ?? ""
                throw NEOError(
                    code: "RATE_LIMIT",
                    message: "İstek limiti aşıldı (429). Bu, Google'ın Gemini API kotanıza takıldığınız anlamına gelir — özellikle görsel üretim modelleri ücretsiz katmanda çok düşük dakikalık/günlük limitlere sahiptir.\(waitNote) Biraz bekleyip tekrar deneyin; sorun sürerse Google AI Studio hesabınızdaki kullanım/kota sayfasından planınızı kontrol edin." + (detail.isEmpty ? "" : " (\(detail))"),
                    retryAfterSeconds: retryAfter
                )
            case 503:
                throw NEOError(code: "OVERLOADED", message: "Gemini modeli şu anda aşırı yüklenmiş (503) — bu Google tarafında geçici bir durum, NEO'nun bir hatası değil. 3 kez otomatik denendi, hepsi başarısız oldu. Birazdan tekrar deneyin; sık oluyorsa Ayarlar > AI bölümünden daha az talep gören bir modele (ör. gemini-3.1-flash-lite) geçmeyi deneyebilirsiniz.")
            case 500...599:
                throw NEOError(code: "SERVER", message: "Gemini sunucusunda geçici bir sorun oluştu (\(http.statusCode)). 3 kez otomatik denendi, hepsi başarısız oldu.")
            default:
                throw NEOError(code: "HTTP_\(http.statusCode)", message: "Beklenmeyen sunucu cevabı: \(http.statusCode)" + (detail.isEmpty ? "" : " — \(detail)"))
            }
        }

        guard let parsed = try? JSONDecoder().decode(GeminiResponse.self, from: data) else {
            throw NEOError(code: "PARSE", message: "Sunucudan gelen cevap çözümlenemedi.")
        }
        let candidate = parsed.candidates?.first
        let parts = candidate?.content?.parts ?? []
        let text = parts.compactMap { $0.text }.joined().trimmingCharacters(in: .whitespacesAndNewlines)
        let imagePart = parts.first { $0.inlineData != nil }

        if text.isEmpty && imagePart == nil {
            if candidate?.finishReason == "SAFETY" || candidate?.finishReason == "PROHIBITED_CONTENT" {
                throw NEOError(code: "SAFETY", message: "Bu isteğe güvenlik filtreleri nedeniyle cevap üretilemedi.")
            }
            throw NEOError(code: "EMPTY", message: "Beklenmeyen API cevabı: içerik boş döndü.")
        }
        return GeminiPartsResult(text: text, imageBase64: imagePart?.inlineData?.data, imageMimeType: imagePart?.inlineData?.mimeType)
    }

    /// Yalnızca metin dönen çağrılar için ince sarmalayıcı (mevcut kullanım
    /// noktalarıyla geriye dönük uyumluluk için korunmuştur).
    static func callRaw(body: Data, apiKey: String, model: String, timeout: TimeInterval) async throws -> String {
        let result = try await callRawParts(body: body, apiKey: apiKey, model: model, timeout: timeout)
        guard !result.text.isEmpty else {
            throw NEOError(code: "EMPTY", message: "Beklenmeyen API cevabı: metin içeriği boş döndü.")
        }
        return result.text
    }

    static func callText(userText: String, history: [HistoryTurn], historySummary: String, systemPrompt: String, apiKey: String, model: String, temperature: Double, thinkingLevel: String = "low") async throws -> String {
        if apiKey.isEmpty {
            throw NEOError(code: "NO_KEY", message: "Gemini API anahtarı girilmemiş. Ayarlar > AI bölümünden bir anahtar ekleyin.")
        }
        var contents: [GeminiContent] = []
        if !historySummary.isEmpty {
            contents.append(GeminiContent(role: "user", parts: [GeminiPart(text: "[Önceki konuşmanın özeti: \(historySummary)]")]))
            contents.append(GeminiContent(role: "model", parts: [GeminiPart(text: "Anlaşıldı, bağlamı dikkate alıyorum.")]))
        }
        for turn in history {
            contents.append(GeminiContent(role: turn.role, parts: [GeminiPart(text: turn.text)]))
        }
        contents.append(GeminiContent(role: "user", parts: [GeminiPart(text: userText)]))

        let body = GeminiRequestBody(
            contents: contents,
            systemInstruction: GeminiSystemInstruction(parts: [GeminiPart(text: systemPrompt)]),
            generationConfig: GeminiGenerationConfig(temperature: temperature, thinkingConfig: thinkingConfig(for: model, level: thinkingLevel), maxOutputTokens: 2048)
        )
        let data = try JSONEncoder().encode(body)
        return try await callRaw(body: data, apiKey: apiKey, model: model, timeout: Config.geminiTimeoutSeconds)
    }

    static func callVision(base64Data: String, promptText: String, mimeType: String, systemPrompt: String, apiKey: String, model: String, temperature: Double) async throws -> String {
        if apiKey.isEmpty {
            throw NEOError(code: "NO_KEY", message: "Gemini API anahtarı girilmemiş. Ayarlar > AI bölümünden bir anahtar ekleyin.")
        }
        let content = GeminiContent(role: "user", parts: [
            GeminiPart(text: promptText),
            GeminiPart(inlineData: GeminiInlineData(mimeType: mimeType, data: base64Data)),
        ])
        let body = GeminiRequestBody(
            contents: [content],
            systemInstruction: GeminiSystemInstruction(parts: [GeminiPart(text: systemPrompt)]),
            generationConfig: GeminiGenerationConfig(temperature: temperature, thinkingConfig: thinkingConfig(for: model), maxOutputTokens: 2048)
        )
        let data = try JSONEncoder().encode(body)
        let timeout = mimeType.hasPrefix("video/") ? Config.geminiVisionTimeoutSeconds : Config.geminiTimeoutSeconds
        return try await callRaw(body: data, apiKey: apiKey, model: model, timeout: timeout)
    }

    // MARK: - Görsel oluşturma (yeni)

    struct GeneratedImage {
        let data: Data
        let mimeType: String
    }

    /// Metinden görsel üretir (Gemini'nin görsel-üretim destekli modeli,
    /// ör. "gemini-2.5-flash-image"). API, generationConfig.responseModalities
    /// alanına ["IMAGE","TEXT"] gönderildiğinde cevap içinde base64 inlineData
    /// olarak bir görsel parçası döner.
    static func generateImage(prompt: String, apiKey: String, model: String) async throws -> GeneratedImage {
        if apiKey.isEmpty {
            throw NEOError(code: "NO_KEY", message: "Gemini API anahtarı girilmemiş. Ayarlar > AI bölümünden bir anahtar ekleyin.")
        }
        guard !prompt.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw NEOError(code: "EMPTY_PROMPT", message: "Görsel açıklaması boş olamaz.")
        }
        let body = GeminiRequestBody(
            contents: [GeminiContent(role: "user", parts: [GeminiPart(text: prompt)])],
            generationConfig: GeminiGenerationConfig(temperature: 1.0, responseModalities: ["IMAGE", "TEXT"], thinkingConfig: thinkingConfig(for: model))
        )
        let data = try JSONEncoder().encode(body)
        let result = try await callRawParts(body: data, apiKey: apiKey, model: model, timeout: Config.geminiVisionTimeoutSeconds)
        guard let b64 = result.imageBase64, let imgData = Data(base64Encoded: b64) else {
            if !result.text.isEmpty {
                throw NEOError(code: "NO_IMAGE", message: "Model bir görsel üretmek yerine şunu yazdı: \(result.text)")
            }
            throw NEOError(code: "NO_IMAGE", message: "Model bir görsel üretemedi. Farklı bir açıklama ile tekrar deneyin.")
        }
        return GeneratedImage(data: imgData, mimeType: result.imageMimeType ?? "image/png")
    }

    // MARK: - Ses kaydından metne çevirme (yeni)

    /// Bir ses dosyasını (base64) Gemini'ye göndererek olduğu gibi yazıya
    /// döker. NEO'nun kişilik/system promptu KASITLI OLARAK kullanılmaz;
    /// amaç sohbet cevabı değil, birebir transkripsiyon almaktır.
    static func transcribeAudio(base64Data: String, mimeType: String, apiKey: String, model: String) async throws -> String {
        if apiKey.isEmpty {
            throw NEOError(code: "NO_KEY", message: "Gemini API anahtarı girilmemiş. Ayarlar > AI bölümünden bir anahtar ekleyin.")
        }
        let prompt = "Bu ses kaydını, duyduğun dilde, eksiksiz ve olduğu gibi yazıya dök. Noktalama işaretlerini uygun şekilde ekle. YALNIZCA transkript metnini yaz; başlık, açıklama, özet veya başka hiçbir ek yorum ekleme."
        let content = GeminiContent(role: "user", parts: [
            GeminiPart(text: prompt),
            GeminiPart(inlineData: GeminiInlineData(mimeType: mimeType, data: base64Data)),
        ])
        let body = GeminiRequestBody(
            contents: [content],
            generationConfig: GeminiGenerationConfig(temperature: 0.1, thinkingConfig: thinkingConfig(for: model))
        )
        let data = try JSONEncoder().encode(body)
        return try await callRaw(body: data, apiKey: apiKey, model: model, timeout: Config.geminiVisionTimeoutSeconds)
    }

    /// Görsel üretim modelleri (Cloudflare'deki flux/SDXL vb.) neredeyse
    /// tamamen İngilizce metinle eğitildi; Türkçe bir prompt gönderildiğinde
    /// modelin metni anlayamayıp tamamen alakasız bir görsel üretmesi çok
    /// olasıdır. Bu yüzden görsel oluşturmadan önce prompt'u kısa, canlı bir
    /// İngilizce görsel açıklamasına çeviriyoruz.
    static func translateForImageGen(text: String, apiKey: String, model: String) async throws -> String {
        if apiKey.isEmpty {
            // API anahtarı yoksa çeviremeyiz; orijinal metni olduğu gibi
            // göndermek zorunda kalırız (çağıran taraf bunu bilip
            // kullanıcıyı bilgilendirmelidir).
            return text
        }
        let prompt = """
        Translate/rewrite the following into a short, vivid, purely visual
        English image-generation prompt (max ~30 words). Output ONLY the
        English prompt text itself — no quotes, no explanation, no labels.

        Input: "\(text)"
        """
        let body = GeminiRequestBody(
            contents: [GeminiContent(role: "user", parts: [GeminiPart(text: prompt)])],
            generationConfig: GeminiGenerationConfig(temperature: 0.3, thinkingConfig: thinkingConfig(for: model))
        )
        let data = try JSONEncoder().encode(body)
        let translated = try await callRaw(body: data, apiKey: apiKey, model: model, timeout: Config.geminiTimeoutSeconds)
        let cleaned = translated.trimmingCharacters(in: .whitespacesAndNewlines)
            .trimmingCharacters(in: CharacterSet(charactersIn: "\""))
        return cleaned.isEmpty ? text : cleaned
    }

    /// Kullanıcının serbest metnini kesin bir JSON şemasına ayrıştırır
    /// (orijinal parseCalendarIntent()). Gerçek veri değişikliği HER ZAMAN
    /// yerel/deterministik yapılır — Gemini yalnızca niyeti ayrıştırır.
    struct CalendarIntent: Codable {
        let intent: String // add | remove | query | unclear
        let title: String?
        let date: String?
        let time: String?
        let query_scope: String?
        let target_hint: String?
    }

    static func parseCalendarIntent(text: String, apiKey: String, model: String) async throws -> CalendarIntent {
        if apiKey.isEmpty {
            throw NEOError(code: "NO_KEY", message: "Takvim komutlarınızı anlayabilmem için Ayarlar > AI bölümünden bir Gemini API anahtarı girmeniz gerekiyor. Bu arada Takvim panelinden etkinlikleri elle ekleyip görüntüleyebilirsiniz.")
        }
        let now = Date()
        let df = DateFormatter()
        df.locale = Locale(identifier: "tr_TR")
        df.dateFormat = "yyyy-MM-dd"
        let todayStr = df.string(from: now)
        let wf = DateFormatter()
        wf.locale = Locale(identifier: "tr_TR")
        wf.dateFormat = "EEEE"
        let weekday = wf.string(from: now)

        let prompt = """
        Sen bir takvim komutu ayrıştırıcısısın. Bugünün tarihi: \(todayStr) (\(weekday)).
        Kullanıcının aşağıdaki cümlesini bir takvim işlemine dönüştür ve YALNIZCA şu JSON şemasında, başka hiçbir metin/açıklama/markdown olmadan cevap ver:
        {"intent":"add|remove|query|unclear","title":string|null,"date":"YYYY-MM-DD"|null,"time":"HH:MM"|null,"query_scope":"today|tomorrow|date|week|all"|null,"target_hint":string|null}

        Kurallar:
        - "add": yeni bir etkinlik/randevu/toplantı ekleme isteği. title kısa ve anlamlı olsun. Tarih belirtilmemişse bugünün tarihini (\(todayStr)) kullan. Saat belirtilmemişse time'ı null bırak (tüm gün etkinliği).
        - "remove": bir etkinliği silme/iptal etme isteği. target_hint alanına, silinecek etkinliğin başlığına dair kısa bir ipucu yaz.
        - "query": kullanıcı takvimindeki etkinlikleri soruyor (ör. "bugün bir etkinliğim var mı", "yarın ne var"). query_scope'u doldur; belirli bir tarih soruluyorsa date alanını doldurup query_scope'u "date" yap.
        - Hiçbiri net değilse "unclear" döndür.

        Kullanıcı cümlesi: "\(text)"
        """

        let body = GeminiRequestBody(
            contents: [GeminiContent(role: "user", parts: [GeminiPart(text: prompt)])],
            generationConfig: GeminiGenerationConfig(temperature: 0.1, thinkingConfig: thinkingConfig(for: model))
        )
        let data = try JSONEncoder().encode(body)
        let raw = try await callRaw(body: data, apiKey: apiKey, model: model, timeout: Config.geminiTimeoutSeconds)
        let cleaned = raw.replacingOccurrences(of: "```json", with: "", options: .caseInsensitive)
            .replacingOccurrences(of: "```", with: "")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        guard let jsonData = cleaned.data(using: .utf8),
              let parsed = try? JSONDecoder().decode(CalendarIntent.self, from: jsonData) else {
            throw NEOError(code: "PARSE", message: "Takvim isteğinizi anlayamadım. Lütfen daha net bir şekilde tekrar deneyin (örn. \"yarın saat 15:00'te toplantı ekle\").")
        }
        return parsed
    }
}
