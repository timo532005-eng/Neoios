import Foundation
import AVFoundation
import UIKit
import SwiftUI

// ════════════════════════════════════════════════════════════════
// CameraManager.swift — orijinal bölüm 10.3 (KAMERA) karşılığı.
// getUserMedia yerine AVCaptureSession; canvas.toDataURL yerine
// AVCapturePhotoOutput ile tek kare yakalama kullanılır.
// ════════════════════════════════════════════════════════════════

@MainActor
final class CameraManager: NSObject, ObservableObject, AVCapturePhotoCaptureDelegate {
    @Published var statusHint = "Kamerayı kullanmak için izin vermeniz gerekir. Görüntü yalnızca \"Çek ve Analiz Et\" düğmesine bastığınızda tek bir kare olarak gönderilir; sürekli izlenmez veya kaydedilmez."
    @Published var isRunning = false
    @Published var facingMode: AVCaptureDevice.Position = .back

    // AVCaptureSession / AVCapturePhotoOutput Apple tarafından çoklu iş
    // parçacığından erişime karşı güvenli kabul edilir (yapılandırma
    // değişiklikleri yine de tek bir seri kuyruk — sessionQueue — üzerinden
    // yapılır). `nonisolated(unsafe)`, bu referanslara sessionQueue'nun arka
    // plan kapanışlarından MainActor izolasyon hatası almadan erişebilmek içindir.
    nonisolated(unsafe) let session = AVCaptureSession()
    nonisolated(unsafe) private let photoOutput = AVCapturePhotoOutput()
    nonisolated(unsafe) private var photoCompletion: ((Data?) -> Void)?
    private let sessionQueue = DispatchQueue(label: "neo.camera.session")

    func start() {
        AVCaptureDevice.requestAccess(for: .video) { [weak self] granted in
            Task { @MainActor in
                guard let self else { return }
                if !granted {
                    self.statusHint = "Kameraya erişilemedi: kamera izni reddedildi. Ayarlar > Gizlilik bölümünden NEO için kamera iznini açıp tekrar deneyin."
                    return
                }
                self.configureAndStart()
            }
        }
    }

    private func configureAndStart() {
        statusHint = "Kamera başlatılıyor…"
        let desiredPosition = facingMode
        sessionQueue.async { [weak self] in
            guard let self else { return }
            self.session.beginConfiguration()
            self.session.inputs.forEach { self.session.removeInput($0) }
            self.session.outputs.forEach { self.session.removeOutput($0) }

            guard let device = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: desiredPosition)
                ?? AVCaptureDevice.default(for: .video),
                  let input = try? AVCaptureDeviceInput(device: device) else {
                self.session.commitConfiguration()
                Task { @MainActor in self.statusHint = "Kameraya erişilemedi: cihazda kullanılabilir bir kamera bulunamadı." }
                return
            }
            if self.session.canAddInput(input) { self.session.addInput(input) }
            if self.session.canAddOutput(self.photoOutput) { self.session.addOutput(self.photoOutput) }
            self.session.commitConfiguration()
            self.session.startRunning()
            Task { @MainActor in
                self.isRunning = true
                self.statusHint = "Görüntü yalnızca \"Çek ve Analiz Et\" düğmesine bastığınızda tek bir kare olarak gönderilir; sürekli izlenmez veya kaydedilmez."
            }
        }
    }

    func stop() {
        sessionQueue.async { [weak self] in
            self?.session.stopRunning()
        }
        isRunning = false
    }

    func switchCamera() {
        facingMode = facingMode == .back ? .front : .back
        start()
    }

    /// Tek kare yakalar ve JPEG verisini döner (orijinal captureCameraFrame()).
    func captureFrame() async -> Data? {
        await withCheckedContinuation { cont in
            self.photoCompletion = { data in cont.resume(returning: data) }
            let settings = AVCapturePhotoSettings()
            // ÖNEMLİ: Bu satır olmadan AVFoundation, fotoğrafı sensörün
            // kendi (donanıma özel) referans yönüne göre kaydediyordu —
            // bu da cihazı normal (dik) tuttuğunuzda fotoğrafın yan/ters
            // çıkmasına, düz çıkması için cihazı ters tutmanız gerekmesine
            // yol açıyordu. Çekim anındaki arayüz yönünü bağlantıya
            // açıkça bildirerek düzeltiyoruz.
            if let connection = self.photoOutput.connection(with: .video), connection.isVideoOrientationSupported {
                connection.videoOrientation = Self.currentVideoOrientation()
            }
            self.photoOutput.capturePhoto(with: settings, delegate: self)
        }
    }

    /// Mevcut arayüz yönünü (UIWindowScene üzerinden) AVFoundation'ın
    /// beklediği video yönüne çevirir. DİKKAT: UIKit ve AVFoundation'ın
    /// yatay (landscape) adlandırması birbirine TERSTİR — arayüz
    /// landscapeLeft iken video bağlantısının landscapeRight olması
    /// gerekir (ve tam tersi); bu, iyi bilinen ama kolayca atlanan bir
    /// AVFoundation tuzağıdır ve atlanırsa tam da "ters tutunca düzeliyor"
    /// belirtisine yol açar.
    private static func currentVideoOrientation() -> AVCaptureVideoOrientation {
        let interfaceOrientation = UIApplication.shared.connectedScenes
            .compactMap { ($0 as? UIWindowScene)?.interfaceOrientation }
            .first ?? .portrait
        switch interfaceOrientation {
        case .portrait: return .portrait
        case .portraitUpsideDown: return .portraitUpsideDown
        case .landscapeLeft: return .landscapeRight
        case .landscapeRight: return .landscapeLeft
        default: return .portrait
        }
    }

    nonisolated func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
        let data = photo.fileDataRepresentation()
        Task { @MainActor in
            self.photoCompletion?(data)
            self.photoCompletion = nil
        }
    }
}

/// AVCaptureSession önizlemesini SwiftUI'a bağlayan UIViewRepresentable.
struct CameraPreviewView: UIViewRepresentable {
    let session: AVCaptureSession

    func makeUIView(context: Context) -> PreviewUIView {
        let view = PreviewUIView()
        view.videoPreviewLayer.session = session
        view.videoPreviewLayer.videoGravity = .resizeAspectFill
        Self.applyCurrentOrientation(to: view.videoPreviewLayer)
        return view
    }
    func updateUIView(_ uiView: PreviewUIView, context: Context) {
        // Çekilen fotoğrafla aynı mantık: önizlemenin de ekrandaki yönle
        // eşleşmesi için bağlantının yönünü güncel arayüz yönüne göre ayarla.
        Self.applyCurrentOrientation(to: uiView.videoPreviewLayer)
    }

    private static func applyCurrentOrientation(to layer: AVCaptureVideoPreviewLayer) {
        guard let connection = layer.connection, connection.isVideoOrientationSupported else { return }
        let interfaceOrientation = UIApplication.shared.connectedScenes
            .compactMap { ($0 as? UIWindowScene)?.interfaceOrientation }
            .first ?? .portrait
        switch interfaceOrientation {
        case .portrait: connection.videoOrientation = .portrait
        case .portraitUpsideDown: connection.videoOrientation = .portraitUpsideDown
        case .landscapeLeft: connection.videoOrientation = .landscapeRight
        case .landscapeRight: connection.videoOrientation = .landscapeLeft
        default: connection.videoOrientation = .portrait
        }
    }

    final class PreviewUIView: UIView {
        override static var layerClass: AnyClass { AVCaptureVideoPreviewLayer.self }
        var videoPreviewLayer: AVCaptureVideoPreviewLayer { layer as! AVCaptureVideoPreviewLayer }
    }
}
