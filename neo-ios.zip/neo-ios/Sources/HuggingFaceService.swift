import Foundation

// ════════════════════════════════════════════════════════════════
// HuggingFaceService.swift — Hugging Face "Inference Providers" router
// üzerinden görsel oluşturma. Kullanıcının verdiği JS örneği
// (@huggingface/inference → InferenceClient.textToImage, provider:
// "fal-ai", model: "black-forest-labs/FLUX.1-dev") aynı işi yapan bir
// InferenceClient SDK'sı Swift'te resmî olarak bulunmadığından, aynı
// isteği Hugging Face'in resmî REST uç noktasına (router.huggingface.co)
// doğrudan HTTP ile gönderiyoruz:
//
//   POST https://router.huggingface.co/{provider}/models/{model}
//   Authorization: Bearer <hf_...>
//   Content-Type: application/json
//   Body: {"inputs": "<prompt>", "parameters": {...}}
//
// Cevap, başarılıysa görselin ham baytlarıdır (Content-Type: image/*).
// ════════════════════════════════════════════════════════════════

enum HuggingFaceService {
    struct GeneratedImage {
        let data: Data
        let mimeType: String
    }

    private struct HFErrorBody: Codable {
        let error: String?
    }

    static func generateImage(
        prompt: String,
        token: String,
        provider: String,
        model: String,
        numInferenceSteps: Int? = nil
    ) async throws -> GeneratedImage {
        let trimmedToken = token.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedToken.isEmpty else {
            throw NEOError(code: "NO_KEY", message: "Hugging Face token'ı girilmemiş. Ayarlar > AI bölümünden bir HF token (hf_... ile başlayan) ekleyin. Token'ınızın \"Inference Providers\" iznine sahip olması gerekir.")
        }
        let trimmedPrompt = prompt.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedPrompt.isEmpty else {
            throw NEOError(code: "EMPTY_PROMPT", message: "Görsel açıklaması boş olamaz.")
        }

        guard let url = URL(string: "https://router.huggingface.co/\(provider)/models/\(model)") else {
            throw NEOError(code: "BAD_URL", message: "Geçersiz model adresi: \(provider)/\(model)")
        }

        struct Params: Codable { var num_inference_steps: Int? }
        struct Body: Codable { let inputs: String; var parameters: Params? }
        let body = Body(inputs: trimmedPrompt, parameters: numInferenceSteps.map { Params(num_inference_steps: $0) })

        var request = URLRequest(url: url, timeoutInterval: 90)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Bearer \(trimmedToken)", forHTTPHeaderField: "Authorization")
        request.httpBody = try JSONEncoder().encode(body)

        let data: Data
        let response: URLResponse
        do {
            (data, response) = try await URLSession.shared.data(for: request)
        } catch let urlError as URLError where urlError.code == .timedOut {
            throw NEOError(code: "TIMEOUT", message: "Hugging Face isteği zaman aşımına uğradı (görsel modelleri bazen 30-60 saniye sürebilir). Tekrar deneyin.")
        } catch {
            throw NEOError(code: "NETWORK", message: "İnternet bağlantısı kurulamadı. Bağlantınızı kontrol edin.")
        }

        guard let http = response as? HTTPURLResponse else {
            throw NEOError(code: "NETWORK", message: "İnternet bağlantısı kurulamadı. Bağlantınızı kontrol edin.")
        }

        let contentType = http.value(forHTTPHeaderField: "Content-Type") ?? ""

        if !(200...299).contains(http.statusCode) {
            let detail = (try? JSONDecoder().decode(HFErrorBody.self, from: data))?.error
                ?? String(data: data, encoding: .utf8)?.trimmingCharacters(in: .whitespacesAndNewlines)
                ?? ""
            switch http.statusCode {
            case 401:
                throw NEOError(code: "AUTH", message: "Hugging Face token'ı geçersiz (401). Ayarlar bölümünden token'ınızı kontrol edin.")
            case 403:
                throw NEOError(code: "AUTH", message: "Bu token'ın \"Inference Providers\" izni yok ya da fal-ai sağlayıcısına erişimi kısıtlı (403). https://huggingface.co/settings/tokens adresinden \"Inference Providers\" izniyle yeni bir token oluşturun.")
            case 404:
                throw NEOError(code: "NOT_FOUND", message: "Model bulunamadı (404): \"\(model)\". Model adının fal-ai sağlayıcısında desteklendiğinden emin olun (ör. \"black-forest-labs/FLUX.1-dev\").")
            case 429:
                throw NEOError(code: "RATE_LIMIT", message: "İstek limiti/kredisi aşıldı (429). Hugging Face hesabınızdaki Inference Providers kredinizi/limitinizi kontrol edin, biraz bekleyip tekrar deneyin.", retryAfterSeconds: http.value(forHTTPHeaderField: "Retry-After").flatMap { Int($0) })
            case 503:
                throw NEOError(code: "LOADING", message: "Model şu anda ısınıyor/yükleniyor olabilir (503). Birkaç saniye sonra tekrar deneyin.")
            case 500...599:
                throw NEOError(code: "SERVER", message: "Hugging Face/sağlayıcı tarafında geçici bir sorun oluştu (\(http.statusCode)).")
            default:
                throw NEOError(code: "HTTP_\(http.statusCode)", message: "Beklenmeyen sunucu cevabı: \(http.statusCode)" + (detail.isEmpty ? "" : " — \(detail)"))
            }
        }

        // Bazı sağlayıcılar hata olsa bile 200 ile birlikte JSON gövdesi
        // dönebilir (ör. {"error": "..."})—bunu görsel sanıp yutmamak için
        // Content-Type'ı kontrol ediyoruz.
        if contentType.contains("application/json") {
            if let errBody = try? JSONDecoder().decode(HFErrorBody.self, from: data), let msg = errBody.error {
                throw NEOError(code: "PROVIDER_ERROR", message: "Görsel oluşturulamadı: \(msg)")
            }
            throw NEOError(code: "UNEXPECTED_JSON", message: "Beklenmedik bir cevap alındı (görsel yerine JSON döndü).")
        }

        guard !data.isEmpty else {
            throw NEOError(code: "EMPTY", message: "Sunucu boş bir cevap döndü.")
        }
        return GeneratedImage(data: data, mimeType: contentType.isEmpty ? "image/png" : contentType)
    }
}
