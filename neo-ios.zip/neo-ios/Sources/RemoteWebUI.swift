import Foundation

// ════════════════════════════════════════════════════════════════
// RemoteWebUI.swift — QR kod okutan cihazın tarayıcısında açılan NEO
// uzaktan kumanda sayfası. Tek dosyalık, bağımsız bir HTML/CSS/JS
// sayfasıdır (harici kaynak yüklemez). Sayfa, adres çubuğundaki "t"
// jetonunu her API isteğine ekler; mesajları ~1,5 sn'de bir sorgular
// (polling) ve yazdıklarınızı /api/send ile NEO'ya iletir.
//
// GÜVENLİK NOTU: Mesaj metinleri DOM'a daima textContent ile eklenir
// (innerHTML KULLANILMAZ) — mesaj içeriği ne olursa olsun betik
// çalıştırılamaz.
// ════════════════════════════════════════════════════════════════

enum RemoteWebUI {
    static let page = #"""
<!doctype html>
<html lang="tr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#05070a">
<title>NEO Uzaktan</title>
<style>
:root{--bg:#05070a;--panel:#0b1118;--border:#17313d;--primary:#2de2ff;--accent:#ffb454;--text:#d8f3ff;--dim:#6f93a3;--danger:#ff4d5e}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{height:100%;margin:0;background:var(--bg);color:var(--text);font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif}
body{display:flex;flex-direction:column;height:100vh;height:100dvh}
header{display:flex;align-items:center;gap:12px;padding:14px 16px;padding-top:max(14px,env(safe-area-inset-top));border-bottom:1px solid var(--border)}
.orb{width:34px;height:34px;border-radius:50%;border:2px solid var(--primary);box-shadow:0 0 14px var(--primary);position:relative;flex:none}
.orb::after{content:"";position:absolute;top:7px;left:7px;right:7px;bottom:7px;border-radius:50%;background:var(--primary);opacity:.8;animation:pulse 2.2s ease-in-out infinite}
.orb.thinking::after{animation-duration:.7s;background:var(--accent)}
.orb.listening::after{background:var(--accent)}
.orb.speaking::after{animation-duration:1.1s}
.orb.error{border-color:var(--danger);box-shadow:0 0 14px var(--danger)}
.orb.error::after{background:var(--danger)}
@keyframes pulse{0%,100%{transform:scale(.8);opacity:.5}50%{transform:scale(1.05);opacity:1}}
h1{font-size:16px;letter-spacing:.2em;margin:0;font-weight:600}
#label{font-size:12px;color:var(--dim);margin-top:2px}
#banner{display:none;background:rgba(255,77,94,.15);color:#ffb3ba;padding:8px 14px;font-size:13px}
#chat{flex:1;overflow-y:auto;padding:14px 14px 6px;display:flex;flex-direction:column;gap:10px;-webkit-overflow-scrolling:touch}
.msg{max-width:86%;padding:10px 13px;border-radius:14px;line-height:1.4;font-size:15px;white-space:pre-wrap;word-wrap:break-word;border:1px solid var(--border);background:var(--panel)}
.msg.user{align-self:flex-end;background:rgba(255,180,84,.1);border-color:rgba(255,180,84,.35)}
.msg.neo{align-self:flex-start}
.msg.err{border-color:rgba(255,77,94,.5);color:#ffb3ba}
.pic{display:block;max-width:100%;border-radius:10px;margin-top:8px;background:#000}
.who{font-size:10px;letter-spacing:.15em;color:var(--dim);margin-bottom:3px}
#empty{margin:auto;color:var(--dim);font-size:14px;text-align:center;line-height:1.6}
#modes{display:flex;gap:8px;overflow-x:auto;padding:8px 14px 0}
.chip{flex:none;border:1px solid var(--border);background:var(--panel);color:var(--dim);border-radius:999px;padding:6px 12px;font-size:13px;font-family:inherit}
.chip.on{color:var(--primary);border-color:var(--primary);background:rgba(45,226,255,.1)}
form{display:flex;gap:8px;padding:10px 14px;padding-bottom:max(12px,env(safe-area-inset-bottom))}
input{flex:1;min-width:0;background:rgba(255,255,255,.05);border:1px solid var(--border);border-radius:10px;color:var(--text);padding:12px;font-size:16px;outline:none;font-family:inherit}
input:focus{border-color:var(--primary)}
button.send{flex:none;width:46px;height:46px;border-radius:50%;border:0;background:var(--primary);color:#04141a;font-size:18px}
button.send:disabled{background:var(--border);color:var(--dim)}
</style>
</head>
<body>
<header>
  <div class="orb" id="orb"></div>
  <div><h1>NEO</h1><div id="label">Bağlanıyor…</div></div>
</header>
<div id="banner"></div>
<div id="chat"><div id="empty">Henüz mesaj yok.<br>NEO'ya buradan yazabilirsiniz.</div></div>
<div id="modes"></div>
<form id="form" autocomplete="off">
  <input id="input" placeholder="NEO'ya bir şey yazın…" enterkeyhint="send" autocomplete="off" autocapitalize="sentences">
  <button class="send" id="sendBtn" type="submit" disabled>&#10148;</button>
</form>
<script>
(function () {
  var T = new URLSearchParams(location.search).get('t') || '';
  var chat = document.getElementById('chat');
  var emptyEl = document.getElementById('empty');
  var orb = document.getElementById('orb');
  var label = document.getElementById('label');
  var banner = document.getElementById('banner');
  var modesEl = document.getElementById('modes');
  var form = document.getElementById('form');
  var input = document.getElementById('input');
  var sendBtn = document.getElementById('sendBtn');

  var MODES = [
    ['normal', 'Normal'],
    ['deepThink', 'Derin Düşünme'],
    ['quickAnswer', 'Hızlı Yanıt'],
    ['translate', 'Çeviri'],
    ['buddy', 'Kanka'],
    ['imageGen', 'Görsel Oluştur']
  ];
  var mode = 'normal';
  var lastId = null;
  var stopped = false;
  var inFlight = false;
  var failures = 0;
  var fast = false;
  var timer = null;

  function api(path, opts) {
    var sep = path.indexOf('?') >= 0 ? '&' : '?';
    return fetch(path + sep + 't=' + encodeURIComponent(T), opts);
  }
  function showBanner(text) { banner.textContent = text; banner.style.display = 'block'; }
  function hideBanner() { banner.style.display = 'none'; }
  function schedule(ms) { clearTimeout(timer); if (!stopped) timer = setTimeout(poll, ms); }

  function renderModes() {
    modesEl.textContent = '';
    MODES.forEach(function (m) {
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'chip' + (mode === m[0] ? ' on' : '');
      b.textContent = m[1];
      b.addEventListener('click', function () { mode = m[0]; renderModes(); });
      modesEl.appendChild(b);
    });
  }

  function clearChat() {
    chat.textContent = '';
    chat.appendChild(emptyEl);
    emptyEl.style.display = 'block';
  }

  function addMessage(m) {
    emptyEl.style.display = 'none';
    var nearBottom = chat.scrollHeight - chat.scrollTop - chat.clientHeight < 80;
    var div = document.createElement('div');
    div.className = 'msg ' + (m.role === 'user' ? 'user' : 'neo') + (m.err ? ' err' : '');
    var who = document.createElement('div');
    who.className = 'who';
    who.textContent = m.role === 'user' ? 'SİZ' : 'NEO';
    var body = document.createElement('div');
    body.textContent = m.text;
    div.appendChild(who);
    div.appendChild(body);
    var stick = nearBottom || m.role === 'user';
    if (m.img) {
      var src = '/api/image?id=' + encodeURIComponent(m.id) + '&t=' + encodeURIComponent(T);
      var link = document.createElement('a');
      link.href = src;
      link.target = '_blank';
      link.rel = 'noopener';
      var pic = document.createElement('img');
      pic.className = 'pic';
      pic.alt = 'Oluşturulan görsel';
      pic.addEventListener('load', function () { if (stick) chat.scrollTop = chat.scrollHeight; });
      pic.src = src;
      link.appendChild(pic);
      div.appendChild(link);
    }
    chat.appendChild(div);
    if (stick) chat.scrollTop = chat.scrollHeight;
  }

  function setState(state, text) {
    orb.className = 'orb ' + (state || 'idle');
    label.textContent = text || '';
    fast = (state === 'thinking' || state === 'speaking' || state === 'listening');
  }

  function poll() {
    if (inFlight || stopped) return;
    inFlight = true;
    var path = '/api/messages' + (lastId ? '?after=' + encodeURIComponent(lastId) : '');
    api(path).then(function (r) {
      if (r.status === 403) {
        stopped = true;
        showBanner('Oturum sona erdi veya paylaşım durduruldu. NEO üzerinden QR kodu yeniden okutun.');
        setState('error', 'Bağlantı yok');
        throw new Error('forbidden');
      }
      if (!r.ok) throw new Error('http ' + r.status);
      return r.json();
    }).then(function (d) {
      failures = 0;
      hideBanner();
      if (d.reset) { clearChat(); lastId = null; }
      d.messages.forEach(addMessage);
      if (d.messages.length) lastId = d.messages[d.messages.length - 1].id;
      setState(d.state, d.label);
    }).catch(function () {
      if (stopped) return;
      failures++;
      if (failures >= 3) {
        showBanner("NEO ile bağlantı kesildi. İki cihaz aynı Wi-Fi'de mi ve NEO ön planda açık mı?");
        setState('error', 'Bağlantı kesildi');
      }
    }).then(function () {
      inFlight = false;
      schedule(fast ? 700 : 1500);
    });
  }

  function updateSendBtn() { sendBtn.disabled = input.value.trim().length === 0; }
  input.addEventListener('input', updateSendBtn);

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    var text = input.value.trim();
    if (!text || stopped) return;
    sendBtn.disabled = true;
    api('/api/send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: text, mode: mode })
    }).then(function (r) {
      return r.json().then(function (j) { return { ok: r.ok, j: j }; });
    }).then(function (x) {
      if (x.ok && x.j.ok) {
        input.value = '';
        mode = 'normal';
        renderModes();
        hideBanner();
        schedule(50);
      } else {
        showBanner((x.j && x.j.error) || 'Gönderilemedi.');
      }
    }).catch(function () {
      showBanner('Gönderilemedi. Bağlantıyı kontrol edin.');
    }).then(updateSendBtn);
  });

  renderModes();
  poll();
})();
</script>
</body>
</html>
"""#
}
