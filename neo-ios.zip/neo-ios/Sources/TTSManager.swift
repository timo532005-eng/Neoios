import Foundation
import AVFoundation

// ════════════════════════════════════════════════════════════════
// TTSManager.swift — orijinal bölüm 13 (SESLENDİRME) karşılığı.
// Web SpeechSynthesis yerine AVSpeechSynthesizer kullanılır. "Humanize"
// modu; cümlelere bölme, cümle-türüne duyarlı hız/perde sapması ve
// cümleler arası doğal duraklamaları aynı mantıkla uygular.
// ════════════════════════════════════════════════════════════════

struct SentenceChunk {
    let text: String
    let pauseSeconds: Double
    let prePauseSeconds: Double
    let kind: String // "question" | "exclaim" | "statement"
}

/// AVSpeechSynthesizerDelegate, Objective-C tarafından çağrılan, izole
/// olmayan (nonisolated) bir protokoldür. Bunu doğrudan @MainActor olan
/// TTSManager'a uygulatmak yerine, ayrı ve minimal bir "aracı" (proxy)
/// nesneye uygulatıp çağrıları @MainActor'a Task ile aktarıyoruz — bu,
/// "converting non-Sendable function value" uyarısını kaynağında ortadan
/// kaldırır.
private final class TTSDelegateProxy: NSObject, AVSpeechSynthesizerDelegate {
    weak var owner: TTSManager?

    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didFinish utterance: AVSpeechUtterance) {
        Task { @MainActor [weak owner] in
            owner?.handleUtteranceFinished()
        }
    }

    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didCancel utterance: AVSpeechUtterance) {
        Task { @MainActor [weak owner] in
            owner?.handleUtteranceCancelled()
        }
    }
}

@MainActor
final class TTSManager: NSObject, ObservableObject {
    @Published var isSpeaking = false
    @Published var volume: Double = 0 // HUD --vol karşılığı, konuşma sırasında

    /// Tüm cümleler bittiğinde (ya da iptal edildiğinde normal bitişte) çağrılır.
    var onFinishedAllSentences: (() -> Void)?

    private let synthesizer = AVSpeechSynthesizer()
    private let delegateProxy = TTSDelegateProxy()
    private var token = 0
    private var availableVoices: [AVSpeechSynthesisVoice] = []

    override init() {
        super.init()
        delegateProxy.owner = self
        synthesizer.delegate = delegateProxy
        loadVoices()
    }

    func loadVoices() {
        availableVoices = AVSpeechSynthesisVoice.speechVoices()
    }

    var voices: [AVSpeechSynthesisVoice] { availableVoices }

    private func isTurkish(_ v: AVSpeechSynthesisVoice) -> Bool { v.language.lowercased().hasPrefix("tr") }

    /// iOS sesleri gerçek bir "cinsiyet" alanı sunar (AVSpeechSynthesisVoiceGender);
    /// bu yüzden orijinaldeki isim-tabanlı tahmine kıyasla burada daha güvenilirdir.
    private func gender(_ v: AVSpeechSynthesisVoice) -> VoiceGenderPref {
        switch v.gender {
        case .male: return .male
        case .female: return .female
        default: return .auto
        }
    }

    private func qualityScore(_ v: AVSpeechSynthesisVoice, genderPref: VoiceGenderPref, strict: Bool) -> Int {
        var score = 0
        if isTurkish(v) { score += 100 }
        switch v.quality {
        case .enhanced: score += 40
        case .premium: score += 60
        default: break
        }
        if genderPref != .auto {
            let g = gender(v)
            if g == genderPref { score += strict ? 220 : 60 }
            else if g != .auto { score -= 20 }
        }
        return score
    }

    func pickDefaultVoice(savedIdentifier: String?, genderPref: VoiceGenderPref, strict: Bool) -> AVSpeechSynthesisVoice? {
        if let saved = savedIdentifier, let found = availableVoices.first(where: { $0.identifier == saved }) {
            return found
        }
        guard !availableVoices.isEmpty else { return nil }
        return availableVoices.max { qualityScore($0, genderPref: genderPref, strict: strict) < qualityScore($1, genderPref: genderPref, strict: strict) }
    }

    func findVoice(langPrefix: String?, gender genderWanted: VoiceGenderPref?) -> AVSpeechSynthesisVoice? {
        availableVoices.first {
            (langPrefix == nil || $0.language.lowercased().hasPrefix(langPrefix!)) &&
            (genderWanted == nil || gender($0) == genderWanted)
        }
    }

    /// iOS'ta Türkçe için yerleşik bir erkek sistem sesi bulunmaz (yalnızca
    /// "Yelda" kadın sesi gelir). Kullanıcı erkek ses tercih ettiğinde ve
    /// seçilen sesin gerçek cinsiyeti erkek DEĞİLSE, tonu yapay olarak
    /// kalınlaştırarak (pitch düşürerek) yaklaşık bir erkek ses efekti
    /// uygulanır. Bu gerçek bir erkek ses kaydı değildir — dürüstlük için
    /// bunu ayrıca voiceSupportHint metninde de belirtiyoruz.
    func syntheticMalePitchMultiplier(for voice: AVSpeechSynthesisVoice?, genderPref: VoiceGenderPref) -> Float {
        guard genderPref == .male, let voice, gender(voice) != .male else { return 1.0 }
        return 0.74
    }

    func stop() {
        token += 1
        synthesizer.stopSpeaking(at: .immediate)
        volume = 0
        isSpeaking = false
    }

    private func clampD(_ v: Double, _ lo: Double, _ hi: Double) -> Double { max(lo, min(hi, v)) }

    private func splitIntoSentences(_ text: String) -> [SentenceChunk] {
        let pattern = "[^.!?…]+[.!?…]*|\\n+"
        var raw: [String] = []
        if let re = try? NSRegularExpression(pattern: pattern) {
            let ns = text as NSString
            re.enumerateMatches(in: text, range: NSRange(location: 0, length: ns.length)) { m, _, _ in
                if let m { raw.append(ns.substring(with: m.range)) }
            }
        }
        if raw.isEmpty { raw = [text] }
        return raw.map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty }.map { s in
            let isQuestion = s.range(of: #"[?？]\s*$"#, options: .regularExpression) != nil
            let isExclaim = s.range(of: #"[!！]\s*$"#, options: .regularExpression) != nil
            let endsSentence = s.range(of: #"[.!?…]\s*$"#, options: .regularExpression) != nil
            let prePause: Double = s.count > 70 ? 0.09 : (s.count > 40 ? 0.04 : 0)
            return SentenceChunk(
                text: s,
                pauseSeconds: endsSentence ? 0.26 : 0.13,
                prePauseSeconds: prePause,
                kind: isQuestion ? "question" : (isExclaim ? "exclaim" : "statement")
            )
        }
    }

    private func makeUtterance(_ text: String, voice: AVSpeechSynthesisVoice?, baseRate: Float, basePitch: Float, humanized: Bool, kind: String) -> AVSpeechUtterance {
        let utter = AVSpeechUtterance(string: text)
        utter.voice = voice
        if humanized {
            var rateMul: Double = 0.97 + Double.random(in: 0...0.06)
            var pitchMul: Double = 0.985 + Double.random(in: 0...0.03)
            if kind == "question" { pitchMul += 0.05 }
            if kind == "exclaim" { rateMul += 0.03; pitchMul += 0.02 }
            // AVSpeechUtterance.rate 0(çok yavaş)-1(çok hızlı) aralığında; web'in
            // 0.5-2 aralığındaki "rate"ini AVFoundation'ın varsayılan hız
            // katsayısına (AVSpeechUtteranceDefaultSpeechRate) oranlayarak eşliyoruz.
            let mappedRate = Float(clampD(Double(AVSpeechUtteranceDefaultSpeechRate) * Double(baseRate) * rateMul, Double(AVSpeechUtteranceMinimumSpeechRate), Double(AVSpeechUtteranceMaximumSpeechRate)))
            utter.rate = mappedRate
            utter.pitchMultiplier = Float(clampD(Double(basePitch) * pitchMul, 0.5, 2.0))
            utter.volume = Float(clampD(0.92 + Double.random(in: 0...0.08), 0, 1))
        } else {
            utter.rate = Float(clampD(Double(AVSpeechUtteranceDefaultSpeechRate) * Double(baseRate), Double(AVSpeechUtteranceMinimumSpeechRate), Double(AVSpeechUtteranceMaximumSpeechRate)))
            utter.pitchMultiplier = basePitch
        }
        return utter
    }

    func speak(_ text: String, voice: AVSpeechSynthesisVoice?, rate: Float, pitch: Float, humanize: Bool) {
        configureAudioSessionForPlayback()
        synthesizer.stopSpeaking(at: .immediate)
        token += 1
        let myToken = token
        isSpeaking = true

        if !humanize {
            let utter = makeUtterance(text, voice: voice, baseRate: rate, basePitch: pitch, humanized: false, kind: "statement")
            self.pendingCompletion = { [weak self] in
                guard let self else { return }
                self.volume = 0
                self.isSpeaking = false
                self.onFinishedAllSentences?()
            }
            synthesizer.speak(utter)
            return
        }

        let sentences = splitIntoSentences(text)
        speakNext(sentences: sentences, index: 0, token: myToken, voice: voice, rate: rate, pitch: pitch)
    }

    /// Konuşma sentezinin gerçekten duyulabilir olması için, mikrofon
    /// dinleme sırasında (.playAndRecord/.measurement) bırakılmış olabilecek
    /// ses oturumunu her seslendirmeden önce temiz bir "oynatma" moduna
    /// getirir. Bu adım atlanırsa, bir kez mikrofon kullanıldıktan sonra
    /// NEO'nun cevapları sessiz kalabilir veya çok kısık çalabilir.
    private func configureAudioSessionForPlayback() {
        let session = AVAudioSession.sharedInstance()
        do {
            try session.setCategory(.playback, mode: .voicePrompt, options: [.duckOthers])
            try session.setActive(true, options: [])
        } catch {
            // Sessizce geç; sentez motoru yine de kendi varsayılanıyla dener.
        }
    }

    private func speakNext(sentences: [SentenceChunk], index: Int, token myToken: Int, voice: AVSpeechSynthesisVoice?, rate: Float, pitch: Float) {
        guard myToken == token else { return }
        guard index < sentences.count else {
            volume = 0
            isSpeaking = false
            onFinishedAllSentences?()
            return
        }
        let chunk = sentences[index]
        let fire: @MainActor () -> Void = { [weak self] in
            guard let self, myToken == self.token else { return }
            let utter = self.makeUtterance(chunk.text, voice: voice, baseRate: rate, basePitch: pitch, humanized: true, kind: chunk.kind)
            self.pendingCompletion = { [weak self] in
                guard let self, myToken == self.token else { return }
                DispatchQueue.main.asyncAfter(deadline: .now() + chunk.pauseSeconds) { @MainActor in
                    self.speakNext(sentences: sentences, index: index + 1, token: myToken, voice: voice, rate: rate, pitch: pitch)
                }
            }
            self.volume = 0.7
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.12) { @MainActor in if myToken == self.token { self.volume = 0.2 } }
            self.synthesizer.speak(utter)
        }
        if chunk.prePauseSeconds > 0 {
            DispatchQueue.main.asyncAfter(deadline: .now() + chunk.prePauseSeconds) { @MainActor in fire() }
        } else {
            fire()
        }
    }

    private var pendingCompletion: (() -> Void)?

    fileprivate func handleUtteranceFinished() {
        let cb = pendingCompletion
        pendingCompletion = nil
        cb?()
    }

    fileprivate func handleUtteranceCancelled() {
        pendingCompletion = nil
    }
}
