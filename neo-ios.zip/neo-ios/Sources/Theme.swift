import SwiftUI

// ════════════════════════════════════════════════════════════════
// theme.swift — CSS :root değişkenlerinin (renk paleti) Swift karşılığı
// ════════════════════════════════════════════════════════════════

struct NEOPalette {
    let bg: Color
    let bgDeep: Color
    let panelBg: Color
    let panelBorder: Color
    let primary: Color
    let primarySoft: Color
    let secondary: Color
    let secondarySoft: Color
    let accent: Color
    let danger: Color
    let text: Color
    let textDim: Color

    static let dark = NEOPalette(
        bg: Color(hex: 0x05070a),
        bgDeep: Color(hex: 0x020304),
        panelBg: Color(hex: 0x101820).opacity(0.55),
        panelBorder: Color(hex: 0x78d6ff).opacity(0.16),
        primary: Color(hex: 0x45e0e8),
        primarySoft: Color(hex: 0x45e0e8).opacity(0.35),
        secondary: Color(hex: 0xb25bff),
        secondarySoft: Color(hex: 0xb25bff).opacity(0.35),
        accent: Color(hex: 0xffb454),
        danger: Color(hex: 0xff4d5e),
        text: Color(hex: 0xe7f6f8),
        textDim: Color(hex: 0x7f97a3)
    )

    static let crimson = NEOPalette(
        bg: Color(hex: 0x05070a),
        bgDeep: Color(hex: 0x020304),
        panelBg: Color(hex: 0x101820).opacity(0.55),
        panelBorder: Color(hex: 0x78d6ff).opacity(0.16),
        primary: Color(hex: 0xff5f6d),
        primarySoft: Color(hex: 0xff5f6d).opacity(0.35),
        secondary: Color(hex: 0xffb454),
        secondarySoft: Color(hex: 0xffb454).opacity(0.35),
        accent: Color(hex: 0x45e0e8),
        danger: Color(hex: 0xff4d5e),
        text: Color(hex: 0xe7f6f8),
        textDim: Color(hex: 0x7f97a3)
    )

    static func forTheme(_ theme: NeoTheme) -> NEOPalette {
        theme == .neoCrimson ? .crimson : .dark
    }
}

extension Color {
    init(hex: UInt32, alpha: Double = 1) {
        self.init(
            .sRGB,
            red: Double((hex >> 16) & 0xff) / 255,
            green: Double((hex >> 8) & 0xff) / 255,
            blue: Double(hex & 0xff) / 255,
            opacity: alpha
        )
    }
}

enum NEOFont {
    static func display(_ size: CGFloat, weight: Font.Weight = .bold) -> Font {
        .system(size: size, weight: weight, design: .rounded)
    }
    static func mono(_ size: CGFloat) -> Font {
        .system(size: size, weight: .regular, design: .monospaced)
    }
    static func body(_ size: CGFloat, weight: Font.Weight = .regular) -> Font {
        .system(size: size, weight: weight, design: .default)
    }
}

/// Durum bazlı renk yardımcıları (status-value.state-ok/warn/bad).
enum PanelLevel { case ok, warn, bad }
