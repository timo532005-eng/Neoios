import Foundation
import Speech
import AVFoundation

// ════════════════════════════════════════════════════════════════
// SpeechRecognizerManager.swift — orijinal bölüm 12 (KONUŞMA TANIMA)
// karşılığı. Web Speech API yerine Apple'ın Speech framework'ü (SFSpeechRecognizer)
// ve mikrofon genliği için AVAudioEngine tap'i kullanılır.
//
// NOT: SFSpeechRecognizer, Web Speech API'nin aksine konuşma bitiminde
// güvenilir biçimde bir "final" sonuç vermeyebilir. Bu yüzden burada iki
// güvenli teslimat yolu vardır: (1) tanıma motoru kendiliğinden bir final
// sonuç verirse onu kullanırız, (2) kullanıcı mikrofon düğmesine tekrar
// basarak elle durdurursa, o ana kadar tanınan en iyi metni kesin olarak
// göndeririz. Böylece "sesli komut hiç gönderilmiyor" sorunu yaşanmaz.
// ════════════════════════════════════════════════════════════════

@MainActor
final class SpeechRecognizerManager: NSObject, ObservableObject {
    @Published var isListening = false
    @Published var liveTranscript = ""
    @Published var volume: Double = 0 // 0..1, HUD'un --vol karşılığı
    @Published var supported = true

    /// Konuşma bittiğinde (final sonuç ya da elle durdurma) çağrılır.
    var onFinalResult: ((String) -> Void)?
    /// Bir hata oluştuğunda çağrılır.
    var onError: ((String) -> Void)?
    /// Tanıma oturumu, gönderilecek bir metin olmadan sona erdiğinde çağrılır.
    var onEnd: (() -> Void)?

    private let recognizer = SFSpeechRecognizer(locale: Locale(identifier: "tr-TR"))
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private let audioEngine = AVAudioEngine()
    private var latestTranscript = ""
    private var finalDelivered = false

    override init() {
        super.init()
        supported = (recognizer?.isAvailable ?? false)
    }

    func requestAuthorization(_ completion: @escaping (Bool) -> Void) {
        SFSpeechRecognizer.requestAuthorization { status in
            DispatchQueue.main.async {
                AVAudioSession.sharedInstance().requestRecordPermission { granted in
                    DispatchQueue.main.async {
                        completion(status == .authorized && granted)
                    }
                }
            }
        }
    }

    func start() {
        guard !isListening else { return }
        requestAuthorization { [weak self] granted in
            guard let self else { return }
            guard granted else {
                self.onError?("Mikrofon veya konuşma tanıma izni verilmedi. Ayarlar uygulamasından NEO için mikrofon/konuşma tanıma iznini açabilirsiniz.")
                return
            }
            self.beginCommandSession()
        }
    }

    private func beginCommandSession(attempt: Int = 0) {
        guard !isListening else { return }
        guard let recognizer, recognizer.isAvailable else {
            onError?("Bu cihaz konuşma tanımayı desteklemiyor.")
            return
        }
        // Önceki bir oturumdan kalmış olabilecek eski tap/format durumunu
        // tamamen temizleyip donanımla format uyuşmazlığı riskini azaltıyoruz.
        audioEngine.stop()
        audioEngine.inputNode.removeTap(onBus: 0)
        audioEngine.reset()

        let session = AVAudioSession.sharedInstance()
        do {
            try session.setCategory(.playAndRecord, mode: .measurement, options: [.duckOthers, .defaultToSpeaker, .allowBluetoothHFP])
            try session.setActive(true, options: .notifyOthersOnDeactivation)
        } catch {
            onError?("Mikrofon başlatılamadı: \(error.localizedDescription)")
            return
        }

        let request = SFSpeechAudioBufferRecognitionRequest()
        request.shouldReportPartialResults = true
        // Kısa cümlelerde de (ör. "hava durumu") sunucu tabanlı tanımanın
        // gereksiz yere geciktirmemesi için, cihaz destekliyorsa cihaz-üstü
        // tanımayı tercih ediyoruz — hem daha hızlı hem de internet
        // bağlantısı olmadan da çalışır.
        if recognizer.supportsOnDeviceRecognition {
            request.requiresOnDeviceRecognition = true
        }

        let inputNode = audioEngine.inputNode
        let nativeFormat = inputNode.outputFormat(forBus: 0)
        // inputNode'un raporladığı format, ses oturumu az önce etkinleştiği
        // için bir anlığına geçersiz (0 Hz / 0 kanal) görünebiliyor — bunu
        // "hazır değil" hatasının asıl sebebi olarak tespit ettik. Bu
        // durumda inputNode'un kendi (bazen güncel olmayan) formatına
        // güvenmek yerine, o anda kesinlikle güncel olan ses OTURUMUNUN
        // örnekleme hızından elle geçerli bir format kuruyoruz — installTap
        // özel bir format almayı destekler, motor gerekirse içeride
        // dönüştürür.
        let format: AVAudioFormat
        if nativeFormat.sampleRate > 0, nativeFormat.channelCount > 0 {
            format = nativeFormat
        } else {
            let sessionRate = session.sampleRate
            guard sessionRate > 0, let fallback = AVAudioFormat(commonFormat: .pcmFormatFloat32, sampleRate: sessionRate, channels: 1, interleaved: false) else {
                // Ses oturumunun kendisi de henüz bir örnekleme hızı
                // vermiyor — gerçekten çok erken bir andayız, kısa bir
                // gecikmeyle tekrar deniyoruz.
                if attempt < 10 {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) { [weak self] in
                        self?.beginCommandSession(attempt: attempt + 1)
                    }
                } else {
                    onError?("Mikrofon donanımı hazır değil, lütfen tekrar deneyin.")
                }
                return
            }
            format = fallback
        }
        recognitionRequest = request

        inputNode.removeTap(onBus: 0)
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: format) { [weak self] buffer, _ in
            request.append(buffer)
            self?.updateVolume(from: buffer)
        }

        audioEngine.prepare()
        do {
            try audioEngine.start()
        } catch {
            onError?("Mikrofon başlatılamadı: \(error.localizedDescription)")
            stopInternal()
            return
        }

        latestTranscript = ""
        finalDelivered = false
        isListening = true
        liveTranscript = ""

        recognitionTask = recognizer.recognitionTask(with: request) { [weak self] result, error in
            guard let self else { return }
            Task { @MainActor in
                if let result {
                    self.latestTranscript = result.bestTranscription.formattedString
                    self.liveTranscript = self.latestTranscript
                    if result.isFinal {
                        self.deliverFinalAndStop()
                    }
                }
                if error != nil {
                    // Tanıma bir hatayla sonlansa bile, o ana kadar
                    // yakalanmış bir metin varsa onu KAYBETMEYİP gönderiyoruz
                    // — "no speech"/zaman aşımı gibi hatalar genellikle
                    // kullanıcı zaten konuştuktan SONRA gelir.
                    if !self.finalDelivered && !self.latestTranscript.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                        self.deliverFinalAndStop()
                    } else {
                        let wasListening = self.isListening
                        self.stopInternal()
                        if wasListening { self.onEnd?() }
                    }
                }
            }
        }
    }

    /// Kullanıcı mikrofon düğmesine tekrar basarak elle durdurduğunda
    /// çağrılır. O ana kadar tanınan metni varsa kesin olarak gönderir.
    func stop() {
        deliverFinalAndStop()
    }

    private func deliverFinalAndStop() {
        guard isListening else { return }
        let text = latestTranscript.trimmingCharacters(in: .whitespacesAndNewlines)
        stopInternal()
        if !finalDelivered && !text.isEmpty {
            finalDelivered = true
            onFinalResult?(text)
        } else {
            onEnd?()
        }
    }

    private func stopInternal() {
        audioEngine.stop()
        audioEngine.inputNode.removeTap(onBus: 0)
        recognitionRequest?.endAudio()
        recognitionTask?.cancel()
        recognitionTask = nil
        recognitionRequest = nil
        isListening = false
        volume = 0
        // Ses oturumunu serbest bırak; böylece hemen ardından gelecek bir
        // seslendirme (TTS), oturumu temiz bir "oynatma" durumundan
        // yeniden yapılandırabilir (bkz. TTSManager.speak()).
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
    }

    /// Mikrofon buffer'ından yaklaşık RMS genliği hesaplayıp yumuşatarak
    /// HUD'un --vol CSS değişkeni karşılığı olan `volume`'u günceller.
    private func updateVolume(from buffer: AVAudioPCMBuffer) {
        guard let channelData = buffer.floatChannelData?[0] else { return }
        let frameLength = Int(buffer.frameLength)
        guard frameLength > 0 else { return }
        var sum: Float = 0
        for i in 0..<frameLength { sum += channelData[i] * channelData[i] }
        let rms = sqrt(sum / Float(frameLength))
        let norm = min(1.0, Double(rms) * 12)
        DispatchQueue.main.async { [weak self] in
            guard let self else { return }
            self.volume += (norm - self.volume) * 0.3
        }
    }
}
