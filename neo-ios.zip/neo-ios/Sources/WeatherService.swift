import Foundation
import CoreLocation

// ════════════════════════════════════════════════════════════════
// WeatherService.swift — Open-Meteo (anahtar gerektirmeyen, ücretsiz)
// hava durumu + geocoding entegrasyonu (orijinal bölüm 10.1 karşılığı).
// ════════════════════════════════════════════════════════════════

struct ResolvedLocation {
    let lat: Double
    let lon: Double
    let label: String?
}

struct WeatherReading {
    let temp: Int
    let humidity: Int
    let wind: Int
    let code: Int
}

private struct GeocodeResponse: Codable {
    struct Result: Codable {
        let latitude: Double
        let longitude: Double
        let name: String
        let admin1: String?
    }
    let results: [Result]?
}

private struct ForecastResponse: Codable {
    struct Current: Codable {
        let temperature_2m: Double
        let relative_humidity_2m: Double
        let wind_speed_10m: Double
        let weather_code: Int
    }
    let current: Current?
}

enum WeatherService {
    static func geocodeCity(_ city: String) async throws -> ResolvedLocation {
        guard let encoded = city.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
              let url = URL(string: "https://geocoding-api.open-meteo.com/v1/search?name=\(encoded)&count=1&language=tr&format=json") else {
            throw NEOError(code: "BAD_URL", message: "Geçersiz şehir adı.")
        }
        let data: Data
        let response: URLResponse
        do {
            (data, response) = try await URLSession.shared.data(from: url)
        } catch {
            throw NEOError(code: "NETWORK", message: "Konum servisine ulaşılamadı. İnternet bağlantınızı kontrol edin.")
        }
        guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else {
            throw NEOError(code: "HTTP", message: "Konum servisi bir hata döndürdü.")
        }
        guard let decoded = try? JSONDecoder().decode(GeocodeResponse.self, from: data),
              let r = decoded.results?.first else {
            throw NEOError(code: "NOT_FOUND", message: "\"\(city)\" adlı bir yer bulamadım.")
        }
        let label = r.name + (r.admin1.map { ", \($0)" } ?? "")
        return ResolvedLocation(lat: r.latitude, lon: r.longitude, label: label)
    }

    static func fetchWeather(_ loc: ResolvedLocation) async throws -> WeatherReading {
        guard let url = URL(string: "https://api.open-meteo.com/v1/forecast?latitude=\(loc.lat)&longitude=\(loc.lon)&current=temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code&timezone=auto") else {
            throw NEOError(code: "BAD_URL", message: "Geçersiz konum.")
        }
        let data: Data
        let response: URLResponse
        do {
            (data, response) = try await URLSession.shared.data(from: url)
        } catch {
            throw NEOError(code: "NETWORK", message: "Hava durumu servisine ulaşılamadı. İnternet bağlantınızı kontrol edin.")
        }
        guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else {
            throw NEOError(code: "HTTP", message: "Hava durumu servisi bir hata döndürdü.")
        }
        guard let decoded = try? JSONDecoder().decode(ForecastResponse.self, from: data),
              let c = decoded.current else {
            throw NEOError(code: "PARSE", message: "Hava durumu verisi alınamadı.")
        }
        return WeatherReading(temp: Int(c.temperature_2m.rounded()), humidity: Int(c.relative_humidity_2m.rounded()), wind: Int(c.wind_speed_10m.rounded()), code: c.weather_code)
    }
}

/// CLLocationManager tek-seferlik konum alma sarmalayıcısı
/// (orijinal getCurrentPositionAsync()).
final class OneShotLocationFetcher: NSObject, CLLocationManagerDelegate {
    private let manager = CLLocationManager()
    private var continuation: CheckedContinuation<ResolvedLocation, Error>?

    func fetch() async throws -> ResolvedLocation {
        try await withCheckedThrowingContinuation { cont in
            self.continuation = cont
            manager.delegate = self
            manager.desiredAccuracy = kCLLocationAccuracyKilometer
            let status = manager.authorizationStatus
            if status == .denied || status == .restricted {
                cont.resume(throwing: NEOError(code: "LOCATION", message: "Konum izni alınamadı (reddedildi)."))
                self.continuation = nil
                return
            }
            manager.requestWhenInUseAuthorization()
            manager.requestLocation()
        }
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let loc = locations.first else { return }
        continuation?.resume(returning: ResolvedLocation(lat: loc.coordinate.latitude, lon: loc.coordinate.longitude, label: nil))
        continuation = nil
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        continuation?.resume(throwing: NEOError(code: "LOCATION", message: "Konum izni alınamadı (\(error.localizedDescription))."))
        continuation = nil
    }
}
