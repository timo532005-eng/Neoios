import Foundation
import SwiftUI
import AVFoundation
import Combine
import Network

// ════════════════════════════════════════════════════════════════
// NEOEngine.swift — orijinal app.js'in merkezi durumu (AppState) ve
// iş mantığının tamamının Swift karşılığı. Tüm SwiftUI görünümleri bu
// tek ObservableObject'i gözlemler.
// ════════════════════════════════════════════════════════════════

@MainActor
final class NEOEngine: ObservableObject {

    // MARK: - HUD / durum
    @Published var state: NEOState = .idle
    @Published var stateLabel = NEOState.idle.label
    @Published var liveTranscript = ""
    /// Kullanıcı ana metin kutusuna yazarken true olur (bkz.
    /// ControlBarView). Kalıcı değildir; yalnızca o anki odak durumunu
    /// yansıtır ve HUDCanvasView'in animasyonunu geçici olarak
    /// durdurarak ana iş parçacığını klavye olayları için serbest
    /// bırakmakta kullanılır.
    @Published var isTyping = false
    /// AI modları > Görsel Oluştur seçilip bir mesaj gönderildiğinde,
    /// Görsel Oluştur çekmecesinin (ImageGenDrawerView) açılışta
    /// otomatik olarak alıp üretimi başlatacağı metin. Kalıcı değildir;
    /// işlendiği an nil'e döner (bkz. ImageGenDrawerView.onAppear).
    @Published var pendingImagePrompt: String? = nil
    @Published var volume: Double = 0 // --vol karşılığı (0..1)

    // MARK: - Panel değerleri
    @Published var neoPanel = "BAŞLATILIYOR"
    @Published var aiPanel = "YAPILANDIRILMADI"
    @Published var aiPanelLevel: PanelLevel = .warn
    @Published var voicePanel = "KONTROL EDİLİYOR"
    @Published var voicePanelLevel: PanelLevel = .warn
    @Published var networkPanel = "—"
    @Published var networkPanelLevel: PanelLevel = .warn
    @Published var clockText = "--:--:--"
    @Published var weatherPanel = "—"
    @Published var weatherPanelLevel: PanelLevel = .warn

    // MARK: - Sohbet
    @Published var chatMessages: [ChatMessage] = []
    var history: [HistoryTurn] = []
    var historySummary = ""

    // MARK: - Hafıza / Notlar / Hatırlatıcılar
    @Published var memory: [MemoryEntry] = [] { didSet { Store.set(StorageKeys.memory, memory) } }
    /// Hayat asistanı profili — Profilim ekranından doldurulur, her
    /// Gemini isteğine sistem talimatı olarak eklenir (bkz. buildSystemPrompt).
    @Published var userProfile: UserProfile = Defaults.userProfile { didSet { Store.set(StorageKeys.userProfile, userProfile) } }
    @Published var notes: [NoteEntry] = [] { didSet { Store.set(StorageKeys.notes, notes) } }
    @Published var reminders: [ReminderEntry] = []

    // MARK: - Takvim
    @Published var events: [CalendarEventEntry] = [] { didSet { persistEvents() } }
    @Published var calendarViewDate = Date()
    @Published var calendarSelectedDate: String? = nil

    // MARK: - Ayarlar
    @Published var apiKey: String = "" { didSet { Store.setString(StorageKeys.apiKey, apiKey) } }
    @Published var model: String = Config.geminiModel { didSet { Store.setString(StorageKeys.model, model) } }
    @Published var hfToken: String = "" { didSet { Store.setString(StorageKeys.hfToken, hfToken) } }
    @Published var imageModel: String = Config.cloudflareImageModel { didSet { Store.setString(StorageKeys.hfImageModel, imageModel) } }
    /// Ayarlar ekranından girilen Cloudflare bilgileri. Doldurulursa,
    /// MyApp.swift'teki CLOUDFLARE_ACCOUNT_ID / CLOUDFLARE_API_TOKEN kod
    /// sabitlerinin ÖNÜNE geçer (bkz. ImageGenViewModel.generate()).
    @Published var cloudflareAccountID: String = "" { didSet { Store.setString(StorageKeys.cloudflareAccountID, cloudflareAccountID) } }
    @Published var cloudflareApiToken: String = "" { didSet { Store.setString(StorageKeys.cloudflareApiToken, cloudflareApiToken) } }
    @Published var temperature: Double = Defaults.temperature { didSet { Store.setDouble(StorageKeys.temperature, temperature) } }
    @Published var rate: Float = Defaults.rate { didSet { Store.setDouble(StorageKeys.rate, Double(rate)) } }
    @Published var pitch: Float = Defaults.pitch { didSet { Store.setDouble(StorageKeys.pitch, Double(pitch)) } }
    @Published var autoSpeak = Defaults.autoSpeak { didSet { Store.setBool(StorageKeys.autoSpeak, autoSpeak) } }
    @Published var humanize = Defaults.humanize { didSet { Store.setBool(StorageKeys.humanize, humanize) } }
    @Published var animationsEnabled = Defaults.animations { didSet { Store.setBool(StorageKeys.animations, animationsEnabled) } }
    @Published var hudIntensity: HudIntensity = Defaults.hudIntensity { didSet { Store.setString(StorageKeys.hudIntensity, hudIntensity.rawValue) } }
    @Published var theme: NeoTheme = Defaults.theme { didSet { Store.setString(StorageKeys.theme, theme.rawValue) } }
    @Published var defaultCity: String = Defaults.defaultCity { didSet { Store.setString(StorageKeys.defaultCity, defaultCity) } }
    @Published var voiceGenderPref: VoiceGenderPref = Defaults.voiceGender { didSet { Store.setString(StorageKeys.voiceGender, voiceGenderPref.rawValue) } }
    @Published var voiceGenderStrict = Defaults.voiceGenderStrict { didSet { Store.setBool(StorageKeys.voiceGenderStrict, voiceGenderStrict) } }
    @Published var selectedVoiceIdentifier: String? = nil { didSet { Store.setString(StorageKeys.voiceIdentifier, selectedVoiceIdentifier ?? "") } }
    @Published var voiceSupportHint = ""

    // MARK: - Akıllı Ev (Tuya)
    @Published var tuyaAccessId: String = "" { didSet { Store.setString(StorageKeys.tuyaAccessId, tuyaAccessId) } }
    @Published var tuyaAccessSecret: String = "" { didSet { Store.setString(StorageKeys.tuyaAccessSecret, tuyaAccessSecret) } }
    @Published var tuyaUid: String = "" { didSet { Store.setString(StorageKeys.tuyaUid, tuyaUid) } }
    @Published var tuyaDataCenter: TuyaDataCenter = Defaults.tuyaDataCenter { didSet { Store.setString(StorageKeys.tuyaDataCenter, tuyaDataCenter.rawValue) } }
    /// Son alınan cihaz listesi (önbellek). Boşsa bir komut geldiğinde
    /// otomatik olarak yeniden çekilir (bkz. NEOEngine+SmartHome.swift).
    @Published var tuyaDevices: [TuyaDevice] = []

    var tuyaConfigured: Bool { !tuyaAccessId.isEmpty && !tuyaAccessSecret.isEmpty && !tuyaUid.isEmpty }
    var tuyaCredentials: TuyaCredentials {
        TuyaCredentials(accessId: tuyaAccessId, accessSecret: tuyaAccessSecret, uid: tuyaUid, dataCenter: tuyaDataCenter)
    }

    // MARK: - Kamera / Uygulama açma
    @Published var pendingAppLaunch: AppCatalogEntry? = nil
    @Published var showAppLaunchModal = false

    // MARK: - Toast / hata
    @Published var toastMessage: String? = nil
    private var toastWorkItem: DispatchWorkItem?

    var palette: NEOPalette { .forTheme(theme) }

    // MARK: - Alt sistemler
    /// "Paylaşım": aynı Wi-Fi'deki başka bir cihazdan tarayıcı üzerinden
    /// NEO'yu uzaktan kullanmayı sağlayan sunucu (bkz. RemoteShareController).
    let remote = RemoteShareController()
    let speech = SpeechRecognizerManager()
    let tts = TTSManager()
    let camera = CameraManager()
    private let locationFetcher = OneShotLocationFetcher()
    private var clockTimer: Timer?
    var speechCancellables = Set<AnyCancellable>()
    var networkMonitor: NWPathMonitor?

    init() {
        loadSettings()
        loadMemory()
        loadUserProfile()
        loadNotes()
        loadEvents()
        wireSpeech()
        wireTTS()
        updateAiPanel()
        updateVoicePanel()
        setState(.idle)
        startClock()
        startNetworkMonitoring()

        // Kullanıcı açıkça istedi: uygulama açılışında NEO otomatik bir
        // karşılama mesajı yazıp seslendirmiyor — sohbet boş başlıyor,
        // NEO kullanıcı bir şey yazana/söyleyene kadar sessiz bekliyor.
        neoPanel = "ONLINE"
    }

    // MARK: - Ayar yükleme (loadSettings karşılığı)

    private func loadSettings() {
        temperature = Store.getDouble(StorageKeys.temperature, fallback: Defaults.temperature)
        rate = Float(Store.getDouble(StorageKeys.rate, fallback: Double(Defaults.rate)))
        pitch = Float(Store.getDouble(StorageKeys.pitch, fallback: Double(Defaults.pitch)))
        autoSpeak = Store.getBool(StorageKeys.autoSpeak, fallback: Defaults.autoSpeak)
        humanize = Store.getBool(StorageKeys.humanize, fallback: Defaults.humanize)
        animationsEnabled = Store.getBool(StorageKeys.animations, fallback: Defaults.animations)
        hudIntensity = HudIntensity(rawValue: Store.getString(StorageKeys.hudIntensity, fallback: Defaults.hudIntensity.rawValue)) ?? .normal
        theme = NeoTheme(rawValue: Store.getString(StorageKeys.theme, fallback: Defaults.theme.rawValue)) ?? .neoDark
        defaultCity = Store.getString(StorageKeys.defaultCity, fallback: Defaults.defaultCity)
        voiceGenderPref = VoiceGenderPref(rawValue: Store.getString(StorageKeys.voiceGender, fallback: Defaults.voiceGender.rawValue)) ?? .auto
        voiceGenderStrict = Store.getBool(StorageKeys.voiceGenderStrict, fallback: Defaults.voiceGenderStrict)
        model = Store.getString(StorageKeys.model, fallback: Config.geminiModel)
        imageModel = Store.getString(StorageKeys.hfImageModel, fallback: Config.cloudflareImageModel)
        apiKey = Store.getString(StorageKeys.apiKey, fallback: "")
        hfToken = Store.getString(StorageKeys.hfToken, fallback: "")
        cloudflareAccountID = Store.getString(StorageKeys.cloudflareAccountID, fallback: "")
        cloudflareApiToken = Store.getString(StorageKeys.cloudflareApiToken, fallback: "")
        let savedVoice = Store.getString(StorageKeys.voiceIdentifier, fallback: "")
        selectedVoiceIdentifier = savedVoice.isEmpty ? nil : savedVoice
        tuyaAccessId = Store.getString(StorageKeys.tuyaAccessId, fallback: "")
        tuyaAccessSecret = Store.getString(StorageKeys.tuyaAccessSecret, fallback: "")
        tuyaUid = Store.getString(StorageKeys.tuyaUid, fallback: "")
        tuyaDataCenter = TuyaDataCenter(rawValue: Store.getString(StorageKeys.tuyaDataCenter, fallback: Defaults.tuyaDataCenter.rawValue)) ?? .europe
        refreshVoiceHint()
    }

    // MARK: - Saat

    private func startClock() {
        tickClock()
        clockTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] _ in
            Task { @MainActor in self?.tickClock() }
        }
    }
    private func tickClock() {
        let df = DateFormatter()
        df.locale = Locale(identifier: "tr_TR")
        df.dateFormat = "HH:mm:ss"
        clockText = df.string(from: Date())
    }

    // MARK: - Panel yardımcıları

    func updateAiPanel() {
        if apiKey.isEmpty { aiPanel = "YAPILANDIRILMADI"; aiPanelLevel = .warn }
        else { aiPanel = "HAZIR (\(model))"; aiPanelLevel = .ok }
    }
    func updateVoicePanel() {
        refreshVoicePanelText()
    }
    func updateNetworkPanel(online: Bool) {
        networkPanel = online ? "BAĞLI" : "ÇEVRİMDIŞI"
        networkPanelLevel = online ? .ok : .bad
    }

    func setState(_ newState: NEOState, label: String? = nil) {
        state = newState
        stateLabel = label ?? newState.label
        if newState != .listening { liveTranscript = "" }
    }

    // MARK: - Toast / Hata (showToast / showError karşılığı)

    func showToast(_ message: String) {
        toastMessage = message
        toastWorkItem?.cancel()
        let work = DispatchWorkItem { [weak self] in self?.toastMessage = nil }
        toastWorkItem = work
        DispatchQueue.main.asyncAfter(deadline: .now() + 5, execute: work)
    }

    func showError(_ message: String, recoverDelay: Double = 2.6, silent: Bool = false) {
        setState(.error)
        showToast(message)
        if !silent { append(role: .neo, text: message, isError: true) }
        DispatchQueue.main.asyncAfter(deadline: .now() + recoverDelay) { [weak self] in
            guard let self else { return }
            if self.state == .error { self.setState(.idle) }
        }
    }

    // MARK: - Sohbet görünümü (appendMessage / clearChatUI karşılığı)

    func append(role: ChatRole, text: String, isError: Bool = false, imageData: Data? = nil) {
        chatMessages.append(ChatMessage(role: role, text: text, isError: isError, imageData: imageData))
    }
    func clearChat() {
        chatMessages.removeAll()
        history.removeAll()
        historySummary = ""
    }

    func respondLocally(_ text: String) {
        append(role: .neo, text: text)
        if autoSpeak { speakNow(text) } else { setState(.idle) }
    }

    // MARK: - Hafıza (bölüm 6)

    private func loadMemory() { memory = Store.get(StorageKeys.memory, fallback: []) }
    private func loadUserProfile() { userProfile = Store.get(StorageKeys.userProfile, fallback: Defaults.userProfile) }
    func saveMemory(_ text: String) {
        let clean = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty else { return }
        memory.append(MemoryEntry(text: clean))
    }
    func deleteMemory(id: String) { memory.removeAll { $0.id == id } }
    func deleteLastMemory() -> MemoryEntry? {
        guard !memory.isEmpty else { return nil }
        return memory.removeLast()
    }
    func clearMemory() { memory.removeAll() }

    func buildSystemPrompt() -> String {
        let memText = memory.isEmpty ? "(kayıtlı bilgi yok)" : memory.map { "- \($0.text)" }.joined(separator: "\n")
        return SystemPrompt.template
            .replacingOccurrences(of: "{{MEMORY}}", with: memText)
            .replacingOccurrences(of: "{{PROFILE}}", with: buildProfileText())
    }

    private func buildProfileText() -> String {
        guard !userProfile.isEmpty else { return "(kullanıcı henüz Profilim ekranından bir bilgi girmedi)" }
        var lines: [String] = []
        func add(_ label: String, _ value: String) {
            let v = value.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !v.isEmpty else { return }
            lines.append("- \(label): \(v)")
        }
        add("İsim", userProfile.name)
        add("Hitap şekli", userProfile.nickname)
        add("Meslek/uğraş", userProfile.occupation)
        add("İlgi alanları", userProfile.interests)
        add("Hedefler", userProfile.goals)
        add("Günlük rutin notları", userProfile.routineNotes)
        add("Ek notlar", userProfile.extraNotes)
        lines.append("- Konuşma tarzı tercihi: \(userProfile.communicationStyle.promptHint)")
        return lines.joined(separator: "\n")
    }

    // MARK: - Notlar (bölüm 7)

    private func loadNotes() { notes = Store.get(StorageKeys.notes, fallback: []) }
    func addNote(_ text: String) {
        let clean = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty else { return }
        notes.append(NoteEntry(text: clean))
    }
    func deleteNote(id: String) { notes.removeAll { $0.id == id } }

    // MARK: - Hatırlatıcılar (bölüm 8) — yalnızca uygulama açıkken çalışır

    func addReminder(_ text: String, delayMinutes: Int) {
        let fireAt = Date().addingTimeInterval(Double(delayMinutes) * 60)
        var entry = ReminderEntry(text: text, fireAt: fireAt)
        let work = DispatchWorkItem { [weak self] in self?.fireReminder(id: entry.id) }
        entry.workItem = work
        reminders.append(entry)
        DispatchQueue.main.asyncAfter(deadline: .now() + Double(delayMinutes) * 60, execute: work)
    }
    private func fireReminder(id: String) {
        guard let entry = reminders.first(where: { $0.id == id }) else { return }
        reminders.removeAll { $0.id == id }
        let msg = "Hatırlatma: \(entry.text)"
        append(role: .neo, text: msg)
        if autoSpeak { speakNow(msg) }
    }
}
