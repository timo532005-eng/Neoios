# NEO — iOS (IPA derleme)

1. GitHub'da yeni repo aç, bu klasörün TÜM içeriğini yükle (`.github` klasörü dahil).
2. **Actions → Build unsigned IPA → Run workflow** (main'e push edince de kendiliğinden çalışır).
3. Bitince run sayfasının altındaki **Artifacts → NEO-unsigned-ipa** dosyasını indir (zip içinde NEO.ipa).
4. IPA'yı Sideloadly / AltStore ile kendi Apple ID'nle imzalayıp kur.

İmzalı sürüm için `build-signed-ipa.yml` (yukiarrr/ios-build-action) — ücretli Apple Developer hesabı ve 5 secret gerekir.
Bundle ID: `project.yml` içindeki `PRODUCT_BUNDLE_IDENTIFIER` (imzalı sürümde profilinle aynı olmalı).
