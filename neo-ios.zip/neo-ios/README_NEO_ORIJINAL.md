# NEO — Swift Playgrounds App (orijinal NEO_single_file_2.html'in Swift/SwiftUI karşılığı)

Bu proje, tek dosyalık NEO web uygulamasının **tüm özelliklerini** hedefleyen
bir Swift Playgrounds "App" projesidir (`.swiftpm`). Swift Playgrounds
(iPad/Mac) veya Xcode ile doğrudan açılabilir.

## Nasıl açılır
- **Swift Playgrounds (iPad/Mac):** `NEO.swiftpm` klasörünü/paketini açın.
- **Xcode:** `NEO.swiftpm` klasörünü Xcode'da açın (File > Open), simülatör
  veya gerçek cihaz seçip Run'a basın. Kamera ve mikrofon **gerçek cihazda**
  test edilmelidir (simülatörde kamera çalışmaz).

## Dosya haritası (orijinal → Swift)
| Orijinal (HTML/JS)                          | Swift karşılığı                              |
|----------------------------------------------|-----------------------------------------------|
| `config.js` (sabitler, sistem promptu)        | `Config.swift`                                 |
| `AppState`, `STATE`                           | `Models.swift`, `NEOEngine.swift`             |
| `localStorage` (`storeGet`/`storeSet`)        | `Persistence.swift` (UserDefaults)             |
| CSS `:root` renk değişkenleri                 | `Theme.swift`                                  |
| `classifyCommand`, hesap makinesi             | `CommandClassifier.swift`                      |
| `callGeminiRaw/callGemini/callGeminiVision`   | `GeminiService.swift`                          |
| `geocodeCity/fetchWeather`                    | `WeatherService.swift`                         |
| `SpeechRecognition` (Web Speech API)          | `SpeechRecognizerManager.swift` (Speech fw.)   |
| `SpeechSynthesis` (`speak()`, humanize)       | `TTSManager.swift` (AVSpeechSynthesizer)       |
| `getUserMedia` (kamera)                       | `CameraManager.swift` (AVFoundation)           |
| Komut yönlendirme (bölüm 10-11, 14)           | `NEOEngine+Commands.swift`                    |
| Konuşma/ses bağlama                           | `NEOEngine+Speech.swift`                      |
| `<canvas>` HUD çizimi (`drawHud`)             | `Views/HUDCanvasView.swift` (SwiftUI Canvas)   |
| HUD çekirdek/mikrofon/rings                   | `Views/CoreView.swift`                         |
| `.status-grid`                                | `Views/StatusGridView.swift`                   |
| Sohbet balonları/paneli                       | `Views/ChatViews.swift`                        |
| Alt kontrol çubuğu                            | `Views/ControlBarView.swift`                   |
| Üst çubuk + hamburger menü                    | `Views/TopBarAndMenu.swift`                    |
| Çekmeceler (drawer'lar)                       | `Views/DrawerContainer.swift` + ilgili görünümler |
| Ayarlar paneli                                | `Views/SettingsDrawerView.swift`               |
| Hafıza / Notlar panelleri                     | `Views/MemoryAndNotesDrawers.swift`            |
| Takvim paneli (Apple Takvim tarzı)            | `Views/CalendarDrawerView.swift`               |
| Kamera paneli + uygulama açma modalı + toast  | `Views/CameraDrawerView.swift`                 |
| Ana `<body>` düzeni                           | `Views/ContentView.swift`                      |

## Platform farklılıkları nedeniyle davranış değişiklikleri (dürüstlük notu)
Orijinal uygulama gibi, bu port da yapamadığı şeyleri gizlemez:

- **Konuşma tanıma/seslendirme motoru**: Web Speech API yerine Apple'ın
  `Speech` ve `AVFoundation` çerçeveleri kullanılır. Ses kalitesi/telaffuzu
  ve kullanılabilir Türkçe sesler, orijinaldeki tarayıcı seslerinden
  (Tolga/Ahmet/Emel/Filiz vb.) farklıdır; iOS'un kendi Türkçe seslerini
  kullanır (Ayarlar > Erişilebilirlik > Sesli İçerik'ten indirilebilir).
- **Cinsiyet tespiti**: iOS sesleri gerçek bir `gender` alanı sunduğu için
  (orijinaldeki isim-tabanlı tahmine kıyasla) burada daha güvenilirdir.
- **Kamera**: `AVCaptureSession` + `AVCapturePhotoOutput` kullanılır;
  yalnızca gerçek cihazda çalışır.
- **Konum**: `CoreLocation` (`CLLocationManager`) kullanılır; kullanıcıdan
  konum izni istenir.
- **Uygulama açma**: `UIApplication.open(_:)` ile URL şeması/web bağlantısı
  denenir; orijinaldeki tarayıcı pop-up engelleme mantığı iOS'ta farklı
  çalışır (izin istemi sistem tarafından yönetilir).
- **"NEO" uyandırma kelimesi (deneysel)**: Orijinalde de deneysel/kısıtlı
  olarak işaretlenmişti; bu portta ayar olarak mevcuttur ancak sürekli
  arka plan dinleme, iOS'un mikrofon/arka plan kısıtları nedeniyle
  uygulama ön planda değilken çalışmaz (tıpkı orijinalin tarayıcı sekmesi
  arka plandayken çalışmaması gibi bir platform sınırıdır).
- **API anahtarı güvenliği**: Orijinal gibi, Gemini API anahtarı bu cihazda
  (UserDefaults içinde) şifrelenmeden saklanır — Ayarlar ekranındaki uyarı
  metni bunu açıkça belirtir.

## Önemli
Bu kod bir Linux konteynerinde, Xcode/iOS SDK olmadan (yalnızca metin
düzeyinde) yazıldığından **derleme zamanında test edilememiştir**. Swift
sözdizimi ve API kullanımı özenle gözden geçirilmiştir, ancak Xcode'da ilk
açılışta küçük derleme hatalarıyla karşılaşırsanız (ör. bir API imzası
sürüm farkı), hata mesajını paylaşırsanız hemen düzeltebilirim.
